<?php

namespace Database\Seeders;

use App\Models\User;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            AdminUserSeeder::class,
            BatchSeeder::class,
            studentsSeeder::class,
            CourseSeeder::class,
            PlatformToolsSeeder::class,
            CoachingToolsSeeder::class,
            TemplateActivityTypeSeeder::class,
            StudentBatchMappingSeeder::class,
            StudentPackagesSeeder::class,
        ]);
    }
}
