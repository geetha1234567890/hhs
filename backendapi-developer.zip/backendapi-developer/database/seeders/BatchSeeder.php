<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Carbon;

class BatchSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $now = Carbon::now();

        $data = [
            ['id' => 13, 'name' => 'Organization', 'parent_id' => null, 'is_active' => 1, 'created_at' => $now, 'updated_at' => $now, 'node_level' => 1],
            ['id' => 14, 'name' => 'Organization', 'parent_id' => null, 'is_active' => 1, 'created_at' => $now, 'updated_at' => $now, 'node_level' => 1],
            ['id' => 9,  'name' => 'Branch 1', 'parent_id' => 13, 'is_active' => 1, 'created_at' => $now, 'updated_at' => $now, 'node_level' => 2],
            ['id' => 10, 'name' => 'Branch 2', 'parent_id' => 13, 'is_active' => 1, 'created_at' => $now, 'updated_at' => $now, 'node_level' => 2],
            ['id' => 11, 'name' => 'Branch 3', 'parent_id' => 14, 'is_active' => 1, 'created_at' => $now, 'updated_at' => $now, 'node_level' => 2],
            ['id' => 12, 'name' => 'Branch 4', 'parent_id' => 14, 'is_active' => 1, 'created_at' => $now, 'updated_at' => $now, 'node_level' => 2],
            ['id' => 1,  'name' => 'batch 1', 'parent_id' => 9, 'is_active' => 1, 'created_at' => $now, 'updated_at' => $now, 'node_level' => 3],
            ['id' => 2,  'name' => 'batch 2', 'parent_id' => 9, 'is_active' => 1, 'created_at' => $now, 'updated_at' => $now, 'node_level' => 3],
            ['id' => 3,  'name' => 'batch 3', 'parent_id' => 9, 'is_active' => 1, 'created_at' => $now, 'updated_at' => $now, 'node_level' => 3],
            ['id' => 4,  'name' => 'batch 4', 'parent_id' => 10, 'is_active' => 1, 'created_at' => $now, 'updated_at' => $now, 'node_level' => 3],
            ['id' => 5,  'name' => 'batch 5', 'parent_id' => 10, 'is_active' => 1, 'created_at' => $now, 'updated_at' => $now, 'node_level' => 3],
            ['id' => 6,  'name' => 'batch 6', 'parent_id' => 11, 'is_active' => 1, 'created_at' => $now, 'updated_at' => $now, 'node_level' => 3],
            ['id' => 7,  'name' => 'batch 7', 'parent_id' => 12, 'is_active' => 1, 'created_at' => $now, 'updated_at' => $now, 'node_level' => 3],
            ['id' => 8,  'name' => 'batch 8', 'parent_id' => 12, 'is_active' => 1, 'created_at' => $now, 'updated_at' => $now, 'node_level' => 3],
        ];

        DB::table('batches')->insert($data);
    }
}
