<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Carbon;

class StudentPackagesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $now = Carbon::now();

        $data = [
            ['id' => 1,  'package_id' => 1, 'package_name' => 'Package-1', 'student_id' => 1, 'is_active' => 1, 'created_by' => 1, 'updated_by' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['id' => 2,  'package_id' => 2, 'package_name' => 'Package-2', 'student_id' => 1, 'is_active' => 1, 'created_by' => 1, 'updated_by' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['id' => 3,  'package_id' => 3, 'package_name' => 'Package-3', 'student_id' => 1, 'is_active' => 1, 'created_by' => 1, 'updated_by' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['id' => 4,  'package_id' => 1, 'package_name' => 'Package-1', 'student_id' => 2, 'is_active' => 1, 'created_by' => 1, 'updated_by' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['id' => 5,  'package_id' => 2, 'package_name' => 'Package-2', 'student_id' => 2, 'is_active' => 1, 'created_by' => 1, 'updated_by' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['id' => 6,  'package_id' => 2, 'package_name' => 'Package-2', 'student_id' => 3, 'is_active' => 1, 'created_by' => 1, 'updated_by' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['id' => 7,  'package_id' => 3, 'package_name' => 'Package-3', 'student_id' => 3, 'is_active' => 1, 'created_by' => 1, 'updated_by' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['id' => 8,  'package_id' => 1, 'package_name' => 'Package-1', 'student_id' => 4, 'is_active' => 1, 'created_by' => 1, 'updated_by' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['id' => 9,  'package_id' => 1, 'package_name' => 'Package-1', 'student_id' => 5, 'is_active' => 1, 'created_by' => 1, 'updated_by' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['id' => 10, 'package_id' => 1, 'package_name' => 'Package-1', 'student_id' => 5, 'is_active' => 1, 'created_by' => 1, 'updated_by' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['id' => 11, 'package_id' => 3, 'package_name' => 'Package-3', 'student_id' => 5, 'is_active' => 1, 'created_by' => 1, 'updated_by' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['id' => 12, 'package_id' => 2, 'package_name' => 'Package-2', 'student_id' => 6, 'is_active' => 1, 'created_by' => 1, 'updated_by' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['id' => 13, 'package_id' => 1, 'package_name' => 'Package-1', 'student_id' => 6, 'is_active' => 1, 'created_by' => 1, 'updated_by' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['id' => 14, 'package_id' => 3, 'package_name' => 'Package-3', 'student_id' => 3, 'is_active' => 1, 'created_by' => 1, 'updated_by' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['id' => 15, 'package_id' => 2, 'package_name' => 'Package-2', 'student_id' => 7, 'is_active' => 1, 'created_by' => 1, 'updated_by' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['id' => 16, 'package_id' => 1, 'package_name' => 'Package-1', 'student_id' => 7, 'is_active' => 1, 'created_by' => 1, 'updated_by' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['id' => 17, 'package_id' => 3, 'package_name' => 'Package-3', 'student_id' => 8, 'is_active' => 1, 'created_by' => 1, 'updated_by' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['id' => 18, 'package_id' => 2, 'package_name' => 'Package-2', 'student_id' => 9, 'is_active' => 1, 'created_by' => 1, 'updated_by' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['id' => 19, 'package_id' => 1, 'package_name' => 'Package-1', 'student_id' => 10, 'is_active' => 1, 'created_by' => 1, 'updated_by' => 1, 'created_at' => $now, 'updated_at' => $now],
        ];

        DB::table('student_packages')->insert($data);
    }
}
