<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class PlatformToolsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $types = [
            'ZOOM',
            'Microsoft Teams',
            'Big Blue Button',
        ];

        foreach ($types as $type) {
            $existingType = \Modules\Admin\Models\PlatformTools::where('name', $type)->first();
    
            if (!$existingType) {
                
                \Modules\Admin\Models\PlatformTools::create([
                    'name' => $type,
                    'is_active' => true,
                ]);

            } else {
                Log::info("Tool already exists: $type");
            }
        }
    }
}
