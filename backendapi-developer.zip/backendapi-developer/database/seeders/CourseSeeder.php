<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CourseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('courses')->insert([
            [
                'id' => 1,
                'name' => 'Course 1',
                'is_active' => 1,
                'description' => 'Description of Course 1',
                'end_date' => '2025-01-01',
                'start_date' => '2024-01-01',
                'timezone_id' => 76,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'id' => 2,
                'name' => 'Course 2',
                'is_active' => 1,
                'description' => 'Description of Course 2',
                'end_date' => '2025-01-01',
                'start_date' => '2024-01-01',
                'timezone_id' => 76,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'id' => 3,
                'name' => 'Course 3',
                'is_active' => 1,
                'description' => 'Description of Course 3',
                'end_date' => '2024-01-01',
                'start_date' => '2024-01-01',
                'timezone_id' => 76,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'id' => 4,
                'name' => 'Course 4',
                'is_active' => 1,
                'description' => 'Description of Course 4',
                'end_date' => '2024-01-01',
                'start_date' => '2024-01-01',
                'timezone_id' => 76,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'id' => 5,
                'name' => 'Course 5',
                'is_active' => 1,
                'description' => 'Description of Course 5',
                'end_date' => '2024-01-01',
                'start_date' => '2024-01-01',
                'timezone_id' => 76,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'id' => 6,
                'name' => 'Course 6',
                'is_active' => 1,
                'description' => 'Description of Course 6',
                'end_date' => '2024-01-01',
                'start_date' => '2024-01-01',
                'timezone_id' => 76,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'id' => 7,
                'name' => 'Course 7',
                'is_active' => 1,
                'description' => 'Description of Course 7',
                'end_date' => '2024-01-01',
                'start_date' => '2024-01-01',
                'timezone_id' => 76,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'id' => 8,
                'name' => 'Course 8',
                'is_active' => 1,
                'description' => 'Description of Course 8',
                'end_date' => '2024-01-01',
                'start_date' => '2024-01-01',
                'timezone_id' => 76,
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);
    }
}
