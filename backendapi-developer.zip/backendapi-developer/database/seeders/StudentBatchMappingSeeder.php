<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Carbon;

class StudentBatchMappingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $now = Carbon::now();
        
        $data = [];
        $newStudents = range(1, 10);
        $batches = range(1, 8);

        foreach ($newStudents as $studentId) {
            $numBatches = rand(1, 3);
            $assignedBatches = array_rand(array_flip($batches), $numBatches);
            if (!is_array($assignedBatches)) {
                $assignedBatches = [$assignedBatches];
            }
            foreach ($assignedBatches as $batchId) {
                $data[] = [
                    'student_id' => $studentId,
                    'batch_id' => $batchId,
                    'created_at' => $now,
                    'updated_at' => $now,
                ];
            }
        }

        DB::table('student_batch_mapping')->insert($data);
    }
}
