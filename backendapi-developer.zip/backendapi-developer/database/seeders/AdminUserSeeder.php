<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class AdminUserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('admin_users')->insert([
            [
                'id' => 1,
                'name' => 'Admin-1',
                'username' => 'admin123',
                'email' => 'admin1@example.com',
                'phone' => '9842377856',
                'password' => Hash::make('123'), // Replace '123' with your secure default password
                'location' => 'Head Office',
                'address' => 'Saras AI office',
                'pincode' => '110001',
                'timezone_id' => 76,
                'gender' => 'Male',
                'date_of_birth' => '1990-01-01',
                'highest_qualification' => 'Masters',
                'is_active' => true,
                'created_by' => null,
                'updated_by' => null,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'id' => 2,
                'name' => 'Admin-2',
                'username' => 'saras-admin',
                'email' => 'admin2@example.com',
                'phone' => '9832334644',
                'password' => Hash::make('admin@123'), // Replace '123' with your secure default password
                'location' => 'Head Office',
                'address' => 'Saras AI office',
                'pincode' => '110001',
                'timezone_id' => 76,
                'gender' => 'Male',
                'date_of_birth' => '1990-01-01',
                'highest_qualification' => 'Masters',
                'is_active' => true,
                'created_by' => null,
                'updated_by' => null,
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);

        DB::table('user_roles')->insert([
        [
            'user_id' => 1,
            'role_id' => 3,
        ],
        [
            'user_id' => 2,
            'role_id' => 3,
        ],
        ]
    );
    }
}
