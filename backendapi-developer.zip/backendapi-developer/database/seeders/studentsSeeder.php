<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Carbon;

class StudentsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $now = Carbon::now();
        
        $data = [
            ['id' => 1, 'name' => 'Student 1', 'enrollment_id' => 'IL4145587', 'is_active' => 1, 'created_at' => $now, 'updated_at' => $now, 'timezone_id' => 76],
            ['id' => 2, 'name' => 'Student 2', 'enrollment_id' => 'IL4145588', 'is_active' => 1, 'created_at' => $now, 'updated_at' => $now, 'timezone_id' => 76],
            ['id' => 3, 'name' => 'Student 3', 'enrollment_id' => 'IL4145589', 'is_active' => 1, 'created_at' => $now, 'updated_at' => $now, 'timezone_id' => 76],
            ['id' => 4, 'name' => 'Student 4', 'enrollment_id' => 'IL4145590', 'is_active' => 1, 'created_at' => $now, 'updated_at' => $now, 'timezone_id' => 76],
            ['id' => 5, 'name' => 'Student 5', 'enrollment_id' => 'IL4145591', 'is_active' => 1, 'created_at' => $now, 'updated_at' => $now, 'timezone_id' => 76],
            ['id' => 6, 'name' => 'Student 6', 'enrollment_id' => 'IL4145592', 'is_active' => 1, 'created_at' => $now, 'updated_at' => $now, 'timezone_id' => 76],
            ['id' => 7, 'name' => 'Student 7', 'enrollment_id' => 'IL4145593', 'is_active' => 1, 'created_at' => $now, 'updated_at' => $now, 'timezone_id' => 76],
            ['id' => 8, 'name' => 'Student 8', 'enrollment_id' => 'IL4145594', 'is_active' => 1, 'created_at' => $now, 'updated_at' => $now, 'timezone_id' => 76],
            ['id' => 9, 'name' => 'Student 9', 'enrollment_id' => 'IL4145595', 'is_active' => 1, 'created_at' => $now, 'updated_at' => $now, 'timezone_id' => 76],
            ['id' => 10, 'name' => 'Student 10', 'enrollment_id' => 'IL4145596', 'is_active' => 1, 'created_at' => $now, 'updated_at' => $now, 'timezone_id' => 76],
        ];

        DB::table('students')->insert($data);
    }
}
