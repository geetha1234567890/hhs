<?php 
    return [
        'admin_id_required'=>'The admin user ID is required main lanuage file.',
        'admin_id_integer'=>'The admin user ID must be an integer.',
    ]
?>