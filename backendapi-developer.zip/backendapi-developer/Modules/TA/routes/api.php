<?php

use Illuminate\Support\Facades\Route;
use Modules\TA\Http\Controllers\API\TAProfileController;
use Modules\TA\Http\Controllers\API\TACalenderController;
use Modules\Admin\Http\Controllers\API\AuthController;
use Modules\TA\Http\Controllers\API\TAStudentBatchMappingController;
use Modules\TA\Http\Controllers\API\TACallRequestController;
use Modules\TA\Http\Controllers\API\TAScheduleCallController;
use Modules\TA\Http\Controllers\API\ChatController;
use Modules\TA\Http\Controllers\API\TACallRecordingController;
use Modules\TA\Http\Controllers\API\MyStudentController;


Route::middleware(['auth:admin-api', 'role:TA'])->group(function () {
    Route::post('/logout',[AuthController::class,'logout']);
    Route::prefix('v1')->group(function () {
        Route::prefix('ta')->name('ta.')->group(function () {
            Route::get('ta-profile', [TAProfileController::class, 'GetUser'])->name('profile');
            Route::put('ta-profile', [TAProfileController::class, 'Update'])->name('update');

            // TA chat routes
            Route::prefix('chat')->name('chat.')->group(function () {
                Route::post('/create-chat', [ChatController::class, 'createChat']);
                Route::post('/add/users', [ChatController::class, 'addUserToChat']);
                Route::post('/sent-messages', [ChatController::class, 'sendMessage']);
                Route::get('/get-messages', [ChatController::class, 'fetchMessages']);
                Route::get('/get-single-chat', [ChatController::class, 'getSingleChat']);
                Route::get('/get-my-chat', [ChatController::class, 'getMyChat']);
            });



            Route::prefix('calendar')->name('calendar.')->group(function () {
                Route::get('slots', [TACalenderController::class, 'getAllSlots'])->name('slots');
                Route::post('slots-by-date', [TACalenderController::class, 'getAllSlotByDate' ])->name('slots-by-date');
                Route::get('sessions',[TACalenderController::class, 'getAllSessions'])->name('sessions');
                Route::post('slot-between-dates', [TACalenderController::class, 'getSlotsForBetweenDates' ])->name('slot-between-dates');
                Route::post('schedule-by-slots', [TACalenderController::class, 'getScheduledRecordsBySlots' ])->name('schedule-by-slots');
                Route::post('reschedule/{id}', [TACalenderController::class, 'ReSchedules' ])->name('reschedule');
                Route::put('cancel-schedule/{id}', [TACalenderController::class, 'CancelSchedule' ])->name('cancel-schedule');
                Route::post('create-slots', [TACalenderController::class, 'storeSlots'])->name('create-slots');
                Route::post('create-leave', [TACalenderController::class, 'storeLeave'])->name('create-leave');
            });

            Route::get('get-students', [TAStudentBatchMappingController::class, 'getAssignStudents'])->name('get-students');
            Route::get('get-batches', [TAStudentBatchMappingController::class, 'getAssignBatches'])->name('get-batches');

            Route::prefix('schedule-call')->name('schedule-call.')->group(function () {
                Route::post('get-schedule-call', [TAScheduleCallController::class, 'getTaScheduleCall'])->name('get-schedule-call');
                Route::post('schedule-calls', [TAScheduleCallController::class, 'scheduleCall'])->name('schedule-call');
            });

            Route::prefix('call-request')->name('call-request.')->group(function () {
                Route::get('get-call-request', [TACallRequestController::class, 'getTaAllCallRequest']);
                Route::get('approve-call-request/{id}', [TACallRequestController::class, 'approveTaCallRequest']);
                Route::put('denie-call-request/{id}', [TACallRequestController::class, 'deniedTaCallRequest']);
            });
            Route::prefix('call-recording')->name('call-recording.')->group(function () {
                Route::POST('get-call-recording', [TACallRecordingController::class, 'getAllCallRecoding']);
                Route::put('assign-session-notes/{id}', [TACallRecordingController::class, 'updateTASessionNotes']);
                Route::put('upload-session-recording/{id}', [TACallRecordingController::class, 'updateTASessionRecoding']);
            });
            Route::prefix('my-student')->name('my-student.')->group(function () {
                Route::get('get-all-student', [MyStudentController::class, 'GetAllStudent'])->name('get-all-student');
                Route::get('get-student-session-status/{id}', [MyStudentController::class, 'StudentAllSessionStatus'])->name('get-student-session-status');
            });
        });
    });
});