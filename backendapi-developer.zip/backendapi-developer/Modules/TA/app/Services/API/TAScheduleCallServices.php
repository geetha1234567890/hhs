<?php

namespace Modules\TA\Services\API;

use Illuminate\Support\Facades\Hash;
use Auth;
use Crypt;

use Modules\Admin\Models\TACoachSlots;
use Modules\Admin\Models\AdminUsers;
use Modules\Admin\Models\TACoachScheduling;
use Modules\Admin\Models\TACoachBatchScheduling;
use Modules\Admin\Models\TACoachStudentScheduling;
use Modules\Admin\Models\Student;
use Modules\Admin\Models\Batch;
use Modules\Admin\Models\StudentBatchMapping;
use Modules\Admin\Models\MeetingDetails;
use Modules\Admin\Services\API\ZoomServices;
use Carbon\Carbon;
class TAScheduleCallServices
{
    public function __construct(ZoomServices $zoomService) {
        $this->zoomService = $zoomService;
    }
    public function getTAScheduleCallData($request)
    {
        // Get the current date in 'Y-m-d' format
        $current_date =$request->date;
        $current_time = Carbon::now()->format('H:i:s');
        $user_id = Auth::guard('admin-api')->user()->id;
 
        // Retrieve TA coach slots for the current date and time
        $ta_schedules = TACoachScheduling::with(['students','PlatformToolDetails','PlatformMeetingDetails'])
            ->where('admin_user_id', $user_id)
            ->where('is_deleted', false)
            ->where('date', $current_date)
            ->get()
            ->map(function ($item) use ($current_time) {
                // Remove unwanted fields
                unset($item->series);
                unset($item->is_deleted);
                unset($item->created_at);
                unset($item->updated_at);
                unset($item->created_by);
                unset($item->updated_by);

                if ($item->start_time <= $current_time && $item->end_time >= $current_time) {
                    $item->event_status = 'join meeting';
                } elseif ($item->end_time < $current_time) {
                    $item->event_status = 'call expired';
                } else {
                    $item->event_status = 'call schedule';
                }
                // Optionally, you can do the same for the students relationship
                $item->students->map(function ($student) {
                    unset($student->created_by);
                    unset($student->updated_by);
                    unset($student->created_at);
                    unset($student->updated_at);
                    return $student;
                });

                return $item;
            });

        // Convert the collection to an array
        $ta_schedules = $ta_schedules->toArray();


        if ($ta_schedules) {
            return [
                'status' => true,
                'message' => __('Admin::response_message.ta_schedule.ta_schedule_retrieve'),
                'data' => $ta_schedules,
            ];
        } else {
            return [
                'status' => false,
                'message' => __('Admin::response_message.ta_schedule.ta_schedule_found'),
            ];
        }
    }
 
    public function ScheduleCall($request)
    {
        // Extract request parameters
        $adminUserId = Auth::guard('admin-api')->user()->id;
        $adminUserEmail = Auth::guard('admin-api')->user()->email;
        $meeting_name = $request->meeting_name;
        $platform_id = $request->platform_id;
        $start_date = Carbon::parse($request->schedule_date);
        $message = $request->message;
        $start_time = $request->start_time;
        $end_time = $request->end_time;
        $timezone_id = $request->timezone_id;
        $event_status = $request->event_status;
        $studentIds = $request->studentId ?? []; 
        $batchIds = $request->batchId ?? [];
    
         $existingSchedule = TACoachScheduling::where('admin_user_id', $adminUserId)
                                        ->where('date', $start_date)
                                        ->orderBy('start_time')
                                        ->where('is_deleted', false)
                                        ->get();
    
            foreach ($existingSchedule as $schedule) {
                if (($start_time >= $schedule->start_time && $start_time < $schedule->end_time) ||
                    ($end_time > $schedule->start_time && $end_time <= $schedule->end_time) ||
                    ($start_time <= $schedule->start_time && $end_time >= $schedule->end_time)) {
                    return [
                        'status'=>false,
                        'message' => __('Admin::response_message.schedules.schedule_clash_message', ['date' => $start_date]),
                    ];
                }
            }
            $existingSlots = TACoachSlots::where('admin_user_id', $adminUserId)
                                        ->where('slot_date', $start_date)
                                        ->orderBy('from_time')
                                        ->get();
            $count = 0;
            foreach ($existingSlots as $slot) {
                if (($start_time >= $slot->from_time && $end_time <= $slot->to_time)) {
                    $potentialSlots[] = $slot;
                    $count = 1;
                }
            }
            if($count==0){
                $slot = new TACoachSlots([
                    'admin_user_id' => $adminUserId,
                    'slot_date' => $start_date,
                    'from_time' => $start_time,
                    'to_time' => $end_time,
                    'timezone_id' => $request->timezone_id,
                    'created_by' => $adminUserId,
                    'updated_by' => $adminUserId,
                ]);
                
                $slot->save();
                $potentialSlots[] = $slot;
            }
            $created_schedule = [];
            $seriesId = null;
             // Format the datetime in ISO 8601 format with 'Z' indicating UTC timezone
             $datetime_string = "$request->schedule_date $start_time";
             $datetime = Carbon::createFromFormat('Y-m-d H:i:s', $datetime_string, 'UTC');
             $formatted_datetime =$datetime->toIso8601String();
             $start = Carbon::createFromTimeString($start_time);
             $end = Carbon::createFromTimeString($end_time);
 
             // Calculate the difference in minutes
             $minutes = $start->diffInMinutes($end);
             $data = [
                         'host_id' => 'sandeeppatel@dynapt.co.in',//$adminUserEmail,
                         'meeting_name' => $meeting_name,
                         'duration' => $minutes,
                         'description' => $meeting_name
                     ];
 
             $zoom_response = $this->zoomService->createMeeting($data,$formatted_datetime);
             $newMeetingDetails = new MeetingDetails([
                'platform_meeting_id' => $zoom_response['id'],
                'host_meeting_url' =>$zoom_response['start_url'],
                'join_url' => $zoom_response['join_url'],
                'password' => $zoom_response['password'],
                'h323_password' => $zoom_response['h323_password'],
                'pstn_password' => $zoom_response['pstn_password'],
                'encrypted_password' => $zoom_response['encrypted_password'],
            ]);
            $newMeetingDetails->save();
            foreach ($potentialSlots as $slot) {

                $newSchedule = new TACoachScheduling([
                    'admin_user_id' => $adminUserId,
                    'meeting_name' => $meeting_name,
                    'meeting_id' => $newMeetingDetails->id,
                    'platform_id'=>$platform_id,
                    'message'=>$message,
                    'date' => $slot['slot_date'],
                    'slot_id' => $slot['id'],
                    'start_time' => $start_time,
                    'end_time' => $end_time,
                    'timezone_id' => $timezone_id,
                    'event_status' => $event_status,
                    'session_type' => 'Live',
                    'created_by' => $adminUserId,
                    'updated_by' => $adminUserId
                ]);
                
                $newSchedule->save();
                foreach ($request->batchId as $batchData) {
                    $Batch = Batch::find($batchData);
                    if ($Batch) {
                        $newSchedule->batch()->attach($Batch);
                
                        $studentListData = StudentBatchMapping::where('batch_id', $batchData)->get();
                        foreach ($studentListData as $studentMapping) {
                            $studentId = $studentMapping->student_id;
                            TACoachStudentScheduling::firstOrCreate(
                                ['ta_schedule_id' => $newSchedule->id, 'student_id' => $studentId],
                                [
                                    'created_by' => $adminUserId,
                                    'updated_by' => $adminUserId,
                                ]
                            );
                        }
                    }
                }
                foreach ($request->studentId as $studentId) {
                    TACoachStudentScheduling::firstOrCreate(
                        ['ta_schedule_id' => $newSchedule->id, 'student_id' => $studentId],
                        [
                            'created_by' => $adminUserId,
                            'updated_by' => $adminUserId,
                        ]
                    );
                }

                $created_schedule[] = $newSchedule;
            }

        // Return appropriate response based on slot creation result
        if($created_schedule){
            return [
                'status'=>true,
                'message' => __('Admin::response_message.schedules.schedule_store'),
                'data'=>$created_schedule,
            ];
        }else{
            return [
                'status'=>false,
                'message' => __('Admin::response_message.schedules.store_schedule_failed'),
            ];
        }

    }
}
