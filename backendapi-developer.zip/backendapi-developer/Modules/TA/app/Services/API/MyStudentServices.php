<?php
namespace Modules\TA\Services\API;

use Illuminate\Support\Facades\Hash;
use Auth;
use Crypt;

use Modules\Admin\Models\TACoachSlots;
use Modules\Admin\Models\AdminUsers;
use Modules\Admin\Models\TACoachScheduling;
use Modules\Admin\Models\TACoachBatchScheduling;
use Modules\Admin\Models\Student;
use Modules\Admin\Models\Batch;
use Modules\Admin\Models\StudentBatchMapping;
use Modules\Admin\Models\TACoachStudentScheduling;
use Modules\Admin\Models\StudentJoinedMeetingStatus;
use Carbon\Carbon;

class MyStudentServices
{
    public function GetAllStudent()
    {
        // Get the ID of the currently authenticated ta
        $admin_id = Auth::guard('admin-api')->user()->id;
        $schedules = TACoachScheduling::with(['students', 'batch'])
        ->where('admin_user_id', $admin_id)
        ->where('is_active', true)->get();
        $studentsData = [];

        foreach ($schedules as $schedule) {
            foreach ($schedule->students as $student) {
                $studentID = $student->id;
            
                // Initialize or update student data
                if (!isset($studentsData[$studentID])) {
                    $studentsData[$studentID] = [
                        'Student_Name' => $student->name,
                        'Student_Id' => $studentID,
                        'Program' => $student->packages->pluck('package_name')->implode(', '),
                        'Batch' => $student->studentBatchMappings->pluck('batch.name')->implode(' '),
                        'Live_Sessions_Scheduled' => 0,
                        'Live_Sessions_Attended' => 0,
                    ];
                }
            
                // Increment live sessions scheduled for this student
                $studentsData[$studentID]['Live_Sessions_Scheduled'] += $schedule->scheduleStudent->where('student_id', $studentID)->count();
            
                // Calculate live sessions attended for this student
                $studentsData[$studentID]['Live_Sessions_Attended'] += StudentJoinedMeetingStatus::where('student_id', $studentID)
                    ->where('ta_schedule_id', $schedule->id)
                    ->whereNotNull('joined_at')
                    ->count();
            }           
        }
        if ($studentsData) {

            return [
                'status' => true,
                'message' => __('Admin::response_message.ta_call_records.call_recording_retrieve'),
                'data' => $studentsData,
            ];
        } else {

            return [
                'status' => false,
                'message' => __('Admin::response_message.ta_call_records.call_recording_not_found'),
            ];
        }
    }

    public function StudentAllSessionStatus($student_id)
    {
        $admin_id = Auth::guard('admin-api')->user()->id;
        $schedules = TACoachScheduling::with(['students', 'batch']) // Adjust relationships as necessary
    ->where('admin_user_id', $admin_id)
    ->whereHas('students', function($query) use ($student_id) {
        $query->where('student_id', $student_id);
    })
    ->where('is_active', true)
    ->get();
    printf($schedules);
    die;


        $schedules = TACoachScheduling::with(['students', 'batch'])
        ->where('admin_user_id', $admin_id)
        ->where('is_active', true)->get();
        $studentsData = [];

        foreach ($schedules as $schedule) {
            foreach ($schedule->students as $student) {
                $studentID = $student->id;
            
                // Initialize or update student data
                if (!isset($studentsData[$studentID])) {
                    $studentsData[$studentID] = [
                        'Student_Name' => $student->name,
                        'Student_Id' => $studentID,
                        'Program' => $student->packages->pluck('package_name')->implode(', '),
                        'Batch' => $student->studentBatchMappings->pluck('batch.name')->implode(' '),
                        'Live_Sessions_Scheduled' => 0,
                        'Live_Sessions_Attended' => 0,
                    ];
                }
            
                // Increment live sessions scheduled for this student
                $studentsData[$studentID]['Live_Sessions_Scheduled'] += $schedule->scheduleStudent->where('student_id', $studentID)->count();
            
                // Calculate live sessions attended for this student
                $studentsData[$studentID]['Live_Sessions_Attended'] += StudentJoinedMeetingStatus::where('student_id', $studentID)
                    ->where('ta_schedule_id', $schedule->id)
                    ->whereNotNull('joined_at')
                    ->count();
            }
        }
        if ($studentsData) {

            return [
                'status' => true,
                'message' => __('Admin::response_message.ta_call_records.call_recording_retrieve'),
                'data' => $studentsData,
            ];
        } else {

            return [
                'status' => false,
                'message' => __('Admin::response_message.ta_call_records.call_recording_not_found'),
            ];
        }
        if ($db_data) {
                $db_data->update(['session_meeting_notes' => $session_notes]);
            return [
                'status' => true,
                'message' => __('Admin::response_message.ta_call_records.call_recording_note_upload'),
                'data' => $db_data,
            ];
        } else {

            return [
                'status' => false,
                'message' => __('Admin::response_message.ta_call_records.call_recording_not_found'),
            ];
        }

    }
}
