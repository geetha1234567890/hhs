<?php     

    namespace Modules\TA\Services\API;
    use Auth;
    use Modules\Admin\Models\Chats;
    use Modules\Admin\Models\ChatUsers;
    use App\Events\ChatMessageSent;
    use Modules\Admin\Models\ChatMessages;
    use Modules\Admin\Models\ChatMessageFiles;
    use Modules\Admin\Models\AdminUsers;
    use Modules\Admin\Models\Student;

    class ChatServices
    {

        /**
         * Creates a new chat with the provided details.
         *
         * @param \Illuminate\Http\Request $request The HTTP request instance containing the chat details.
         * @return array An associative array containing the status and message of the operation. 
         *
         */
        public function createNewChat($request)
        {
            $chat = Chats::create([
                'chat_name' => $request->chat_name ?? null,
                'is_group' => $request->is_group ?? 0
            ]);

            if ($chat) {

                return [
                    'status' => true,
                    'message' => __('Admin::response_message.chat.store_chat'),
                    'data' => $chat,
                ];
            } else {

                return [
                    'status' => false,
                    'message' => __('Admin::response_message.chat.failed_to_store_chat'),
                ];
            }

        }

        /**
         * Adds multiple users to a specified chat.
         *
         * @param \Illuminate\Http\Request $request The HTTP request instance containing the chat and user details.
         * @return array An associative array containing the status and message of the operation.
         *  
         */
        public function addUserToNewChat($request)
        {
            $user = Auth::guard('admin-api')->user();
            $login_user_id = $user->id;

            $chat_id = $request->chat_id;
            $chat = Chats::find($chat_id);
        
            // Check if chat exists
            if (!$chat) {
                return [
                    'status' => false,
                    'message' => __('Admin::response_message.chat.failed_assign_user_chat'),
                ];
            }
            
            // Ensure $users is an array
            $users = $request->users; 
          
            // Define the current user
            $current_user = [
                'user_id'=>$login_user_id,
                'user_type'=>'AdminUsers',
            ];

            // Add the current user to the users array
            $users[] = $current_user;

            $errors = [];
        
            foreach ($users as $user) {

                $user_id = $user['user_id'];
                $user_type = $user['user_type'];

                $user_type = "Modules\Admin\Models\\{$user_type}";
        
                $relationship = $user_type == 'Modules\Admin\Models\AdminUsers' ? 'adminUsers' : 'students';

                // Check if user is already assigned to the chat
                $is_user_already_assigned = ChatUsers::where(['user_id'=>$user_id,'user_type'=>$user_type,'chats_id'=>$chat_id])->first();
        
                if ($is_user_already_assigned) {
                    $errors[] = [
                        'user_id' => $user_id,
                        'message' => __('Admin::response_message.chat.user_already_assigned'),
                    ];
                    continue; // Skip this user and proceed with the next one
                }
        
                // Attach the user to the chat
                $chat->$relationship()->attach($user_id, ['user_type' => $user_type]);
            }
        
            if (!empty($errors)) {
                return [
                    'status' => false,
                    'message' => __('Admin::response_message.chat.some_users_not_assigned'),
                    'errors' => $errors,
                ];
            }

            return [
                'status' => true,
                'message' => __('Admin::response_message.chat.assign_user_chat'),
                'data' => $chat,
            ];
        }

        /**
         * Handles sending chat messages, including saving the message and any attached files.
         *
         * @param \Illuminate\Http\Request $request The incoming request containing the message details and optional file uploads.
         * @return array A response array with the status of the message sending operation, a message, and the saved message data.
         */
        public function sendMessages($request)
        {
            // Get the authenticated user
            $user = Auth::guard('admin-api')->user();
            $login_user_id = $user->id;
    
            // Retrieve data from the request
            $chat_id = $request->chat_id;
            $user_id = $login_user_id ?? $request->user_id;
            $sender_type = $request->sender_type;
            $message = $request->message_text ?? null;
            $sender_type = "Modules\Admin\Models\\{$sender_type}";

            // Validate sender_type
            if (!in_array($sender_type, [AdminUsers::class, Student::class])) {
                return [
                    'status' => false,
                    'message' => __('Admin::response_message.chat.invalid_sender_type'),
                ];
            }
    
            // Create a new chat message
            $message = ChatMessages::create([
                'chat_id' => $request->chat_id,
                'sender_id' => $user_id,
                'sender_type' => $sender_type,
                'message_text' => $message ,
                'status' => 'sent',
            ]);
    
            // Handle file uploads if any
            if ($request->hasFile('files')) {

                foreach ($request->file('files') as $file) {
     
                    // Generate a filename
                    $file_name =  time() . '.' . $file->getClientOriginalExtension();
    
                    // Store the file and get its path
                    $filePath = $file->storeAs('chat_files', $file_name, 'public');
    
                    // Save file information to the `files` table
                    ChatMessageFiles::create([
                        'message_id' => $message->id,
                        'file_name' => $file_name,
                        'original_name' => $file->getClientOriginalName(),
                        'uploaded_at' => now(),
                    ]);
                }
            }
           
            // Broadcast the new message event to others
            // broadcast(new ChatMessageSent($message))->toOthers();

            // Return a response array
            return [
                'status' => true,
                'message' => __('Admin::response_message.chat.message_sent'),
                'data' => $message,
            ];

        }


        /**
         * Fetch all messages for a given chat.
         * 
         * @param \Illuminate\Http\Request $request The HTTP request instance containing the chat ID.
         * @return array An associative array with the following keys:
         */
        public function fetchAllMessages($request)
        { 
            // Retrieve all chat messages along with related chat details, message files, and sender information.
            $chat_message = ChatMessages::with([
                'chats',
                'chatMessageFiles',
                'sender'
            ])->get()->toArray();
            
            // Return the results in a structured array
            if($chat_message){
                return [
                    'status' => true,
                    'message' => __('Admin::response_message.chat.message_showing'),
                    'data' => $chat_message,
                ];
            }else{
                return [
                    'status' => false,
                    'message' => __('Admin::response_message.chat.message_not_found'),
                ];
            }

        }

        /**
         * Retrieve a single chat along with its related messages, users, and files.
         *
         * @param \Illuminate\Http\Request $request The HTTP request instance containing the `chat_id`.
         * @return array An associative array with the following keys:
         * 
         */
        public function getSingleChatMessages($request)
        {
            // Retrieve the chat ID from the request
            $chat_id = $request->chat_id;

            // Find the chat by its ID, including related admin users, students, chat messages, message files, and senders.
            $chat = Chats::with([
                'adminUsers',
                'students',
                'chatMessages',
                'chatMessages.chatMessageFiles',
                'chatMessages.sender'
            ])->find($chat_id);
            
            // Return the results in a structured array
            if($chat){
                return [
                    'status' => true,
                    'message' => __('Admin::response_message.chat.messages'),
                    'data' => $chat,
                ];
            }else{
                return [
                    'status' => false,
                    'message' => __('Admin::response_message.chat.message_not_found'),
                ];
            }

        }


        /**
         * Retrieves all chat records associated with the currently authenticated admin user.
         *
         * @return array An associative array containing:
         */
        public function getAllMyChat()
        {
            $user = Auth::guard('admin-api')->user();
            $login_user_id = $user->id;

            $chat = Chats::whereHas('adminUsers',function($query) use ($login_user_id){
                $query->where('admin_users.id',$login_user_id);
            })->with([
                'adminUsers',
                'students',
                'chatMessages',
                'chatMessages.chatMessageFiles',
                'chatMessages.sender'
            ])->get();
            
            // Return the results in a structured array
            if($chat){
                return [
                    'status' => true,
                    'message' => __('Admin::response_message.chat.messages'),
                    'data' => $chat,
                ];
            }else{
                return [
                    'status' => false,
                    'message' => __('Admin::response_message.chat.message_not_found'),
                ];
            }
        }
        
    }
?>