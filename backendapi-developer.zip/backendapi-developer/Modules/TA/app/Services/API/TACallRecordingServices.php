<?php

namespace Modules\TA\Services\API;
use Modules\Admin\Models\AdminUsers;
use Modules\Admin\Models\TACoachScheduling;
use Carbon\Carbon;
use Auth;

class TACallRecordingServices
{
    public function getAllCallRecordingDateWise($request)
    {
        // Get the ID of the currently authenticated ta
        $current_date = Carbon::now('UTC')->format('Y-m-d');
        $current_time = Carbon::now('UTC')->format('H:i:s');

        $current_date =$request->date;
        $current_time = Carbon::now('UTC')->format('H:i:s');
        $user_id = Auth::guard('admin-api')->user()->id;

        
        $db_data = TACoachScheduling::with(['students','PlatformToolDetails','PlatformMeetingDetails'])
            ->where('admin_user_id', $user_id)
            ->where('is_deleted', false)
            ->where('date', $current_date)
            ->get()
            ->map(function ($item) use ($current_time) {
        // $db_data = TACoachScheduling::with(['students', 'PlatformToolDetails', 'PlatformMeetingDetails'])
        //     ->where('admin_user_id', $user_id)
        //     ->where('is_deleted', false)
        //     ->when($current_date === $item->date, function ($query) use ($current_time) {
        //         return $query->whereTime('end_time', '<', $current_time); // Assuming 'end_time' is the column name for end time
        //     })
        //     ->whereDate('date', '<=', $current_date) // Fetch records from today or past
        //     ->get()
        //     ->map(function ($item) use ($current_time) {
                // Remove unwanted fields
                unset($item->series);
                unset($item->is_deleted);
                unset($item->created_at);
                unset($item->updated_at);
                unset($item->created_by);
                unset($item->updated_by);
                $item->students->map(function ($student) {
                    unset($student->created_by);
                    unset($student->updated_by);
                    unset($student->created_at);
                    unset($student->updated_at);
                    return $student;
                });

                return $item;
            });

        // Convert the collection to an array
        $db_data = $db_data->toArray();
        
        if ($db_data) {

            return [
                'status' => true,
                'message' => __('Admin::response_message.ta_call_records.call_recording_retrieve'),
                'data' => $db_data,
            ];
        } else {

            return [
                'status' => false,
                'message' => __('Admin::response_message.ta_call_records.call_recording_not_found'),
            ];
        }
    }

    public function updateTASessionNotes($request,$id)
    {
        // Get the ID of the currently authenticated ta
        $ta_id = Auth::guard('admin-api')->user()->id;
        $session_notes=$request->session_notes;
        // print_r($session_notes);
        // die;
        // Query the database for sessions associated with the ta
        $db_data = TACoachScheduling::where('id', $id)
            ->first();
        if ($db_data) {
                $db_data->update(['session_meeting_notes' => $session_notes]);
            return [
                'status' => true,
                'message' => __('Admin::response_message.ta_call_records.call_recording_note_upload'),
                'data' => $db_data,
            ];
        } else {

            return [
                'status' => false,
                'message' => __('Admin::response_message.ta_call_records.call_recording_not_found'),
            ];
        }

    }

    public function updateTASessionRecoding($request,$id)
    {
        // Get the ID of the currently authenticated ta
        $session_recording_url=$request->session_recording_url;
        $ta_id = Auth::guard('admin-api')->user()->id;

        // Query the database for sessions associated with the ta
        $db_data = TACoachScheduling::where('id', $id)
            ->first();
            
        if ($db_data) {
                $db_data->update([
                    'session_recording_url'=>$session_recording_url       
                ]); 
            return [
                'status' => true,
                'message' => __('Admin::response_message.ta_call_records.call_recording_upload'),
                'data' => $db_data,
            ];
        } else {

            return [
                'status' => false,
                'message' => __('Admin::response_message.ta_call_records.call_recording_not_found'),
            ];
        }

    }
}
