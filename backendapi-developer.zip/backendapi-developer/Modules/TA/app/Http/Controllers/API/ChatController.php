<?php

namespace Modules\TA\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

use Modules\TA\Services\API\ChatServices;
use Modules\Admin\Helpers\APIResponse\APIResponseHelper;

use App\Events\ChatMessageSent;
use Modules\Admin\Models\ChatMessages;
use Modules\Admin\Models\ChatMessageFiles;
use Modules\Admin\Models\AdminUsers;
use Auth;

class ChatController extends Controller
{
    private $chat_services;
    private $api_response_helper;

    /**
     * Constructor for initializing ProfileController.
     *
     * @param ChatServices $chat_services Injected service for profile operations.
     * @param APIResponseHelper $api_response_helper Injected helper for API response handling.
     */
    public function __construct(
        ChatServices $chat_services,
        APIResponseHelper $api_response_helper,
    ){
        // Initialize HTTP status codes for various responses
        $this->status_code = config('global_constant.STATUS_CODE.SUCCESS');
        $this->not_found_status_code = config('global_constant.STATUS_CODE.NOT_FOUND');
        $this->bad_request_status_code = config('global_constant.STATUS_CODE.BAD_REQUEST');
        $this->credentials_valid_status_code = config('global_constant.STATUS_CODE.CREDENTIALS_VALID');
        $this->no_content_status_code = config('global_constant.STATUS_CODE.NO_CONTENT');
        $this->unprocessable_entity_status_code =  config('global_constant.STATUS_CODE.UNPROCESSABLE_ENTITY');
        $this->new_resource_create =  config('global_constant.STATUS_CODE.NEW_RESOURCE_CREATE');
        $this->server_error = config('global_constant.STATUS_CODE.SERVER_ERROR');

        // Injected dependencies initialization
        $this->chat_services = $chat_services;
        $this->api_response_helper = $api_response_helper;
    }


    /**
     * Handles the creation of a new chat.
     *
     * @param \Illuminate\Http\Request $request The HTTP request instance containing the data to create a new chat.
     * @return \Illuminate\Http\JsonResponse A JSON response with the result of the chat creation.
     */
    public function createChat(Request $request)
    {
        try {
            // Attempt to create a new chat using the chat services
            $create_new_chat = $this->chat_services->createNewChat($request);

            // Generate and return the API response using the response helper
            return $this->api_response_helper::generateAPIResponse(
                $create_new_chat,
                $this->new_resource_create,
                $this->not_found_status_code 
            );

        } catch (\Exception $e) {
            // Handle any exceptions that occur during the execution
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(), // Optionally include the error message for debugging
            ],   $this->server_error,); // You can adjust the status code based on the type of error encountered
        }
    }


    /**
     * Adds one or more users to a specified chat.
     *
     * @param \Illuminate\Http\Request $request The HTTP request instance containing the data to add users to a chat.
     * @return \Illuminate\Http\JsonResponse A JSON response with the result of adding users to the chat.
     */
    public function addUserToChat(Request $request)
    {
        try {
            
            // Attempt to add users to the chat using the chat services
            $create_new_chat = $this->chat_services->addUserToNewChat($request);

            // Generate and return the API response using the response helper
            return $this->api_response_helper::generateAPIResponse(
                $create_new_chat,
                $this->new_resource_create,
                $this->not_found_status_code 
            );

        } catch (\Exception $e) {
            // Handle any exceptions that occur during the execution
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(), // Optionally include the error message for debugging
            ],   $this->server_error,); // You can adjust the status code based on the type of error encountered
        }
    }

    /**
     * Handles sending chat messages by calling the chat service and generating an API response.
     *
     * @param \Illuminate\Http\Request $request The incoming request containing the message details.
     * @return \Illuminate\Http\JsonResponse The JSON response with the status of the message sending operation.
     */
    public function sendMessage(Request $request)
    {

        try {
            // Call the chat service to send the message
            $send_message = $this->chat_services->sendMessages($request);

            // Generate and return the API response using the response helper
            return $this->api_response_helper::generateAPIResponse(
                $send_message,
                $this->new_resource_create,
                $this->not_found_status_code 
            );

        } catch (\Exception $e) {
            // Handle any exceptions that occur during the execution
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(), // Optionally include the error message for debugging
            ],   $this->server_error,); // You can adjust the status code based on the type of error encountered
        }
    }

    /**
     * Fetch and return messages based on the request parameters.
     * 
     * @param \Illuminate\Http\Request $request The HTTP request instance containing parameters for fetching messages.
     * @return \Illuminate\Http\JsonResponse A JSON response with the following structure:
     */
    public function fetchMessages(Request $request)
    {
        try {
            // Fetch messages by calling the chat services
            $fetch_message = $this->chat_services->fetchAllMessages($request);

            // Generate and return the API response using the response helper
            return $this->api_response_helper::generateAPIResponse(
                $fetch_message,
                $this->status_code,
                $this->not_found_status_code 
            );

        } catch (\Exception $e) {
            // Handle any exceptions that occur during the execution
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(), // Optionally include the error message for debugging
            ],   $this->server_error,); // You can adjust the status code based on the type of error encountered
        }
    }

    
    /**
     * Retrieve and return a single chat along with its associated messages and related data.
     *
     * @param \Illuminate\Http\Request $request The HTTP request instance containing the parameters to identify the chat.
     * @return \Illuminate\Http\JsonResponse A JSON response with the following structure:
     * 
     */
    public function getSingleChat(Request $request)
    {
        try {
            // Retrieve chat details by calling the chat services
            $fetch_message = $this->chat_services->getSingleChatMessages($request);

            // Generate and return the API response using the response helper
            return $this->api_response_helper::generateAPIResponse(
                $fetch_message,
                $this->status_code,
                $this->not_found_status_code 
            );

        } catch (\Exception $e) {
            // Handle any exceptions that occur during the execution
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(), // Optionally include the error message for debugging
            ],   $this->server_error,); // You can adjust the status code based on the type of error encountered
        }
    }


    /**
     * Retrieves and returns all chat records associated with the currently authenticated user.
     *
     * @return \Illuminate\Http\JsonResponse A JSON response containing:
     */
    public function getMyChat()
    {
        try {
            $get_all_my_chat = $this->chat_services->getAllMyChat();

            // Generate and return the API response using the response helper
            return $this->api_response_helper::generateAPIResponse(
                $get_all_my_chat,
                $this->status_code,
                $this->not_found_status_code 
            );

        } catch (\Exception $e) {
            // Handle any exceptions that occur during the execution
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(), // Optionally include the error message for debugging
            ],   $this->server_error,); // You can adjust the status code based on the type of error encountered
        }
    }
}
