<?php

namespace Modules\TA\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class SchedulesCallRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {
        return [
            'meeting_name' => 'required|string',
            'meeting_name'=> 'required|string',
            'platform_id' => 'required|integer',
            'message'=>'required|string',
            'schedule_date' => 'required|date',
            'start_time' => 'required|date_format:H:i:s',
            'end_time' => 'required|date_format:H:i:s|after:from_time',
            'timezone_id' => 'required|integer',
            'event_status' => 'required|string',
            'studentId' => 'array', // studentId should be an array
            'studentId.*' => 'integer', // Each studentId in the array should be an integer
            'batchId' => 'array', // batchId should be an array
            'batchId.*' => 'integer', // Each batchId in the array should be an integer
        ];

    } 

    public function messages()
    {
        return [
            'meeting_name.required' =>  __('Admin::validation_message.ta.meeting_name_required'),
            'meeting_name.string' => __('Admin::validation_message.ta.meeting_name_string'),
            'message.required' =>  __('Admin::validation_message.ta.message_required'),
            'message.string' => __('Admin::validation_message.ta.message_string'),
            'platform_id.required' => __('Admin::validation_message.ta.platform_id_required'),
            'platform_id.integer' => __('Admin::validation_message.ta.platform_id_integer'),
            'schedule_date.required' => __('Admin::validation_message.ta.schedule_date_required'),
            'schedule_date.date' => __('Admin::validation_message.ta.schedule_date_date'),
            'start_time.required' => __('Admin::validation_message.ta.start_time_required'),
            'start_time.date_format' =>  __('Admin::validation_message.ta.start_time_date_format'),
            'end_time.required' => __('Admin::validation_message.ta.end_time_required'),
            'end_time.date_format' => __('Admin::validation_message.ta.end_time_date_format'),
            'end_time.after' => __('Admin::validation_message.ta.end_time_after'),
            'timezone_id.required' => __('Admin::validation_message.ta.timezone_id_required'),
            'timezone_id.integer' => __('Admin::validation_message.ta.timezone_id_integer'),
            'event_status.required' => __('Admin::validation_message.ta.event_status_required'),
            'event_status.string' => __('Admin::validation_message.ta.event_status_string'),
            'studentId.array' => __('Admin::validation_message.ta.studentId_array'),
            'studentId.*.integer' => __('Admin::validation_message.ta.studentId_integer'),
            'batchId.array' => __('Admin::validation_message.ta.batchId_array'),
            'batchId.*.integer' =>__('Admin::validation_message.ta.batchId_integer'),
        ];
    }
}
