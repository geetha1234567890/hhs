<?php
    namespace Modules\Coach\Services\API;

    use Illuminate\Support\Facades\Hash;
    use Auth;
    use Crypt;

    use Modules\Admin\Models\TACoachSlots;
    use Modules\Admin\Models\AdminUsers;
    use Modules\Admin\Models\TACoachScheduling;
    use Modules\Admin\Models\CallRequest;
    use Carbon\Carbon;

class CoachCallRequestServices
{

    /**
     * Retrieve all call requests assigned to the currently authenticated coach, excluding rejected requests.
     *
     * @return array - An associative array containing the status, message, and data of the call requests.
     * 
    */
    public function getAllCallRequest()
    {
        // Get the ID of the currently authenticated coach
        $id = Auth::guard('admin-api')->user()->id;

        // Query the database for sessions associated with the coach
        $db_data = CallRequest::with(['student','ta_and_coaches'])->where('receiver_id', $id)
        ->where('status', '!=', 'Reject')
        ->get();
        
        // Convert the collection of sessions to an array
        $response = $db_data->map(function($request) {
            return [
               
                'id' => $request->id,
                'sender' => [
                    'id' => $request->student->id,
                    'name' => $request->student->name,
                    'enrollment_id' => $request->student->enrollment_id,
                ],
                'receiver' => [
                    'id' => $request->ta_and_coaches->id,
                    'name' => $request->ta_and_coaches->name,
                ],
                'meeting_link' => $request->meeting_link,
                'message' => $request->message,
                'date' => $request->date,
                'start_time' => $request->start_time,
                'end_time' => $request->end_time,
                'status' => $request->status,
            ];
        });
        // Check if sessions were found
        if ($response) {

            return [
                'status' => true,
                'message' => __('Admin::response_message.coach_call_request.call_request_retrieve'),
                'data' => $response,
            ];
        } else {

            return [
                'status' => false,
                'message' => __('Admin::response_message.coach_call_request.call_request_not_found'),
            ];
        }
    }


    /**
     * Approve a specific call request for the currently authenticated coach.
     *
     * @param int $id The unique ID of the call request to be approved.
     * 
     * @return array An associative array containing the result of the approval process. The structure of the returned array is as follows:
     * 
     */
    public function approveCallRequest($id)
    {
        // Get the ID of the currently authenticated coach
        $coach_id = Auth::guard('admin-api')->user()->id;

        // Query the database for sessions associated with the coach
        $db_data = CallRequest::where('id', $id)
            ->where('receiver_id', $coach_id)
            ->first();
        if ($db_data) {
                $db_data->update(['status' => 'Approved']);
            return [
                'status' => true,
                'message' => __('Admin::response_message.coach_call_request.call_request_approve'),
                'data' => $db_data,
            ];
        } else {

            return [
                'status' => false,
                'message' => __('Admin::response_message.coach_call_request.call_request_not_found'),
            ];
        }

    }
 

    /**
     * Deny a specific call request for the currently authenticated coach and provide a reason for rejection.
     *
     * @param \Illuminate\Http\Request $request The HTTP request instance containing the rejection reason.
     * @param int $id The unique ID of the call request to be rejected.
     * 
     * @return array An associative array containing the result of the rejection process. The structure of the returned array is as follows:
     * 
     */
    public function deniedCallRequest($request,$id)
    {
        // Get the ID of the currently authenticated coach
        $reject_reason=$request->reject_reason;
        $coach_id = Auth::guard('admin-api')->user()->id;

        // Query the database for sessions associated with the coach
        $db_data = CallRequest::where('id', $id)
            ->where('receiver_id', $coach_id)
            ->first();
            
        if ($db_data) {
                $db_data->update([
                    'reject_reason'=>$reject_reason,
                    'status' => 'Reject',
                        
                ]); 
            return [
                'status' => true,
                'message' => __('Admin::response_message.coach_call_request.call_request_reject'),
                'data' => $db_data,
            ];
        } else {

            return [
                'status' => false,
                'message' => __('Admin::response_message.coach_call_request.call_request_not_found'),
            ];
        }

    }

}
