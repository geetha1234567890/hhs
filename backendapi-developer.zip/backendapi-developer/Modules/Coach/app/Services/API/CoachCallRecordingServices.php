<?php

namespace Modules\Coach\Services\API;
use Modules\Admin\Models\AdminUsers;
use Modules\Admin\Models\TACoachScheduling;
use Carbon\Carbon;
use Auth;

class CoachCallRecordingServices
{

    public function getAllCallRecordingDateWise($request)
    {
        // Get the ID of the currently authenticated coach
        $current_date = Carbon::now('UTC')->format('Y-m-d');
        $current_time = Carbon::now('UTC')->format('H:i:s');

        $current_date =$request->date;
        $current_time = Carbon::now('UTC')->format('H:i:s');
        $user_id = Auth::guard('admin-api')->user()->id;

        $db_data1 = TACoachScheduling::with(['students','PlatformToolDetails','PlatformMeetingDetails'])
            ->where('admin_user_id', $user_id)
            ->where('is_deleted', false)
            ->where('date', $current_date)
            ->get();
            printf($db_data1);
            die;
        $db_data = TACoachScheduling::with(['students','PlatformToolDetails','PlatformMeetingDetails'])
            ->where('admin_user_id', $user_id)
            ->where('is_deleted', false)
            ->where('date', $current_date)
            ->get()
            ->map(function ($item) use ($current_time) {
                // Remove unwanted fields
                unset($item->series);
                unset($item->is_deleted);
                unset($item->created_at);
                unset($item->updated_at);
                unset($item->created_by);
                unset($item->updated_by);

                // if ($item->start_time <= $current_time && $item->end_time >= $current_time) {
                //     $item->event_status = 'join meeting';
                // } elseif ($item->end_time < $current_time) {
                //     $item->event_status = 'call expired';
                // } else {
                //     $item->event_status = 'call schedule';
                // }
                // Optionally, you can do the same for the students relationship
                $item->students->map(function ($student) {
                    unset($student->created_by);
                    unset($student->updated_by);
                    unset($student->created_at);
                    unset($student->updated_at);
                    return $student;
                });

                return $item;
            });

        // Convert the collection to an array
        $db_data = $db_data->toArray();
        
        // Check if sessions were found
        if ($db_data) {

            return [
                'status' => true,
                'message' => __('Admin::response_message.coach_call_records.call_recording_retrieve'),
                'data' => $db_data,
            ];
        } else {

            return [
                'status' => false,
                'message' => __('Admin::response_message.coach_call_records.call_recording_not_found'),
            ];
        }
    }

    public function updateCoachSessionNotes($request,$id)
    {
        // Get the ID of the currently authenticated coach
        $coach_id = Auth::guard('admin-api')->user()->id;
        $session_notes=$request->session_notes;
        // print_r($session_notes);
        // die;
        // Query the database for sessions associated with the coach
        $db_data = TACoachScheduling::where('id', $id)
            ->first();
        if ($db_data) {
                $db_data->update(['session_meeting_notes' => $session_notes]);
            return [
                'status' => true,
                'message' => __('Admin::response_message.coach_call_records.call_recording_note_upload'),
                'data' => $db_data,
            ];
        } else {

            return [
                'status' => false,
                'message' => __('Admin::response_message.coach_call_records.call_recording_not_found'),
            ];
        }

    }

    public function uploadCoachSessionRecoding($request,$id)
    {
        // Get the ID of the currently authenticated coach
        $session_recording_url=$request->session_recording_url;
        $coach_id = Auth::guard('admin-api')->user()->id;

        // Query the database for sessions associated with the coach
        $db_data = TACoachScheduling::where('id', $id)
            ->first();
            
        if ($db_data) {
                $db_data->update([
                    'session_recording_url'=>$session_recording_url       
                ]); 
            return [
                'status' => true,
                'message' => __('Admin::response_message.coach_call_records.call_recording_upload'),
                'data' => $db_data,
            ];
        } else {

            return [
                'status' => false,
                'message' => __('Admin::response_message.coach_call_records.call_recording_not_found'),
            ];
        }

    }
}
