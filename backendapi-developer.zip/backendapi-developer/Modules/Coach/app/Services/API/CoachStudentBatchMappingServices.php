<?php

namespace Modules\Coach\Services\API;

use Illuminate\Support\Facades\Hash;

use Modules\Admin\Models\AdminUsers;
use Modules\Admin\Models\TACoachStudentMapping;
use Modules\Admin\Models\TACoachBatchMapping;
use Modules\Admin\Models\StudentBatchMapping;
use Modules\Admin\Models\Student;
use Modules\Admin\Models\Batch;

use Auth;
use Crypt;

class CoachStudentBatchMappingServices
{
    
    /**
     * Get the list of students assigned to the currently authenticated admin user, including their batches and packages.
     *
     * @param \Illuminate\Http\Request $request - The HTTP request instance (not used in the method).
     * @return array - An array containing the status, message, and data of the assigned students.
     * 
     */
    public function getAssignStudentsData()
    {
        $adminUserId = Auth::guard('admin-api')->user()->id;
        
        $mappings = TACoachStudentMapping::with(['AdminUsers', 'Student.studentBatchMappings.Batch'])
                    ->where('is_deleted', false)
                    ->where('admin_user_id', $adminUserId)
                    ->get();

        $data = $mappings->map(function($mapping) {
            $student = $mapping->student;
            $batches = $student->studentBatchMappings->map(function ($studentBatchMapping) {
                return [
                    'batch_id' => $studentBatchMapping->batch->id,
                    'batch_name' => $studentBatchMapping->batch->name,
                    'branch' => [
                            'id' => $studentBatchMapping->batch->parent->id,
                            'name' =>$studentBatchMapping->batch->parent->name
                    ],
                    'is_active' => $studentBatchMapping->batch->is_active,
                ];
            });

            return [
                'id' => $mapping->id,
                'ta' => [
                    'id' => $mapping->AdminUsers->id,
                    'name' => $mapping->AdminUsers->name,
                ],
                'student' => [
                    'id' => $student->id,
                    'name' => $student->name,
                    'enrollment_id' => $student->enrollment_id,
                    'packages' => $student->packages->map(function ($package) {
                        return [
                            'id' => $package->id,
                            'package_id' => $package->package_id,
                            'name' => $package->package_name,
                        ];
                    }),
                    'batches' => $batches,
                ],
                'is_active' => $mapping->is_active,
            ];
        });

        if ($data) {
            return [
                'status' => true,
                'message' => __('Admin::response_message.mappings.assignstudents_retrive'),
                'data' => $data,
            ];
        } else {
            return [
                'status' => false,
                'message' => __('Admin::response_message.mappings.assignstudents_notretrive'),
            ];
        }
    }


    /**
     * Retrieve the list of batches assigned to the currently authenticated admin user, including batch and TA (admin user) details.
     *
     * @param \Illuminate\Http\Request $request The HTTP request instance. This parameter is not used within the method but is required for method signature consistency.
     * @return array An associative array containing the result of the data retrieval process. The structure of the returned array is as follows:
     * 
     */
    public function getAssignBatchesData()
    {
        $adminUserId = Auth::guard('admin-api')->user()->id;
        $mappings = TACoachBatchMapping::with(['AdminUsers', 'batch'])
                    ->where('is_deleted', false)
                    ->where('admin_user_id', $adminUserId)
                    ->get();

        $data = $mappings->map(function($mapping) {
            return [
                'id' => $mapping->id,
                'ta' => [
                    'id' => $mapping->AdminUsers->id,
                    'name' => $mapping->AdminUsers->name,
                ],
                'batch' => [
                    'id' => $mapping->batch->id,
                    'name' => $mapping->batch->name,
                    'branch' => [
                        'id' => $mapping->batch->parent->id,
                        'name' => $mapping->batch->parent->name
                    ],
                ],
                'is_active' => $mapping->is_active,
                // 'is_deleted' => $mapping->is_deleted,
            ];
        });

        if ($data) {
            return [
                'status' => true,
                'message' => __('Admin::response_message.mappings.assigbatch_retrive'),
                'data' => $data,
            ];
        } else {
            return [
                'status' => false,
                'message' => __('Admin::response_message.mappings.assigbatch_notretrive'),
            ];
        }
    }
    
}
