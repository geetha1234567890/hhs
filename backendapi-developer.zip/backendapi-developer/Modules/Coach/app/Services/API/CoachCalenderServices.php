<?php     
    namespace Modules\Coach\Services\API;

    use Illuminate\Support\Facades\Hash;
    use Auth;
    use Crypt;

    use Modules\Admin\Models\TACoachSlots;
    use Modules\Admin\Models\AdminUsers;
    use Modules\Admin\Models\TACoachScheduling;
    use Modules\Admin\Models\TACoachBatchScheduling;
    use Modules\Admin\Models\Student;
    use Modules\Admin\Models\Batch;
    use Modules\Admin\Models\StudentBatchMapping;
    use Modules\Admin\Models\TACoachStudentScheduling;
    use Modules\Admin\Models\Leaves;
    use Carbon\Carbon;

    class CoachCalenderServices
    {


        /**
         * Retrieve time slots associated with the currently authenticated coach.
         *
         * @return array An array containing status, message, and slots data.
         *               - status: boolean, indicating success or failure of the operation.
         *               - message: string, a message describing the outcome of the operation.
         *               - data: array, containing time slot information if successful.
         */
        public function getSlots()
        {
            // Get the ID of the currently authenticated coach
            $id = Auth::guard('admin-api')->user()->id;

            // Query the database for time slots associated with the coach
            $slots = TACoachSlots::with(['taCoachScheduling','taCoachScheduling.students','taCoachScheduling.batch','leaves'])
            ->where('admin_user_id', $id)
            ->orderBy('slot_date')
            ->orderBy('from_time')
            ->get();

            // Convert the collection of slots to an array
            $slots = $slots->toArray();

            // Check if slots were found
            if ($slots) {

                return [
                    'status' => true,
                    'message' => __('Admin::response_message.coach_calendor.slots_retrieve'),
                    'data' => $slots,
                ];
            } else {

                return [
                    'status' => false,
                    'message' => __('Admin::response_message.coach_calendor.slots_not_found'),
                ];
            }

        }

        /**
         * Retrieve all available time slots for the authenticated coach on a specific date.
         *
         * @param \Illuminate\Http\Request $request The incoming request containing the date for which slots are to be fetched.
         * @return array An array containing the status, message, and data (slots) if found.
         */
        public function getSlotsByDate($request)
        {
            // Get the ID of the currently authenticated coach
            $id = Auth::guard('admin-api')->user()->id;

            // Extract the date from the request
            $date = Carbon::parse($request->date);
            // Query the database for time slots associated with the coach
            $slots = TACoachSlots::with(['taCoachScheduling','leaves'])
            ->where('admin_user_id', $id)
            ->where('slot_date', $date)
            ->orderBy('from_time')
            ->whereDoesntHave('leaves')
            ->get();

            // Convert the collection of slots to an array
            $slots = $slots->toArray();

            // Check if slots were found
            if ($slots) {

                return [
                    'status' => true,
                    'message' => __('Admin::response_message.coach_calendor.slots_retrieve'),
                    'data' => $slots,
                ];
            } else {

                return [
                    'status' => false,
                    'message' => __('Admin::response_message.coach_calendor.slots_not_found'),
                ];
            }

        }

        public function getSlotsForSpecificUser($request)
        {

            // Retrieve the admin user ID from the request
            $admin_user_id = Auth::guard('admin-api')->user()->id;
            // Parse the start date and end date from the request
            $start_date = Carbon::parse($request->start_date)->toDateString();
            $end_date = Carbon::parse($request->end_date)->toDateString();

            $slots = TACoachSlots::with('leaves')->where('admin_user_id', $admin_user_id)
            ->whereBetween('slot_date', [$start_date, $end_date]) // Check if slot_date is between start_date and end_date
            ->whereDoesntHave('leaves')
            ->orderBy('slot_date')                                // Order the results by slot_date in ascending order
            ->get(); 

            // Convert the collection to array for easier manipulation
            $slots = $slots->toArray();

            // Check if slots were found
            if ($slots) {
                // Return success response with slots data
                return [
                    'status' => true,
                    'message' => __('Admin::response_message.slots.slot_retrieve'),
                    'data' => $slots,
                ];
            } else {
                // Return failure response if no slots were found
                return [
                    'status' => false,
                    'message' => __('Admin::response_message.slots.slot_not_found'),
                ];
            }
        }

        /**
         * Retrieve all sessions data associated with the currently authenticated coach.
         *
         * @return array An array containing status, message, and sessions data.
         *               - status: boolean, indicating success or failure of the operation.
         *               - message: string, a message describing the outcome of the operation.
         *               - data: array, containing session information if successful.
         */
        public function getAllSessionsData()
        {
            // Get the ID of the currently authenticated coach
            $id = Auth::guard('admin-api')->user()->id;

            // Query the database for sessions associated with the coach
            $schedules = TACoachScheduling::with(['taCoachSlots','students','batch'])
            ->where('admin_user_id', $id)
            ->where('is_deleted', false)
            ->orderBy('date')
            ->orderBy('start_time')
            ->get();
            
            // Convert the collection of sessions to an array
            $schedules = $schedules->toArray();

            // Check if sessions were found
            if ($schedules) {

                return [
                    'status' => true,
                    'message' => __('Admin::response_message.coach_calendor.slots_session_retrieve'),
                    'data' => $schedules,
                ];
            } else {

                return [
                    'status' => false,
                    'message' => __('Admin::response_message.coach_calendor.slots_session_not_found'),
                ];
            }

        } 

        public function getCoachSchedulesRecords($request)
        {
            // Extract admin user ID and data from request input
            $admin_user_id = Auth::guard('admin-api')->user()->id;
            $data = $request->input('data');
            
            // Initialize an empty response array
            $response = [];

            // Loop through each data entry to fetch matching records
            foreach ($data as $item) {

                $date = $item['date'];
                $slotId = $item['slot_id'];
                $startTime = $item['start_time'];
                $endTime = $item['end_time'];

                // Query to fetch TA scheduling records based on criteria
                $records = TACoachScheduling::with(['students.studentBatchMappings.batch'])
                    ->where('admin_user_id', $admin_user_id)
                    ->where('slot_id', $slotId)
                    ->where('is_deleted', false)
                    ->whereDate('date', $date)
                    ->whereTime('start_time', '>=', $startTime)
                    ->whereTime('end_time', '<=', $endTime)
                    ->get();

                $formattedRecords = $records->map(function ($record) {
                    $students = $record->students->map(function ($student) {
                        return [
                            'student_id' => $student->id,
                            'student_name' => $student->name,
                            'packages' => $student->packages->map(function ($package) {
                                return [
                                    'id' => $package->id,
                                    'package_id' => $package->package_id,
                                    'name' => $package->package_name,
                                ];
                            }),
                            'enrollment_id' => $student->enrollment_id,
                            'is_active' => $student->is_active,
                            'batches' => $student->studentBatchMappings->map(function ($mapping) {
                                return [
                                    'batch_id' => $mapping->batch->id,
                                    'batch_name' => $mapping->batch->name,
                                    'branch' => [
                                        'id' => $mapping->batch->parent->id,
                                        'name' => $mapping->batch->parent->name
                                    ],
                                    'is_active' => $mapping->batch->is_active
                                ];
                            })
                        ];
                    });

                    return [
                        'id' => $record->id,
                        'admin_user_id' => $record->admin_user_id,
                        'meeting_name' => $record->meeting_name,
                        'meeting_url' => $record->meeting_url,
                        'date' => $record->date,
                        'slot_id' => $record->slot_id,
                        'start_time' => $record->start_time,
                        'end_time' => $record->end_time,
                        'timezone_id' => $record->timezone_id,
                        'is_active' => $record->is_active,
                        'event_status' => $record->event_status,
                        'session_type' => $record->session_type,
                        'is_deleted' => $record->is_deleted,
                        'created_by' => $record->created_by,
                        'updated_by' => $record->updated_by,
                        'Students' => $students
                    ];
                });

                // Merge fetched records into response array
                $response = array_merge($response, $formattedRecords->toArray());
            }
        
            // Prepare and return response based on fetched records
            if ($response) {
                return [
                    'status' => true,
                    'message' => __('Admin::response_message.schedules.schedule_retrieve'),
                    'data' => $response,
                ];
            } else {
                return [
                    'status' => false,
                    'message' => __('Admin::response_message.schedules.schedule_not_found'),
                ];
            }
        }


        public function UpdateSchedules($request , $id)
        { 
            // Extract request parameters
            $adminUserId = Auth::guard('admin-api')->user()->id;
            $start_date = Carbon::parse($request->schedule_date);
            $platform_id = $request->platform_id;
            $message = $request->message;
            //$slot_id = $request->slot_id;
            $start_time = $request->start_time;
            $end_time = $request->end_time;
            $timezone_id = $request->timezone_id;
            $event_status = $request->event_status;

            // Validate slotDate against today's date
            if ($start_date->isBefore(Carbon::today())) {
                return [
                    'status'=>false,
                    'message' => __('Admin::response_message.schedules.schedule_start_date'),
                ];
            }
            $existingSchedule = TACoachScheduling::where('admin_user_id', $adminUserId)
                                            ->where('id', '!=', $id)
                                            ->where('is_deleted', false)
                                            ->get();
                
        
                foreach ($existingSchedule as $schedule) {
                    if (($start_time >= $schedule->start_time && $start_time < $schedule->end_time) ||
                        ($end_time > $schedule->start_time && $end_time <= $schedule->end_time) ||
                        ($start_time <= $schedule->start_time && $end_time >= $schedule->end_time)) {

                        return [
                            'status'=>false,
                            'message' => __('Admin::response_message.schedules.schedule_clash_message', ['date' => $start_date . ' ' . $start_time . ' - ' . $end_time]),
                        ];

                    }
                }

            $existingSlot = TACoachSlots::where('admin_user_id', $adminUserId)
                                            ->where('id', $slot_id)
                                            ->where('slot_date', $start_date)
                                            ->get();

            if ($existingSlot->isEmpty()) {
                return [
                    'status' => false,
                    'message' =>  __('Admin::response_message.slots.slot_not_found', ['date' => $start_date]),
                ];
            }
            //die($existingSlot[0]);

            if($existingSlot[0]['from_time'] > $start_time || $existingSlot[0]['to_time'] < $end_time){
                return [
                    'status' => false,
                    'message' => __('Admin::response_message.slots.slot_time_message',[
                        'date' => $start_date,
                        'slot_from_time' => $start_time,
                        'slot_to_time' => $end_time
                    ]
                    ),
                ];
            }

            
            // No clashes found, proceed to create schedules
            $newSchedule = TACoachScheduling::find($id);

            // Return appropriate response based on slot creation result
            if($newSchedule){
                $newSchedule->date = $start_date;
                $newSchedule->slot_id = $slot_id;
                $newSchedule->start_time = $start_time;
                $newSchedule->end_time = $end_time;
                $newSchedule->timezone_id= $timezone_id;
                $newSchedule->event_status = $event_status;
                $newSchedule->save();
                return [
                    'status'=>true,
                    'message' => __('Admin::response_message.schedules.schedule_store'),
                    'data'=>$newSchedule,
                ];
            }else{
                return [
                    'status'=>false,
                    'message' => __('Admin::response_message.schedules.store_schedule_failed'),
                ];
            }

        }

        public function CancelSchedules($id)
        {
            // Find the slot with the given ID
            $schedule = TACoachScheduling::find($id);
        
            if ($schedule) {
                // Update the is_deleted flag to true
                $schedule->is_deleted = true;
                $schedule->event_status = 'cancelled';
                $schedule->is_active = false;
                $schedule_deleted = $schedule->save();
            //ToDO
                // Update the isDeleted flag for all schedules with the same series ID as the deleted slot
                $related_schedules_deleted = TACoachScheduling::where('series', $schedule->series)
                    ->update(['is_deleted' => true]);
            
                return [
                    'status' => true,
                    'message' => __('Admin::response_message.schedules.schedule_deleted'),
                    'data' => $schedule_deleted,
                ];
            } else {
                return [
                    'status' => false,
                    'message' => __('Admin::response_message.schedules.schedule_not_found'),
                ];
            }
        }


        /**
         * Store leave requests for an admin user.
         *
         * @param \Illuminate\Http\Request $request The incoming request containing the leave data.
         * @return array An array containing the status, message, and data (created leave) if successful.
         */
        public function storeLeave($request)
        {
            // Extract request parameters
            $admin_user_id = Auth::guard('admin-api')->user()->id;
            $approve_status = $request->approve_status ?? 1;
            $leave_type = $request->leave_type ?? 'full';
            $message = $request->reason ?? null;
            $leave_data = $request->data;
               
            foreach($leave_data as $data){
                $start_date = Carbon::parse($data['date']);
                $end_date = Carbon::parse($data['date']);
                $start_time = $data['start_time'];
                $end_time = $data['end_time'];
                $slot_id = $data['slot_id'] ?? null;

                //check if given slot id associated with given admin user id

                if($slot_id){
                    $slot = TACoachSlots::where('id',$slot_id)->where('admin_user_id',$admin_user_id)->first();
                    if(!$slot){
                        return [
                            'status' => false,
                            'message' => __('Admin::response_message.leave.slot_not_found'),
                        ];
                    }
                    // Check if leave with the same slot id already exists
                    $existing_leave = Leaves::where('slot_id', $slot_id)->first();
                    if ($existing_leave) {
                        return [
                        'status' => false,
                        'message' => __('Admin::response_message.leave.duplicate_entry'),
                        ];
                    }
                }

                $leave = Leaves::create([
                    'admin_user_id'=>$admin_user_id,
                    'slot_id'=>$slot_id,
                    'start_date'=>$start_date,
                    'end_date'=>$end_date,
                    'start_time'=>$start_time,
                    'end_time'=>$end_time,
                    'approve_status'=>$approve_status,
                    'leave_type'=>$leave_type,
                    'message'=>$message
                ]);
            }

            // Check if leave record creation was successful
            if (isset($leave) && $leave) {
                return [
                    'status'=>true,
                    'message' => __('Admin::response_message.leave.leave_store'),
                    'data'=>$leave,
                ];
            }else{
                return [
                    'status'=>false,
                    'message' => __('Admin::response_message.leave.store_leave_failed'),
                ];
            }

        }

        
        /**
         * Retrieve today's schedule call data.
         *
         * This method gets the current date and time, retrieves the authenticated admin user's ID,
         * and fetches the TA coach slots for today. It checks if any TA is available for the current
         * date and time, and returns the appropriate response.
         *
         * @return array An array containing the status, message, and data (if available).
         */
        public function getTodayScheduleCallData()
        {
            // Get the current date in 'Y-m-d' format
            $current_date = Carbon::now()->format('Y-m-d');
            $current_time = Carbon::now()->format('H:i:s');
            $user_id = Auth::guard('admin-api')->user()->id;

            // Retrieve TA coach slots for the current date and time
            $coach_slots = TACoachSlots::where('admin_user_id', $user_id)
            ->where('slot_date', $current_date)
            ->where('from_time', '<=', $current_time)
            ->where('to_time', '>=', $current_time)
            ->with('taCoachScheduling')
            ->get();

            // Convert the collection to an array
            $coach_slots = $coach_slots->toArray();


            if ($coach_slots) {
                return [
                    'status' => true,
                    'message' => __('Admin::response_message.coach_calendor.coach_slots_retrieve'),
                    'data' => $coach_slots,
                ];
            } else {
                return [
                    'status' => false,
                    'message' => __('Admin::response_message.coach_calendor.coach_slots_not_found'),
                ];
            }
        }


        /**
         * Store new time slots for a coach.
         *
         * @param \Illuminate\Http\Request $request The incoming request containing the data for the new time slots.
         * @return array An array containing the status, message, and data (created slots) if successful.
         */
        public function storeSlots($request)
        {
            // Extract request parameters
            $adminUserId = Auth::guard('admin-api')->user()->id;
            $slotDate = Carbon::parse($request->slot_date);
            $fromTime = $request->from_time;
            $toTime = $request->to_time;
            $endDate = Carbon::parse($request->end_date);
            $weeks = $request->weeks ?? []; // array example: [1,0,0,1,0,1,0]
        
            // Validate slotDate against today's date
            if ($slotDate->isBefore(Carbon::today())) {
                return [
                    'status'=>false,
                    'message' => __('Admin::response_message.slots.slot_start_date'),
                ];
            }

            $potentialDates = [];
        
            // Calculate all dates within the range based on the weeks array
            for ($date = $slotDate; $date->lte($endDate); $date->addDay()) {
                $dayOfWeek = $date->dayOfWeek; // 0 (Sunday) to 6 (Saturday)
                if (isset($weeks[$dayOfWeek]) && $weeks[$dayOfWeek] == 1) {
                    $potentialDates[] = $date->format('Y-m-d');
                }
            }
        
            // Check for slot clashes on all potential dates
            foreach ($potentialDates as $date) {
                $existingSlots = TACoachSlots::where('admin_user_id', $adminUserId)
                                            ->where('slot_date', $date)
                                            ->orderBy('from_time')
                                            ->get();
        
                foreach ($existingSlots as $slot) {
                    if (($fromTime >= $slot->from_time && $fromTime < $slot->to_time) ||
                        ($toTime > $slot->from_time && $toTime <= $slot->to_time) ||
                        ($fromTime <= $slot->from_time && $toTime >= $slot->to_time)) {

                        return [
                            'status'=>false,
                            'message' => __('Admin::response_message.slots.slot_clash_message', ['date' => $date]),
                        ];

                    }
                }
            }
        
            // No clashes found, proceed to create slots
            $created_slots = [];
            $seriesId = null;
        
            foreach ($potentialDates as $date) {
                $newSlot = new TACoachSlots([
                    'admin_user_id' => $adminUserId,
                    'slot_date' => $date,
                    'from_time' => $fromTime,
                    'to_time' => $toTime,
                    'timezone_id' => $request->timezone_id,
                    'created_by' => $request->created_by,
                    'updated_by' => $request->updated_by,
                ]);
                
                $newSlot->save();
        
                // Assign series ID for grouping, ensuring null for the first slot and parent ID for subsequent slots
                if ($seriesId === null) {
                    // If $seriesId is null, set it to the ID of the first created slot
                    $seriesId = $newSlot->id;
                } else {
                    // For subsequent slots, assign the same $seriesId (parent ID)
                    $newSlot->series = $seriesId;
                    $newSlot->save();
                }
        
                $created_slots[] = $newSlot;
            }

            // Return appropriate response based on slot creation result
            if($created_slots){
                return [
                    'status'=>true,
                    'message' => __('Admin::response_message.slots.slot_store'),
                    'data'=>$created_slots,
                ];
            }else{
                return [
                    'status'=>false,
                    'message' => __('Admin::response_message.slots.store_slot_failed'),
                ];
            }

        }


        /**
         * Store new schedules for a coach.
         *
         * @param \Illuminate\Http\Request $request The incoming request containing the data for the new schedules.
         * @return array An array containing the status, message, and data (created schedules) if successful.
         */

    }   
?>