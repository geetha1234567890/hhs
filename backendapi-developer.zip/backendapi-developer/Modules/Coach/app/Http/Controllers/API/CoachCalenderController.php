<?php

namespace Modules\Coach\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Modules\Admin\Models\TACoachSlots;
use Modules\Admin\Models\AdminUsers;
use Modules\Admin\Models\TACoachScheduling;
use Modules\Admin\Models\TACoachBatchScheduling;
use Modules\Admin\Models\TACoachStudentScheduling;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Modules\Admin\Http\Requests\StoreLeaveRequest;
use Auth;

use Modules\Coach\Services\API\CoachCalenderServices;
use Modules\Admin\Helpers\APIResponse\APIResponseHelper;
use Modules\Coach\Http\Requests\SlotByDateRequest;
use Modules\Coach\Http\Requests\StoreSlotsRequest;
use Modules\Coach\Http\Requests\StoreSchedulesRequest;

class CoachCalenderController extends Controller
{
    private $coach_calender_services;
    private $api_response_helper;

    /**
     * Constructor for initializing ProfileController.
     *
     * @param CoachCalenderServices $coach_calender_services Injected service for profile operations.
     * @param APIResponseHelper $api_response_helper Injected helper for API response handling.
     */
    public function __construct(
        CoachCalenderServices $coach_calender_services,
        APIResponseHelper $api_response_helper,
    ){
        // Initialize HTTP status codes for various responses
        $this->status_code = config('global_constant.STATUS_CODE.SUCCESS');
        $this->not_found_status_code = config('global_constant.STATUS_CODE.NOT_FOUND');
        $this->bad_request_status_code = config('global_constant.STATUS_CODE.BAD_REQUEST');
        $this->credentials_valid_status_code = config('global_constant.STATUS_CODE.CREDENTIALS_VALID');
        $this->no_content_status_code = config('global_constant.STATUS_CODE.NO_CONTENT');
        $this->unprocessable_entity_status_code =  config('global_constant.STATUS_CODE.UNPROCESSABLE_ENTITY');
        $this->new_resource_create =  config('global_constant.STATUS_CODE.NEW_RESOURCE_CREATE');
        $this->server_error = config('global_constant.STATUS_CODE.SERVER_ERROR');

        // Injected dependencies initialization
        $this->coach_calender_services = $coach_calender_services;
        $this->api_response_helper = $api_response_helper;
    }

    /**
     * Retrieve all time slots associated with the currently authenticated coach.
     *
     * @return \Illuminate\Http\JsonResponse JSON response containing status, message,
     *                                       and data of time slots.
     */
    public function getAllSlots()
    {

        try {
            // Retrieve time slots using the coach_calendar_services instance
            $get_slots = $this->coach_calender_services->getSlots();

            // Generate and return the API response using the response helper
            return $this->api_response_helper::generateAPIResponse(
                $get_slots,
                $this->status_code,
                $this->not_found_status_code 
            );
        } catch (\Exception $e) {
            // Handle any exceptions that occur during the execution
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(), // Optionally include the error message for debugging
            ],   $this->server_error,); // You can adjust the status code based on the type of error encountered
        }

    }


    /**
     * Handle the incoming request to get all available slots by date.
     *
     * @param SlotByDateRequest $request The incoming request containing the date for which slots are to be fetched.
     * @return \Illuminate\Http\JsonResponse The API response with the available slots or an error message.
     */
    public function getAllSlotByDate(SlotByDateRequest $request)
    {
        try {
            // Validate the request data
            $validatedData = $request->validated();

            // Fetch all available slots using the calendar service
            $get_slots = $this->coach_calender_services->getSlotsByDate($request);

            // Generate and return the API response using the response helper
            return $this->api_response_helper::generateAPIResponse(
                $get_slots,
                $this->status_code,
                $this->not_found_status_code 
            );
        } catch (\Exception $e) {
            // Handle any exceptions that occur during the execution
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(), // Optionally include the error message for debugging
            ],   $this->server_error,); // You can adjust the status code based on the type of error encountered
        }
    }

    public function getSlotsForBetweenDates(Request $request)
    {   
        try {
            // Retrieve all TA coach slots using the service class method
            $get_slots = $this->coach_calender_services->getSlotsForSpecificUser($request);

            // Generate API response based on the retrieved slots
            return $this->api_response_helper::generateAPIResponse(
                $get_slots,
                $this->status_code,
                $this->not_found_status_code 
            );
        } catch (\Exception $e) {
            // Handle any exceptions that occur during the execution
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(), // Optionally include the error message for debugging
            ],   $this->server_error,); // You can adjust the status code based on the type of error encountered
        }
    }

    public function getScheduledRecordsBySlots(Request $request)
    { 
        try {
            // Validate the incoming request data using the validated method from the request class
            // $validatedData = $request->validated();
            
            // Call the service method to retrieve TA schedules records
            $get_schedule_recods = $this->coach_calender_services->getCoachSchedulesRecords($request);

            // Generate an API response based on the result of retrieving schedules
            return $this->api_response_helper::generateAPIResponse(
                $get_schedule_recods,
                $this->status_code,
                $this->not_found_status_code 
            );
        } catch (\Exception $e) {
            // Handle any exceptions that occur during the execution
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(), // Optionally include the error message for debugging
            ],   $this->server_error,); // You can adjust the status code based on the type of error encountered
        }

    }

    public function ReSchedules(Request $request,$id)
    {
        try {
            // Validate the incoming request data
            $validatedData = $request->validate([
                'schedule_date' => 'required|date',
                'slot_id' => 'required|integer',
                'start_time' => 'required|date_format:H:i:s',
                'end_time' => 'required|date_format:H:i:s',
                'timezone_id' => 'required|integer',
                'event_status' => 'required|string'
            ]);
            
            // Store schedules using the service class method
            $update_schedule = $this->coach_calender_services->UpdateSchedules($request,$id);

            // Generate API response based on the result of storing schedules
            return $this->api_response_helper::generateAPIResponse(
                $update_schedule,
                $this->status_code,
                $this->unprocessable_entity_status_code 
            );
        } catch (\Exception $e) {
            // Handle any exceptions that occur during the execution
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(), // Optionally include the error message for debugging
            ],   $this->server_error,); // You can adjust the status code based on the type of error encountered
        }
        
    }

    public function CancelSchedule($id)
    {
        try {
            // Attempt to delete the schedule using the ta_coach_schedules_services
            $delete_schedule = $this->coach_calender_services->CancelSchedules($id);

            // Generate and return the API response based on the result of the delete operation
            return $this->api_response_helper::generateAPIResponse(
                $delete_schedule,
                $this->no_content_status_code,
                $this->not_found_status_code 
            );

        } catch (\Exception $e) {
            // Handle any exceptions that occur during the execution
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(), // Optionally include the error message for debugging
            ],   $this->server_error,); // You can adjust the status code based on the type of error encountered
        }
    }


    /**
     * Retrieve all sessions associated with the currently authenticated coach.
     *
     * @return \Illuminate\Http\JsonResponse JSON response containing status, message,
     *                                       and data of sessions.
     */
    public function getAllSessions()
    {

        try {
            // Retrieve sessions using the coach_calendar_services instance
            $schedules = $this->coach_calender_services->getAllSessionsData();

            // Generate and return the API response using the response helper
            return $this->api_response_helper::generateAPIResponse(
                $schedules,
                $this->status_code,
                $this->not_found_status_code 
            );
        } catch (\Exception $e) {
            // Handle any exceptions that occur during the execution
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(), // Optionally include the error message for debugging
            ],   $this->server_error,); // You can adjust the status code based on the type of error encountered
        }

    }


   
   
    /**
     * Get today's schedule call.
     *
     * This method retrieves the schedule for today from the coach calendar services
     * and generates an API response. If an exception occurs during the process,
     * an error response is returned.
     *
     * @return \Illuminate\Http\JsonResponse The API response containing today's schedule or an error message.
     */    
    public function getTodayScheduleCall()
    {

        try {

            // Retrieve today's schedule call data from the coach calendar services
            $schedules = $this->coach_calender_services->getTodayScheduleCallData();

            // Generate and return the API response using the response helper
            return $this->api_response_helper::generateAPIResponse(
                $schedules,
                $this->status_code,
                $this->not_found_status_code 
            );
        } catch (\Exception $e) {
            // Handle any exceptions that occur during the execution
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(), // Optionally include the error message for debugging
            ],   $this->server_error,); // You can adjust the status code based on the type of error encountered
        }

    }

    /**
     * Store new time slots for a coach.
     *
     *
     * @param StoreSlotsRequest $request The incoming request containing the data for the new time slots.
     * @return \Illuminate\Http\JsonResponse The API response indicating success or failure.
     */
    public function storeSlots(StoreSlotsRequest $request)
    {
        try {
            // Validate the request data
            $validatedData = $request->validated();
            
            // Store slots using the service class method
            $store_slots = $this->coach_calender_services->storeSlots($request);

            // Generate API response based on the result of storing slots
            return $this->api_response_helper::generateAPIResponse(
                $store_slots,
                $this->new_resource_create,
                $this->unprocessable_entity_status_code 
            );
        } catch (\Exception $e) {
            // Handle any exceptions that occur during the execution
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(), // Optionally include the error message for debugging
            ],   $this->server_error,); // You can adjust the status code based on the type of error encountered
        }
    }

    
    /**
     * Handle the store of leave requests.
     *
     * @param \App\Http\Requests\StoreLeaveRequest $request The incoming request containing leave data.
     * @return \Illuminate\Http\JsonResponse A JSON response indicating success or failure of the leave storage.
     */
    public function storeLeave(StoreLeaveRequest $request)
    {
        try {
            // Validate the incoming request data
            $validatedData = $request->validated();
            
            $store_leave = $this->coach_calender_services->storeLeave($request);

            // Generate API response based on the result of storing slots
            return $this->api_response_helper::generateAPIResponse(
                $store_leave,
                $this->new_resource_create,
                $this->unprocessable_entity_status_code 
            );
        } catch (\Exception $e) {
            // Handle any exceptions that occur during the execution
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(), // Optionally include the error message for debugging
            ],   $this->server_error,); // You can adjust the status code based on the type of error encountered
        }
    }

}
