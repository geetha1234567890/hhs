<?php

namespace Modules\Coach\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

use Modules\Coach\Services\API\CoachStudentBatchMappingServices;
use Modules\Admin\Helpers\APIResponse\APIResponseHelper;

use Auth;

class CoachStudentBatchMappingController extends Controller
{

    private $coach_student_batch_mapping_services;
    private $api_response_helper;

    /**
     * Constructor for initializing ProfileController.
     *
     * @param CoachStudentBatchMappingServices $coach_student_batch_mapping_services Injected service for profile operations.
     * @param APIResponseHelper $api_response_helper Injected helper for API response handling.
     */
    public function __construct(
        CoachStudentBatchMappingServices $coach_student_batch_mapping_services,
        APIResponseHelper $api_response_helper,
    ){
        // Initialize HTTP status codes for various responses
        $this->status_code = config('global_constant.STATUS_CODE.SUCCESS');
        $this->not_found_status_code = config('global_constant.STATUS_CODE.NOT_FOUND');
        $this->bad_request_status_code = config('global_constant.STATUS_CODE.BAD_REQUEST');
        $this->credentials_valid_status_code = config('global_constant.STATUS_CODE.CREDENTIALS_VALID');
        $this->no_content_status_code = config('global_constant.STATUS_CODE.NO_CONTENT');
        $this->unprocessable_entity_status_code =  config('global_constant.STATUS_CODE.UNPROCESSABLE_ENTITY');
        $this->new_resource_create =  config('global_constant.STATUS_CODE.NEW_RESOURCE_CREATE');
        $this->server_error = config('global_constant.STATUS_CODE.SERVER_ERROR');

        // Injected dependencies initialization
        $this->coach_student_batch_mapping_services = $coach_student_batch_mapping_services;
        $this->api_response_helper = $api_response_helper;
    }

    
    /**
     * Retrieve assigned students' data.
     *
     * @return \Illuminate\Http\JsonResponse A JSON response containing the assigned students' data or an error message.
     */
    public function getAssignStudents()
    {
        try {
            // Fetch assigned students' data using the service class
            $get_student = $this->coach_student_batch_mapping_services->getAssignStudentsData();

            // Generate and return the API response using the response helper
            return $this->api_response_helper::generateAPIResponse(
                $get_student,
                $this->status_code,
                $this->not_found_status_code 
            );
        } catch (\Exception $e) {
            // Handle any exceptions that occur during the execution
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(), // Optionally include the error message for debugging
            ],   $this->server_error,); // You can adjust the status code based on the type of error encountered
        }
    }


    /**
     * Retrieve assigned batches' data.
     *
     * @return \Illuminate\Http\JsonResponse A JSON response containing the assigned batches' data or an error message.
     */
    public function getAssignBatches()
    {
        try {
            // Fetch assigned batches' data using the service class
            $get_batch = $this->coach_student_batch_mapping_services->getAssignBatchesData();

            // Generate and return the API response using the response helper
            return $this->api_response_helper::generateAPIResponse(
                $get_batch,
                $this->status_code,
                $this->not_found_status_code 
            );
        } catch (\Exception $e) {
            // Handle any exceptions that occur during the execution
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(), // Optionally include the error message for debugging
            ],   $this->server_error,); // You can adjust the status code based on the type of error encountered
        }
    }
}
