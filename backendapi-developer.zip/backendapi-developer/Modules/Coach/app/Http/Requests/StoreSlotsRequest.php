<?php 
    namespace Modules\Coach\Http\Requests;
    use Illuminate\Foundation\Http\FormRequest;

    class StoreSlotsRequest extends FormRequest
    {
        public function authorize()
        {
            return true;
        }

        /**
         * Get the validation rules that apply to the request.
         */
        public function rules(): array
        {
            return [
                'slot_date' => 'required|date',
                'from_time' => 'required|date_format:H:i:s',
                'to_time' => 'required|date_format:H:i:s|after:from_time',
                'timezone_id' => 'required|integer',
                'series' => 'integer|nullable',
            ];

        } 
    
        public function messages()
        {
            return [
                'slot_date.required' =>  __('Admin::validation_message.coach.slot_date_required'),
                'slot_date.date' =>  __('Admin::validation_message.coach.slot_date_date'),
                'from_time.required' =>  __('Admin::validation_message.coach.from_time_required'),
                'from_time.date_format' =>  __('Admin::validation_message.coach.from_time_date_format'),
                'to_time.required' => __('Admin::validation_message.coach.to_time_required'),
                'to_time.date_format' => __('Admin::validation_message.coach.to_time_date_format'),
                'to_time.after' => __('Admin::validation_message.coach.to_time_after'),
                'timezone_id.required' => __('Admin::validation_message.coach.timezone_id_required'),
                'timezone_id.integer' => __('Admin::validation_message.coach.timezone_id_integer'),
                'series.integer' => __('Admin::validation_message.coach.series_integer'),
            ];
        }
    }   
?>