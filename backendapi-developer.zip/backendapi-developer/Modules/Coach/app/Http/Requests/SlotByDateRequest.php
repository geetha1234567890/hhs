<?php 
    namespace Modules\Coach\Http\Requests;
    use Illuminate\Foundation\Http\FormRequest;

    class SlotByDateRequest extends FormRequest
    {
        public function authorize()
        {
            return true;
        }

        /**
         * Get the validation rules that apply to the request.
         */
        public function rules(): array
        {
            return [
               'date' => 'required|date',
            ];

        } 
    
        public function messages()
        {
            return [
                'date.required' =>  __('Admin::validation_message.coach.slot_date_required'),
                'date.date' =>  __('Admin::validation_message.coach.slot_date_date'),
            ];
        }
    }   
?>