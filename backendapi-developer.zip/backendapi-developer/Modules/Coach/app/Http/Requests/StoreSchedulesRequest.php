<?php 
    namespace Modules\Coach\Http\Requests;
    use Illuminate\Foundation\Http\FormRequest;

    class StoreSchedulesRequest extends FormRequest
    {
        public function authorize()
        {
            return true;
        }

        /**
         * Get the validation rules that apply to the request.
         */
        public function rules(): array
        {
            return [
                'meeting_name' => 'required|string',
                'meeting_url' => 'required|string',
                'schedule_date' => 'required|date',
                'slot_id' => 'required|integer',
                'start_time' => 'required|date_format:H:i:s',
                'end_time' => 'required|date_format:H:i:s|after:from_time',
                'timezone_id' => 'required|integer',
                'event_status' => 'required|string',
                'studentId' => 'array', // studentId should be an array
                'studentId.*' => 'integer', // Each studentId in the array should be an integer
                'batchId' => 'array', // batchId should be an array
                'batchId.*' => 'integer', // Each batchId in the array should be an integer
            ];

        } 
    
        public function messages()
        {
            return [
                'meeting_name.required' =>  __('Admin::validation_message.coach.meeting_name_required'),
                'meeting_name.string' => __('Admin::validation_message.coach.meeting_name_string'),
                'meeting_url.required' => __('Admin::validation_message.coach.meeting_url_required'),
                'meeting_url.string' => __('Admin::validation_message.coach.meeting_url_string'),
                'schedule_date.required' => __('Admin::validation_message.coach.schedule_date_required'),
                'schedule_date.date' => __('Admin::validation_message.coach.schedule_date_date'),
                'slot_id.required' => __('Admin::validation_message.coach.slot_id_required'),
                'slot_id.integer' => __('Admin::validation_message.coach.slot_id_integer'),
                'start_time.required' => __('Admin::validation_message.coach.start_time_required'),
                'start_time.date_format' =>  __('Admin::validation_message.coach.start_time_date_format'),
                'end_time.required' => __('Admin::validation_message.coach.end_time_required'),
                'end_time.date_format' => __('Admin::validation_message.coach.end_time_date_format'),
                'end_time.after' => __('Admin::validation_message.coach.end_time_after'),
                'timezone_id.required' => __('Admin::validation_message.coach.timezone_id_required'),
                'timezone.integer' => __('Admin::validation_message.coach.timezone_id_integer'),
                'event_status.required' => __('Admin::validation_message.coach.event_status_required'),
                'event_status.string' => __('Admin::validation_message.coach.event_status_string'),
                'studentId.array' => __('Admin::validation_message.coach.studentId_array'),
                'studentId.*.integer' => __('Admin::validation_message.coach.studentId_integer'),
                'batchId.array' => __('Admin::validation_message.coach.batchId_array'),
                'batchId.*.integer' =>__('Admin::validation_message.coach.batchId_integer'),
            ];
        }
    }   
?>