<?php

namespace Modules\Admin\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Modules\Admin\Models\AdminUsers;
use Modules\Admin\Models\Course;
use Modules\Admin\Models\CourseCoachMapping;

use Auth;

use Modules\Admin\Services\API\CourseCoachMappingServices;
use Modules\Admin\Helpers\APIResponse\APIResponseHelper;


class CourseCoachMappingController extends Controller
{
    private $coach_course_mapping_services;
    private $api_response_helper;

    /**
     * Constructor method for initializing dependencies and status codes.
     *
     * @param \Modules\Admin\Services\API\CourseCoachMappingServices $coach_course_mapping_services
     * @param \Modules\Admin\Helpers\APIResponse\APIResponseHelper $api_response_helper
     */
    public function __construct(
        CourseCoachMappingServices $coach_course_mapping_services,
        APIResponseHelper $api_response_helper
    ){
        $this->status_code = config('global_constant.STATUS_CODE.SUCCESS');
        $this->not_found_status_code = config('global_constant.STATUS_CODE.NOT_FOUND');
        $this->server_error = config('global_constant.STATUS_CODE.SERVER_ERROR');
        $this->not_allow = config('global_constant.STATUS_CODE.FORBIDDEN');
        $this->coach_course_mapping_services = $coach_course_mapping_services;
        $this->api_response_helper = $api_response_helper;
    }
    public function store(Request $request)
    {
        try {
            $course_coach_mapping = $this->coach_course_mapping_services->storeCoachCourseMapping($request);

            return $this->api_response_helper::generateAPIResponse(
                $course_coach_mapping,
                $this->status_code,
                $this->not_allow
            );
        } catch (\Exception $e) {
            Log::error('Error retrieving Coach Course Mapping :', ['message' => $e->getMessage()]);
            return response()->json(['error' => 'An unexpected error occurred.'], $this->server_error);
        }
        // try {
        //     $request->validate([
        //         'Coach_id' => 'required|exists:admin_users,id',
        //         'courses' => 'required|array',
        //         'courses.*.id' => 'required|string',
        //     ]);

        //     $coach = AdminUsers::find($request->Coach_id);
        //     $coachRole = $coach->roles;

        //     if (!$coachRole->contains('role_name', 'Coach')) {
        //         return response()->json(['error' => 'Only Coach can be assigned to a course'], 403);
        //     }

        //     foreach ($request->courses as $course) {
        //         $course = Course::find($course['id']);
        //         $course->coaches()->attach($request->Coach_id);
        //     }

        //     return response()->json(['message' => 'Course Coach Mapping created successfully'], 201);
        // } catch (\Exception $e) {
        //     return response()->json(['error' => 'An error occurred while creating Course Coach Mapping'], 500);
        // }

    }

    public function destroy(Request $request)
    {
        try {
            $request->validate([
                'Coach_id' => 'required|exists:admin_users,id',
                'courses' => 'required|array',
                'courses.*.id' => 'required|string',
            ]);

            $coach = AdminUsers::find($request->Coach_id);
            $coachRole = $coach->roles;

            if (!$coachRole->contains('role_name', 'Coach')) {
                return response()->json(['error' => 'Only Coach can be assigned to a course'], 403);
            }

            foreach ($request->courses as $course) {
                $course = Course::find($course['id']);
                $course->coaches()->detach($request->Coach_id);
            }

            return response()->json(['message' => 'Course Coach Mapping deleted successfully'], 200);
        } catch (\Exception $e) {
            return response()->json(['error' => 'An error occurred while deleting Course Coach Mapping'], 500);
        }
    }

    public function showCoachesForCourse($course_id)
    {
        try {
            $coaches = CourseCoachMapping::with('course', 'coach')->where('course_id', $course_id)->get();
            if($course == null) {
            return response()->json(['error' => 'Course not found'], 404);
            }

            // $modifiedcoaches = $coaches->map(function($coach) {
            //     return [
            //         'id' => $coach->id,
            //         'name' => $coach->name,
            //         'is_active' => $coach->is_active,
            //         'created_at' => $coach->created_at,
            //         'updated_at' => $coach->updated_at,
            //         'branch' => [
            //             'id' => $coach->parent->id,
            //             'name' => $coach->parent->name
            //         ]
            //     ];
            // });

            return response()->json(['coaches' => $coaches], 200);
        } catch (\Exception $e) {
            return response()->json(['An error occurred while fetching Course Coaches' => $e->get_message()], 500);
        }
    }

    public function showCoursesForCoach($Coach_id)
    {
        try {
            $coach = AdminUsers::find($Coach_id);
            if($coach == null) {
                return response()->json(['error' => 'Coach not found'], 404);
            }

            $coachRole = $coach->roles->toArray();

            if (!$coachRole->contains('role_name', 'Coach')) {
                return response()->json(['error' => 'Only Coach can be assigned to a course'], 403);
            }

            $courses = $coach->courses;

            return response()->json(['courses' => $courses], 200);
        } catch (\Exception $e) {
            return response()->json(['error' => 'An error occurred while fetching Coach Courses'], 500);
        }
    }

    public function getAllCoursesWithCoaches()
    {
        try {

            $courses = Course::with('coaches')
            ->get();

            return response()->json(['courses' => $courses], 200);
            
        } catch (\Exception $e) {
            return response()->json(['error' => 'An error occurred while fetching Courses'], 500);
        }
    }

    public function getAllCoachesWithCourses()
    {
        try {

            $coaches = AdminUsers::whereHas('roles', function($q){
                $q->where('role_name', 'Coach');
            })->with(['courses' => function ($query) {
                $query->select('id', 'name');
            }])->get(['id', 'name']);

            return response()->json(['coaches' => $coaches], 200);
            
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }
    
}
