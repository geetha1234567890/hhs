<?php

namespace Modules\Admin\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Modules\Admin\Models\PlatformTools;

class PlatformToolsController extends Controller
{
    public function getAll(){
        $platformTools = PlatformTools::where('is_active', 1)->get();
        return response()->json($platformTools);
    }
    
}
