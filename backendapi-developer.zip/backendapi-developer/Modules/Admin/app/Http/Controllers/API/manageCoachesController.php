<?php

namespace Modules\Admin\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Modules\Admin\Models\AdminUsers;
use Modules\Admin\Models\Role;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Crypt;
use Modules\Admin\Http\Requests\ManageTaCoachStoreRequest;

class manageCoachesController extends Controller
{
    public function index()
    {
        try {
            $coachesRole = Role::where('role_name', 'Coach')->first();
            $coaches = AdminUsers::whereHas('roles', function ($query) use ($coachesRole) {
                $query->where('role_id', $coachesRole->id);
            })->get()->map(function ($coach) {
                $data = $coach->only([
                    'id', 'name', 'username','phone', 'email', 'location', 'address', 'pincode', 'timezone_id', 'gender',
                    'date_of_birth', 'highest_qualification', 'profile', 'about_me','description', 'is_active', 
                    'created_by', 'updated_by', 'created_at', 'updated_at'
                ]);
                $data['profile_picture'] = $coach->profile_picture ? base64_encode($coach->profile_picture) : null;
                try {
                    // Decrypt email field
                    $data['email'] = Crypt::decrypt($coach->email);
                } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
                    // Handle decryption failure
                    $data['email'] = 'Decryption failed'; // or handle as per your application's logic
                }

                try {
                    // Decrypt email field
                    $data['phone'] = Crypt::decrypt($coach->phone);
                } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
                    // Handle decryption failure
                    $data['phone'] = 'Decryption failed'; // or handle as per your application's logic
                }
                return $data;
            });

            return response()->json($coaches, 200);
        } catch (\Exception $e) {
            Log::error('Error fetching Coaches:', ['message' => $e->getMessage()]);
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function store(ManageTaCoachStoreRequest $request)
    {
        try {
            $validatedData = $request->validated();
            $existingUsers = AdminUsers::all();
            foreach ($existingUsers as $existingUser) {
                try {
                    $decryptedEmail = Crypt::decrypt($existingUser->email);
                } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
                    // Handle decryption failure
                    $decryptedEmail = 'Decryption failed'; // or handle as per your application's logic
                }
    
                try {
                    $decryptedPhone = Crypt::decrypt($existingUser->phone);
                } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
                    // Handle decryption failure
                    $decryptedPhone = 'Decryption failed'; // or handle as per your application's logic
                }

                if ($decryptedEmail === $request->email) {
                    return response()->json(['error' => 'Email already exists'], 400);
                }

                if ($decryptedPhone === $request->phone) {
                    return response()->json(['error' => 'Phone number already exists'], 400);
                }
            }

            $hashedPassword = Hash::make($request->password);
    
            // Convert base64 to binary if profile_picture is present
            $encryptedPhone = Crypt::encrypt($request->phone);
            $encryptedEmail = Crypt::encrypt($request->email);
            $profilePicture = null;
            if ($request->has('profile_picture')) {
                $profilePicture = base64_decode($request->profile_picture);
            }
    
            $coach = AdminUsers::create([
                'name' => $request->name,
                'username' => $request->username,
                'email' => $encryptedEmail,
                'phone' => $encryptedPhone,
                'password' => $hashedPassword,
                'location' => $request->location,
                'address' => $request->address,
                'pincode' => $request->pincode,
                'timezone_id' => $request->timezone_id,
                'gender' => $request->gender,
                'date_of_birth' => $request->date_of_birth,
                'highest_qualification' => $request->highest_qualification,
                'profile_picture' => $profilePicture,
                'profile' => $request->profile,
                'about_me' => $request->about_me,
                'description' => $request->description,
            ]);
    
            $coachRole = Role::where('role_name', 'Coach')->first();
    
            if ($coachRole) {
                DB::table('user_roles')->insert([
                    'user_id' => $coach->id,
                    'role_id' => $coachRole->id
                ]);
            }

            if ($coach->profile_picture) {
                $coach->profile_picture = base64_encode($coach->profile_picture);
            }    
    
            return response()->json([
                'message' => 'Coach successfully created',
                'coach' => $coach  
            ], 201);
        } catch (ValidationException $e) {
            Log::error('Validation Error:', ['errors' => $e->errors()]);
            return response()->json(['errors' => $e->errors()], 422);
        } catch (\Exception $e) {
            Log::error('Error creating Coach:', ['message' => $e->getMessage()]);
            return response()->json(['error' => 'Failed to create Coach', 'message' => $e->getMessage()], 500);
        }
    }
    

    public function show($id)
    {
        try {
            $coachRole = Role::where('role_name', 'Coach')->first();
            $coach = AdminUsers::where('id', $id)
                ->whereHas('roles', function ($query) use ($coachRole) {
                    $query->where('role_id', $coachRole->id);
                })
                ->first();

            if (is_null($coach)) {
                return response()->json(['message' => 'Coach Not Found or not a Coach'], 404);
            }

            $data = $coach->only([
                'id', 'name', 'username', 'email','phone', 'location', 'address', 'pincode', 'timezone_id', 'gender',
                'date_of_birth', 'highest_qualification', 'profile', 'about_me','description', 'is_active', 
                'created_by', 'updated_by', 'created_at', 'updated_at'
            ]);
            $data['profile_picture'] = $coach->profile_picture ? base64_encode($coach->profile_picture) : null;

            try {
                // Decrypt email field
                $data['email'] = Crypt::decrypt($coach->email);
            } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
                // Handle decryption failure
                $data['email'] = 'Decryption failed'; // or handle as per your application's logic
            }

            try {
                // Decrypt email field
                $data['phone'] = Crypt::decrypt($coach->phone);
            } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
                // Handle decryption failure
                $data['phone'] = 'Decryption failed'; // or handle as per your application's logic
            }

            return response()->json($data, 200);
        } catch (\Exception $e) {
            Log::error('Error fetching Coach:', ['message' => $e->getMessage()]);
            return response()->json(['error' => 'Failed to retrieve coach'], 500);
        }
    }

    public function update(Request $request, $id)
{
    //
    try {
        $coachRole = Role::where('role_name', 'Coach')->first();
        $coach = AdminUsers::where('id', $id)
            ->whereHas('roles', function ($query) use ($coachRole) {
                $query->where('role_id', $coachRole->id);
            })
            ->first();

        if (is_null($coach)) {
            return response()->json(['message' => 'Coach Not Found or not a Coach'], 404);
        }

        $rules = [
            'name' => 'string|max:255',
            'username' => 'string|max:255|unique:admin_users,username,' . $id,
            'phone' => 'string|max:20|unique:admin_users,phone,' . $id,
            'password' => 'string|max:255',
            'location' => 'string|nullable',
            'address' => 'string|nullable',
            'pincode' => 'string|nullable',
            'timezone_id' => 'integer|nullable',
            'gender' => 'in:Male,Female,Other',
            'date_of_birth' => 'date',
            'highest_qualification' => 'string|max:255',
            'profile_picture' => 'nullable|string', // Expect base64 encoded string
            'profile' => 'nullable|string',
            'about_me' => 'nullable|string',
            'is_active' => 'boolean',
            'description' => 'nullable|string',
        ];

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 400);
        }

        $allowedFields = array_keys($rules);
        $extraFields = array_diff(array_keys($request->all()), $allowedFields);

        if (!empty($extraFields)) {
            return response()->json(['message' => 'You cannot update these fields: ' . implode(', ', $extraFields)], 400);
        }

        $input = $request->except(['username']);

        if (isset($input['password'])) {
            $input['password'] = Hash::make($input['password']);
        }

        if (isset($input['phone'])) {
            $existingUsers = AdminUsers::all();
            foreach ($existingUsers as $existingUser) {
                $decryptedPhone = Crypt::decrypt($existingUser->phone);
                if ($decryptedPhone === $input['phone']) {
                    return response()->json(['error' => 'Phone number already exists'], 400);
                }
            }
            $input['phone'] = Crypt::encrypt($input['phone']);
        }

        // Convert base64 to binary if profile_picture is present
        if ($request->has('profile_picture')) {
            $input['profile_picture'] = base64_decode($request->profile_picture);
        }

        $coach->update($input);

        if ($coach->profile_picture) {
            $coach->profile_picture = base64_encode($coach->profile_picture);
        }

        try {
            // Decrypt email field
            $coach->phone = Crypt::decrypt($coach->phone);
        } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
            // Handle decryption failure
            $coach->phone = 'Decryption failed'; // or handle as per your application's logic
        }

        try {
            // Decrypt email field
            $coach->email = Crypt::decrypt($coach->email);
        } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
            // Handle decryption failure
            $coach->email = 'Decryption failed'; // or handle as per your application's logic
        }
        
        return response()->json($coach, 200);
    } catch (ValidationException $e) {
        Log::error('Validation Error:', ['errors' => $e->errors()]);
        return response()->json(['errors' => $e->errors()], 422);
    } catch (\Exception $e) {
        Log::error('Error updating Coach:', ['message' => $e->getMessage()]);
        return response()->json(['error' => 'An unexpected error occurred.'], 500);
    }
}


    public function destroy($id)
    {
        try {
            $coachRole = Role::where('role_name', 'Coach')->first();
            $coach = AdminUsers::where('id', $id)
                ->whereHas('roles', function ($query) use ($coachRole) {
                    $query->where('role_id', $coachRole->id);
                })
                ->first();

            if (is_null($coach)) {
                return response()->json(['message' => 'Coach Not Found or not a Coach'], 404);
            }

            $coach->delete();
            return response()->json(null, 204);
        } catch (\Exception $e) {
            Log::error('Error deleting Coach:', ['message' => $e->getMessage()]);
            return response()->json(['error' => 'Failed to delete coach'], 500);
        }
    }
}
