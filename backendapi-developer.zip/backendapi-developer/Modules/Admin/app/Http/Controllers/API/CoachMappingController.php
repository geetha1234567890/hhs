<?php

namespace Modules\Admin\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

use Modules\Admin\Services\API\CoachMappingServices;
use Modules\Admin\Helpers\APIResponse\APIResponseHelper;
use Modules\Admin\Http\Requests\AssignStudentRequest;
use Modules\Admin\Http\Requests\AssignBatchRequest;



class CoachMappingController extends Controller
{


    private $coach_mapping_services;
    private $api_response_helper;

    public function __construct(
        CoachMappingServices $coach_mapping_services,
        APIResponseHelper $api_response_helper,
    ){
        $this->status_code = config('global_constant.STATUS_CODE.SUCCESS');
        $this->not_found_status_code = config('global_constant.STATUS_CODE.NOT_FOUND');
        $this->bad_request_status_code = config('global_constant.STATUS_CODE.BAD_REQUEST');
        $this->credentials_valid_status_code = config('global_constant.STATUS_CODE.CREDENTIALS_VALID');
        $this->no_content_status_code = config('global_constant.STATUS_CODE.NO_CONTENT');
        $this->unprocessable_entity_status_code =  config('global_constant.STATUS_CODE.UNPROCESSABLE_ENTITY');
        $this->new_resource_create =  config('global_constant.STATUS_CODE.NEW_RESOURCE_CREATE');
        $this->server_error = config('global_constant.STATUS_CODE.SERVER_ERROR');

        $this->coach_mapping_services = $coach_mapping_services;
        $this->api_response_helper = $api_response_helper;
    }


    public function getAssignStudents($Coach_Id)
    {
        try {
            $get_students = $this->coach_mapping_services->getAssignStudents($Coach_Id);
            return $this->api_response_helper::generateAPIResponse(
                $get_students,
                $this->status_code,
                $this->not_found_status_code
            );

        } catch (\Exception $e) {
            Log::error('Error in fetching assign student:', ['message' => $e->getMessage()]);
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(),
            ],$this->server_error);
        }
    }

    public function getAssignBatches($Coach_Id)
    {
        try {
            $get_batches = $this->coach_mapping_services->getAssignBatches($Coach_Id);
            return $this->api_response_helper::generateAPIResponse(
                $get_batches,
                $this->status_code,
                $this->not_found_status_code
            );

        } catch (\Exception $e) {
            Log::error('Error in fetching assign batches:', ['message' => $e->getMessage()]);
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(),
            ],$this->server_error);
        }
    }

    public function getActiveAssignStudents($Coach_Id)
    {
        try {
            $get_students = $this->coach_mapping_services->getActiveAssignStudents($Coach_Id);
            return $this->api_response_helper::generateAPIResponse(
                $get_students,
                $this->status_code,
                $this->not_found_status_code
            );

        } catch (\Exception $e) {
            Log::error('Error in fetching Active assign student:', ['message' => $e->getMessage()]);
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(),
            ],$this->server_error);
        }
    }

    public function getActiveAssignBatches($Coach_Id)
    {
        try {
            $get_batches = $this->coach_mapping_services->getAssignBatches($Coach_Id);
            return $this->api_response_helper::generateAPIResponse(
                $get_batches,
                $this->status_code,
                $this->not_found_status_code
            );

        } catch (\Exception $e) {
            Log::error('Error in fetching assign batches:', ['message' => $e->getMessage()]);
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(),
            ],$this->server_error);
        }
    }

    public function assignStudents(AssignStudentRequest $request)
    {
        try {
            $validatedData = $request->validated();
            $assign_students = $this->coach_mapping_services->assignStudents($request);
            return $this->api_response_helper::generateAPIResponse(
                $assign_students,
                $this->new_resource_create,
                $this->unprocessable_entity_status_code
            );

        } catch (\Exception $e) {
            Log::error('Unexpected Error:', ['message' => $e->getMessage()]);
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(),
            ],$this->server_error);
        }
           
    }

    public function assignBatches(AssignBatchRequest $request)
    {
        try {
            $validatedData = $request->validated();
            $assign_batches = $this->coach_mapping_services->assignBatches($request);
            return $this->api_response_helper::generateAPIResponse(
                $assign_batches,
                $this->new_resource_create,
                $this->unprocessable_entity_status_code
            );
        } catch (\Exception $e) {
            Log::error('Unexpected Error:', ['message' => $e->getMessage()]);
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(),
            ],$this->server_error);
        }
    }
    

    public function CoachswithActiveStudentnBatches()
    {
        try {
            $TAs = $this->coach_mapping_services->CoachswithActiveStudentnBatches();
            return $this->api_response_helper::generateAPIResponse(
                $TAs,
                $this->status_code,
                $this->not_found_status_code
            );
        
        } catch (\Exception $e) {
            Log::error('Error fetching TA:', ['message' => $e->getMessage()]);
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(),
            ],$this->server_error);
        }
    }

    public function ActiveDeactiveAssignStudent($id)
    {
        try {

            $active_deactive = $this->coach_mapping_services->ActiveDeactiveAssignStudent($id);
            return $this->api_response_helper::generateAPIResponse(
                $active_deactive,
                $this->status_code,
                $this->unprocessable_entity_status_code 
            );

        } catch (\Exception $e) {
            Log::error('Error Activeted Student:', ['message' => $e->getMessage()]);
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(),
            ],$this->server_error);
        }
    }
    

    public function ActiveDeactiveAssignBatch($id)
    {
        try {
            $active_deactive = $this->coach_mapping_services->ActiveDeactiveAssignBatch($id);
            return $this->api_response_helper::generateAPIResponse(
                $active_deactive,
                $this->status_code,
                $this->unprocessable_entity_status_code 
            );

        } catch (\Exception $e) {
            Log::error('Error Activeted Batch:', ['message' => $e->getMessage()]);
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(),
            ],$this->server_error);
        }
    }


    public function destroyAssignStudents($id)
    {
        try {
            $destroy_student = $this->coach_mapping_services->destroyAssignStudents($id);
            return $this->api_response_helper::generateAPIResponse(
                $destroy_student,
                $this->no_content_status_code,
                $this->not_found_status_code
            );

        } catch (\Exception $e) {
            Log::error('Error deleting student:', ['message' => $e->getMessage()]);
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(),
            ],$this->server_error);
        }
    }


    public function destroyAssignBatch($id)
    {
        try {
            $destroy_batch = $this->coach_mapping_services->destroyAssignBatch($id);
            return $this->api_response_helper::generateAPIResponse(
                $destroy_batch,
                $this->no_content_status_code,
                $this->not_found_status_code
            );

        } catch (\Exception $e) {
            Log::error('Error deleting batch:', ['message' => $e->getMessage()]);
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(),
            ],$this->server_error);
        }
    }

    public function destroyMapping($id)
    {
        try {
            $destroy_mapping = $this->coach_mapping_services->destroyMapping($id);
            return $this->api_response_helper::generateAPIResponse(
                $destroy_mapping,
                $this->no_content_status_code,
                $this->not_found_status_code
            );

        } catch (\Exception $e) {
            Log::error('Error deleting mapping:', ['message' => $e->getMessage()]);
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(),
            ],$this->server_error);
        }
    }
    
    
    
    
}

