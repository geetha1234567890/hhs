<?php

namespace Modules\Admin\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;

use Modules\Admin\Services\API\TASchedulingServices;
use Modules\Admin\Http\Requests\StoreTACoachScheduleRequest;
use Modules\Admin\Http\Requests\GetTaCoachSchedulesRecordsRequest;
use Modules\Admin\Http\Requests\RescheduleSessionRequest;
use Modules\Admin\Helpers\APIResponse\APIResponseHelper;

class TASchedulingController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    private $ta_schedule_services;
    private $api_response_helper;

    /**
     * Constructor method for initializing dependencies and status codes.
     *
     * @param \Modules\Admin\Services\API\TASchedulingServices $ta_schedule_services
     * @param \Modules\Admin\Helpers\APIResponse\APIResponseHelper $api_response_helper
     */
    public function __construct(
        TASchedulingServices $ta_schedule_services,
        APIResponseHelper $api_response_helper,
    ){
        // Initialize HTTP status codes for various responses
        $this->status_code = config('global_constant.STATUS_CODE.SUCCESS');
        $this->not_found_status_code = config('global_constant.STATUS_CODE.NOT_FOUND');
        $this->bad_request_status_code = config('global_constant.STATUS_CODE.BAD_REQUEST');
        $this->credentials_valid_status_code = config('global_constant.STATUS_CODE.CREDENTIALS_VALID');
        $this->no_content_status_code = config('global_constant.STATUS_CODE.NO_CONTENT');
        $this->unprocessable_entity_status_code =  config('global_constant.STATUS_CODE.UNPROCESSABLE_ENTITY');
        $this->new_resource_create =  config('global_constant.STATUS_CODE.NEW_RESOURCE_CREATE');
        $this->server_error = config('global_constant.STATUS_CODE.SERVER_ERROR');

        // Injected dependencies initialization
        $this->ta_schedule_services = $ta_schedule_services;
        $this->api_response_helper = $api_response_helper;
    }

    public function getOneTaRecords(Request $request,$ta_id)
    {
 
        try {
            // Retrieve all TA coach schedules using the service class method
            $get_schedules = $this->ta_schedule_services->getOneTaAllRecords($request,$ta_id);

            // Generate API response based on the retrieved schedules
            return $this->api_response_helper::generateAPIResponse(
                $get_schedules,
                $this->status_code,
                $this->not_found_status_code 
            );
        } catch (\Exception $e) {
            // Handle any exceptions that occur during the execution
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(), // Optionally include the error message for debugging
            ],   $this->server_error,); // You can adjust the status code based on the type of error encountered
        }
    }

    
    public function getOneTaSessions($ta_id)
    {
 
        try {
            // Retrieve all TA coach schedules using the service class method
            $get_schedules = $this->ta_schedule_services->getOneTaAllSessions($ta_id);

            // Generate API response based on the retrieved schedules
            return $this->api_response_helper::generateAPIResponse(
                $get_schedules,
                $this->status_code,
                $this->not_found_status_code 
            );
        } catch (\Exception $e) {
            // Handle any exceptions that occur during the execution
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(), // Optionally include the error message for debugging
            ],   $this->server_error,); // You can adjust the status code based on the type of error encountered
        }
    }

    public function getScheduleStudents($id){
        try {
            // Retrieve all TA coach schedules using the service class method
            $get_schedules = $this->ta_schedule_services->getScheduleStudents($id);

            // Generate API response based on the retrieved schedules
            return $this->api_response_helper::generateAPIResponse(
                $get_schedules,
                $this->status_code,
                $this->not_found_status_code 
            );
        } catch (\Exception $e) {
            // Handle any exceptions that occur during the execution
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(), // Optionally include the error message for debugging
            ],   $this->server_error,); // You can adjust the status code based on the type of error encountered
        }
    }

    public function getScheduleBatches($id){
        try {
            // Retrieve all TA coach schedules using the service class method
            $get_schedules = $this->ta_schedule_services->getScheduleBatches($id);

            // Generate API response based on the retrieved schedules
            return $this->api_response_helper::generateAPIResponse(
                $get_schedules,
                $this->status_code,
                $this->not_found_status_code 
            );
        } catch (\Exception $e) {
            // Handle any exceptions that occur during the execution
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(), // Optionally include the error message for debugging
            ],   $this->server_error,); // You can adjust the status code based on the type of error encountered
        }
    }

    public function updateScheduleStudents(Request $request ,$id)
    {
        try {
            // Validate the incoming request data
            $validatedData = $request->validate([
                'admin_user_id' => 'required|integer|exists:admin_users,id',
                'studentId' => 'array|exists:students,id',
                'studentId.*' => 'integer', 
            ]);
            
            // Store schedules using the service class method
            $update_schedule = $this->ta_schedule_services->updateScheduleStudents($request,$id);

            // Generate API response based on the result of storing schedules
            return $this->api_response_helper::generateAPIResponse(
                $update_schedule,
                $this->status_code,
                $this->unprocessable_entity_status_code 
            );
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(),
            ],   $this->server_error,); 
        }
        
    }

    public function updateScheduleBatches(Request $request ,$id)
    {
        try {
            // Validate the incoming request data
            $validatedData = $request->validate([
                'admin_user_id' => 'required|integer|exists:admin_users,id',
                'batchId' => 'array|exists:batches,id',
                'batchId.*' => 'integer', 
            ]);
            
            // Store schedules using the service class method
            $update_schedule = $this->ta_schedule_services->updateScheduleBatches($request,$id);

            // Generate API response based on the result of storing schedules
            return $this->api_response_helper::generateAPIResponse(
                $update_schedule,
                $this->status_code,
                $this->unprocessable_entity_status_code 
            );
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(),
            ],   $this->server_error,); 
        }
        
    }



    public function changePlatform(Request $request ,$id)
    {
        try {
            // Validate the incoming request data
            $validatedData = $request->validate([
                'admin_user_id' => 'required|integer|exists:admin_users,id',
                'platform_id' => 'required|integer|exists:platform_tools,id',
            ]);
            
            // Store schedules using the service class method
            $update_schedule = $this->ta_schedule_services->changePlatform($request,$id);

            // Generate API response based on the result of storing schedules
            return $this->api_response_helper::generateAPIResponse(
                $update_schedule,
                $this->status_code,
                $this->unprocessable_entity_status_code 
            );
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(),
            ],   $this->server_error,); 
        }
        
    }


   /**
     * Store a new TA coach schedule based on the incoming request.
     *
     * @param \Modules\Admin\Http\Requests\StoreTACoachScheduleRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(StoreTACoachScheduleRequest $request)
    {

        try {
            // Validate the incoming request data
            $validatedData = $request->validated();
            // Store schedules using the service class method
            $store_schedule = $this->ta_schedule_services->storeSchedules($request);
           
            // Generate API response based on the result of storing schedules
            return $this->api_response_helper::generateAPIResponse(
                $store_schedule,
                $this->new_resource_create,
                $this->unprocessable_entity_status_code 
            );
        } catch (\Exception $e) {
            // Handle any exceptions that occur during the execution
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(), // Optionally include the error message for debugging
            ],   $this->server_error,); // You can adjust the status code based on the type of error encountered
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function ReSchedules(RescheduleSessionRequest $request ,$id)
    {
        try {
            // Validate the incoming request data
            
            $validatedData = $request->validated();
            
            // Store schedules using the service class method
            $update_schedule = $this->ta_schedule_services->ReSchedules($request , $id);

            // Generate API response based on the result of storing schedules
            return $this->api_response_helper::generateAPIResponse(
                $update_schedule,
                $this->status_code,
                $this->unprocessable_entity_status_code 
            );
        } catch (\Exception $e) {
            // Handle any exceptions that occur during the execution
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(), // Optionally include the error message for debugging
            ],   $this->server_error,); // You can adjust the status code based on the type of error encountered
        }
        
    }

    public function destroy($id)
    {
        try {
            // Attempt to delete the schedule using the ta_coach_schedules_services
            $delete_schedule = $this->ta_schedule_services->DeleteSchedules($id);

            // Generate and return the API response based on the result of the delete operation
            return $this->api_response_helper::generateAPIResponse(
                $delete_schedule,
                $this->no_content_status_code,
                $this->not_found_status_code 
            );

        } catch (\Exception $e) {
            // Handle any exceptions that occur during the execution
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(), // Optionally include the error message for debugging
            ],   $this->server_error,); // You can adjust the status code based on the type of error encountered
        }
    }

    public function cancel($id)
    {
        try {
            // Attempt to delete the schedule using the ta_coach_schedules_services
            $delete_schedule = $this->ta_schedule_services->CancelSchedules($id);
            // Generate and return the API response based on the result of the delete operation
            return $this->api_response_helper::generateAPIResponse(
                $delete_schedule,
                $this->status_code,
                $this->not_found_status_code 
            );

        } catch (\Exception $e) {
            // Handle any exceptions that occur during the execution
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(), // Optionally include the error message for debugging
            ],   $this->server_error,); // You can adjust the status code based on the type of error encountered
        }
    }


    /**
     * Retrieve scheduled records based on validated request data.
     *
     * @param App\Http\Requests\GetTaCoachSchedulesRecordsRequest $request
     * @return Illuminate\Http\JsonResponse
     */
    public function getScheduledRecords(GetTaCoachSchedulesRecordsRequest $request)
    { 
        try {
            // Validate the incoming request data using the validated method from the request class
            $validatedData = $request->validated();
            
            // Call the service method to retrieve TA schedules records
            $get_schedule_recods = $this->ta_schedule_services->getTASchedulesRecords($request);

            // Generate an API response based on the result of retrieving schedules
            return $this->api_response_helper::generateAPIResponse(
                $get_schedule_recods,
                $this->status_code,
                $this->not_found_status_code 
            );
        } catch (\Exception $e) {
            // Handle any exceptions that occur during the execution
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(), // Optionally include the error message for debugging
            ],   $this->server_error,); // You can adjust the status code based on the type of error encountered
        }

    }
    
}
