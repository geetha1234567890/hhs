<?php

namespace Modules\Admin\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;
use Modules\Admin\Services\API\TaMappingServices;
use Modules\Admin\Helpers\APIResponse\APIResponseHelper;
use Modules\Admin\Http\Requests\AssignStudentRequest;
use Modules\Admin\Http\Requests\AssignBatchRequest;





class TaMappingController extends Controller
{   

    private $ta_mapping_services;
    private $api_response_helper;

    public function __construct(
        TaMappingServices $ta_mapping_services,
        APIResponseHelper $api_response_helper,
    ){
        $this->status_code = config('global_constant.STATUS_CODE.SUCCESS');
        $this->not_found_status_code = config('global_constant.STATUS_CODE.NOT_FOUND');
        $this->bad_request_status_code = config('global_constant.STATUS_CODE.BAD_REQUEST');
        $this->credentials_valid_status_code = config('global_constant.STATUS_CODE.CREDENTIALS_VALID');
        $this->no_content_status_code = config('global_constant.STATUS_CODE.NO_CONTENT');
        $this->unprocessable_entity_status_code =  config('global_constant.STATUS_CODE.UNPROCESSABLE_ENTITY');
        $this->new_resource_create =  config('global_constant.STATUS_CODE.NEW_RESOURCE_CREATE');
        $this->server_error = config('global_constant.STATUS_CODE.SERVER_ERROR');

        $this->ta_mapping_services = $ta_mapping_services;
        $this->api_response_helper = $api_response_helper;
    }

   
    public function getAssignStudents($TA_Id)
    {
        try {
            $get_students = $this->ta_mapping_services->getAssignStudents($TA_Id);
            return $this->api_response_helper::generateAPIResponse(
                $get_students,
                $this->status_code,
                $this->not_found_status_code
            );

        } catch (\Exception $e) {
            Log::error('Error fetching assign student:', ['message' => $e->getMessage()]);
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(),
            ],$this->server_error);
        }
    }


    

    public function getAssignBatches($TA_Id)
    {
        try {
            $get_batches = $this->ta_mapping_services->getAssignBatches($TA_Id);
            return $this->api_response_helper::generateAPIResponse(
                $get_batches,
                $this->status_code,
                $this->not_found_status_code
            );

        } catch (\Exception $e) {
            Log::error('Error fetching assign batches:', ['message' => $e->getMessage()]);
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(),
            ],$this->server_error);
        }
    }


    public function getActiveAssignStudents($TA_Id)
    {
        try {
            $get_students = $this->ta_mapping_services->getActiveAssignStudents($TA_Id);
            return $this->api_response_helper::generateAPIResponse(
                $get_students,
                $this->status_code,
                $this->not_found_status_code
            );

        } catch (\Exception $e) {
            Log::error('Error fetching assign student:', ['message' => $e->getMessage()]);
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(),
            ],$this->server_error);
        }
    }


    

    public function getActiveAssignBatches($TA_Id)
    {
        try {
            $get_batches = $this->ta_mapping_services->getActiveAssignBatches($TA_Id);
            return $this->api_response_helper::generateAPIResponse(
                $get_batches,
                $this->status_code,
                $this->not_found_status_code
            );

        } catch (\Exception $e) {
            Log::error('Error fetching assign batches:', ['message' => $e->getMessage()]);
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(),
            ],$this->server_error);
        }
    }
    
    /**
     * Store a newly created resource in storage.
     */
    public function assignStudents(AssignStudentRequest $request)
    {   
        try {
            $assign_students = $this->ta_mapping_services->assignStudents($request);
            return $this->api_response_helper::generateAPIResponse(
                $assign_students,
                $this->new_resource_create,
                $this->unprocessable_entity_status_code
            );

        } catch (\Exception $e) {
            Log::error('Unexpected Error:', ['message' => $e->getMessage()]);
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(),
            ],$this->server_error);
        }

    }
    
    public function assignBatches(AssignBatchRequest $request)
    {
        try {
            $assign_batches = $this->ta_mapping_services->assignBatches($request);
            return $this->api_response_helper::generateAPIResponse(
                $assign_batches,
                $this->new_resource_create,
                $this->unprocessable_entity_status_code
            );
        } catch (\Exception $e) {
            Log::error('Unexpected Error:', ['message' => $e->getMessage()]);
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(),
            ],$this->server_error);
        }
    }
    
    



    public function TAswithActiveStudentnBatches()
    {
        try {
            $TAs = $this->ta_mapping_services->TAswithActiveStudentnBatches();
            return $this->api_response_helper::generateAPIResponse(
                $TAs,
                $this->status_code,
                $this->not_found_status_code
            );
        
        } catch (\Exception $e) {
            Log::error('Error fetching TA:', ['message' => $e->getMessage()]);
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(),
            ],$this->server_error);
        }
    }

    public function ActiveDeactiveAssignStudent($id)
    {
        try {

            $active_deactive = $this->ta_mapping_services->ActiveDeactiveAssignStudent($id);
            return $this->api_response_helper::generateAPIResponse(
                $active_deactive,
                $this->status_code,
                $this->unprocessable_entity_status_code 
            );

        } catch (\Exception $e) {
            Log::error('Error Activeted Student:', ['message' => $e->getMessage()]);
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(),
            ],$this->server_error);
        }
    }
    

    public function ActiveDeactiveAssignBatch($id)
    {
        try {
            $active_deactive = $this->ta_mapping_services->ActiveDeactiveAssignBatch($id);
            return $this->api_response_helper::generateAPIResponse(
                $active_deactive,
                $this->status_code,
                $this->unprocessable_entity_status_code 
            );

        } catch (\Exception $e) {
            Log::error('Error Activeted Batch:', ['message' => $e->getMessage()]);
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(),
            ],$this->server_error);
        }
    }
    

    /**
     * Remove the specified resource from storage.
     */
    public function destroyAssignStudents($id)
    {
        try {
            $destroy_student = $this->ta_mapping_services->destroyAssignStudents($id);
            return $this->api_response_helper::generateAPIResponse(
                $destroy_student,
                $this->no_content_status_code,
                $this->not_found_status_code
            );

        } catch (\Exception $e) {
            Log::error('Error deleting student:', ['message' => $e->getMessage()]);
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(),
            ],$this->server_error);
        }
    }
    
    public function destroyAssignBatch($id)
    {
        try {
            $destroy_batch = $this->ta_mapping_services->destroyAssignBatch($id);
            return $this->api_response_helper::generateAPIResponse(
                $destroy_batch,
                $this->no_content_status_code,
                $this->not_found_status_code
            );

        } catch (\Exception $e) {
            Log::error('Error deleting batch:', ['message' => $e->getMessage()]);
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(),
            ],$this->server_error);
        }
    }


    public function destroyMapping($id)
    {
        try {
            $destroy_mapping = $this->ta_mapping_services->destroyMapping($id);
            return $this->api_response_helper::generateAPIResponse(
                $destroy_mapping,
                $this->no_content_status_code,
                $this->not_found_status_code
            );

        } catch (\Exception $e) {
            Log::error('Error deleting mapping:', ['message' => $e->getMessage()]);
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while processing the request.',
                'error' => $e->getMessage(),
            ],$this->server_error);
        }
    }

}
