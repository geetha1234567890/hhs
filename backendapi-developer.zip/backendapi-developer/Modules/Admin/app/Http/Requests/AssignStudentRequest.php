<?php

namespace Modules\Admin\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AssignStudentRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     */
    public function authorize(): bool
    {
        return true;
    }
    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {

        return [
            'admin_user_id' => 'required|integer|exists:admin_users,id',
            'students' => 'required|array',
            'students.*.id' => 'required|string',
        ];

    }
    public function messages()
    {
        return [
            'admin_user_id.required' => __('Admin::validation_message.admin_id_required'),
            'admin_user_id.integer' => __('Admin::validation_message.admin_id_integer'),
            'admin_user_id.exists' => __('Admin::validation_message.admin_id_exists'),
        
            'students.required' => __('Admin::validation_message.studentId.required'),
            'students.array' => __('Admin::validation_message.studentId.array'),
        
            'students.*.id.required' => __('Admin::validation_message.studentId.required'),
            'students.*.id.string' => __('Admin::validation_message.studentId.string'),
        ];
    }
}
