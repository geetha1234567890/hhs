<?php

namespace Modules\Admin\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StudentStoreRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {
        return [
            'name' => 'required|string|max:255',
            'enrollment_id' => 'required|string|max:255', 
            'is_active' => 'required|boolean',
            'timezone_id' => 'required|integer|exists:country_time_zones,id',
            'center' => 'nullable|string|max:255',
            'packages' => 'required|array|min:1', // Ensure at least one package is provided
            'packages.*.Id' => 'required|string|max:255', // Changed to string
            'packages.*.Name' => 'required|string|max:255',
        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }
    public function messages()
    {
        return [
         
        ];
    }
}
