<?php

namespace Modules\Admin\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CourseCoachMappingRequest extends FormRequest
{
    public function rules(): array
    {

        return [
            'Coach_id' => 'required|integer|exists:admin_users,id',
            'courses' => 'required|array',
            'data.*.slot_id' => 'required|integer|exists:ta_coach_slots,id',
            'courses.*.id' => 'required|integer|exists:courses,id',
        ];

    }
    public function messages()
    {
        return [
            'Coach_id.required' => __('Admin::validation_message.course.coach_id_required'),
            'Coach_id.integer' => __('Admin::validation_message.course.coach_id_integer'),
        
            'courses.required' => __('Admin::validation_message.course.course_required'),
            'courses.array' => __('Admin::validation_message.course.course_array'),
        
            'courses.*.id.required' => __('Admin::validation_message.course.course_id_required'),
            'courses.*.id.integer' => __('Admin::validation_message.course.course_id_integer'),
        ];
    }
}
