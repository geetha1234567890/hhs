<?php

namespace Modules\Admin\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class RescheduleSessionRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {
        return [
            'admin_user_id' => 'required|integer|exists:admin_users,id',
            'schedule_date' => 'required|date|date_format:Y-m-d|after_or_equal:today',
            'slot_id' => 'required|integer|exists:ta_coach_slots,id',
            'start_time' => 'required|date_format:H:i:s',
            'end_time' => 'required|date_format:H:i:s|after:start_time',
            'timezone_id' => 'required|integer|exists:country_time_zones,id',
        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }
}
