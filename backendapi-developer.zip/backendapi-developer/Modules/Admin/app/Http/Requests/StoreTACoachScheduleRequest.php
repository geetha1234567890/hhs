<?php

namespace Modules\Admin\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreTACoachScheduleRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     */
    public function rules()
    {
        return [
            'admin_user_id' => 'required|integer|exists:admin_users,id',
            'meeting_name' => 'required|string|max:255',
            'schedule_date' => 'required|date|date_format:Y-m-d|after_or_equal:today',
            'end_date' => 'date|after_or_equal:schedule_date',
            'slot_id' => 'required|integer|exists:ta_coach_slots,id',
            'platform_id' => 'required|integer|exists:platform_tools,id',
            'start_time' => 'required|date_format:H:i:s',
            'end_time' => 'required|date_format:H:i:s|after:start_time',
            'timezone_id' => 'required|integer|exists:country_time_zones,id',
            'event_status' => 'required|string| in:scheduled,rescheduled,cancelled',
            'studentId' => 'array|exists:students,id',
            'studentId.*' => 'integer', 
            'batchId' => 'array|exists:batches,id',
            'batchId.*' => 'integer',
            'weeks' => 'array|size:7',
            'weeks.*' => 'boolean', //
        ];
    }

    public function messages()
    {
        return [
            'admin_user_id.required' => __('Admin::validation_message.admin_id_required'),
            'admin_user_id.integer' => __('Admin::validation_message.admin_id_integer'),
            'admin_user_id.exists' => __('Admin::validation_message.admin_id_exists'),

            'meeting_name.required' => __('Admin::validation_message.meeting_name.required'),
            'meeting_name.string' => __('Admin::validation_message.meeting_name.string'),

            'platform_id.required' => __('Admin::validation_message.platform_id.required'),
            'platform_id.integer' => __('Admin::validation_message.platform_id.integer'),
            'platform_id.exists' => __('Admin::validation_message.platform_id.exists'),
    
            'schedule_date.required' => __('Admin::validation_message.date.required'),
            'schedule_date.date' =>  __('Admin::validation_message.date.valid'),
            
            'slot_id.required' => __('Admin::validation_message.slotid.required'),
            'slot_id.integer' => __('Admin::validation_message.slotid.integer'),
            'slot_id.exists' => __('Admin::validation_message.slotid.exists'),

            'start_time.required' => __('Admin::validation_message.slots.start_time.required'),
            'start_time.date_format' => __('Admin::validation_message.slots.start_time.date_format'),
    
            'end_time.required' => __('Admin::validation_message.end_time.required'),
            'end_time.date_format' => __('Admin::validation_message.end_time.date_format'),
            'end_time.after' => __('Admin::validation_message.end_time.after'),
    
            'timezone_id.required' => __('Admin::validation_message.timezone_id_required'),
            'timezone.integer' => __('Admin::validation_message.timezone_id_integer'),
            'timezone.exists' => __('Admin::validation_message.timezone_id_exists'),

            'event_status.required' => __('Admin::validation_message.event_status.required'),
            'event_status.integer' => __('Admin::validation_message.event_status.string'),
            'event_status.in' => __('Admin::validation_message.event_status.in'),

            'studentId.array' => __('Admin::validation_message.studentId.array'),
            'studentId.*.integer' => __('Admin::validation_message.studentId.integer'),

            'batchId.array' => __('Admin::validation_message.batchId.array'),
            'batchId.*.integer' => __('Admin::validation_message.batchId.integer'),

            'weeks.array' => __('Admin::validation_message.weeks.array'),
            'weeks.*.boolean' => __('Admin::validation_message.weeks.boolean'),
        ];
    }
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }
}
