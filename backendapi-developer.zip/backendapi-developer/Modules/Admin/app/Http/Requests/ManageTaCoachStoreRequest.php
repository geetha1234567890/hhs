<?php

namespace Modules\Admin\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ManageTaCoachStoreRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {
        return [
            'name' => 'required|string|max:255',
            'username' => 'required|string|max:255|unique:admin_users,username',
            'email' => 'required|string|email|max:255|unique:admin_users,email',
            'phone' => 'required|string|max:20|unique:admin_users,phone',
            'password' => 'required|string|max:255',
            'location' => 'string|nullable',
            'address' => 'string|nullable',
            'pincode' => 'string|nullable',
            'timezone_id' => 'integer|nullable',
            'gender' => 'required|in:Male,Female,Other',
            'date_of_birth' => 'required|date',
            'highest_qualification' => 'required|string|max:255',
            'profile_picture' => 'nullable|string', // Expect base64 encoded string
            'profile' => 'nullable|string',
            'about_me' => 'nullable|string',
            'description' => 'nullable|string',
        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }
    public function messages()
    {
        return [
         
        ];
    }
}
