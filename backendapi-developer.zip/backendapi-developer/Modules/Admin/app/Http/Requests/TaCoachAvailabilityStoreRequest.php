<?php

namespace Modules\Admin\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class TaCoachAvailabilityStoreRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {
        return [
                'admin_user_id' => 'required|integer|exists:admin_users,id',
                'current_availability' => 'required|string|max:255',
                'calendar' => 'required|string|max:255',
                'is_active' => 'required|boolean',
                'created_by' => 'required|integer',
                'updated_by' => 'nullable|integer',
        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }
    public function messages()
    {
        return [
         
        ];
    }
}
