<?php

namespace Modules\Admin\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AssignBatchRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     */
    public function authorize(): bool
    {
        return true;
    }
    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {

        return [
            'admin_user_id' => 'required|integer|exists:admin_users,id',
            'batches' => 'required|array',
            'batches.*.id' => 'required|string',
        ];

    }
    public function messages()
    {
        return [
            'admin_user_id.required' => __('Admin::validation_message.admin_id_required'),
            'admin_user_id.integer' => __('Admin::validation_message.admin_id_integer'),
            'admin_user_id.exists' => __('Admin::validation_message.admin_id_exists'),
        
            'students.required' => __('Admin::validation_message.batchId.required'),
            'students.array' => __('Admin::validation_message.batchId.array'),
        
            'students.*.id.required' => __('Admin::validation_message.batchId.required'),
            'students.*.id.string' => __('Admin::validation_message.batchId.string'),
        ];
    }
}
