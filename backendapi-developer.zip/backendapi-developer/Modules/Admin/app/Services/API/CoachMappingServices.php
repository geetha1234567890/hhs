<?php

namespace Modules\Admin\Services\API;

use Modules\Admin\Models\AdminUsers;
use Modules\Admin\Models\TACoachStudentMapping;
use Modules\Admin\Models\TACoachBatchMapping;
use Modules\Admin\Models\StudentBatchMapping;
use Modules\Admin\Models\Student;
use Modules\Admin\Models\Batch;
use Modules\Admin\Models\Role;

class CoachMappingServices
{
    public function getAssignStudents($Coach_Id)
    {
            $CoachRole = Role::where('role_name', 'Coach')->first();
            $Coach = AdminUsers::whereHas('roles', function ($query) use ($CoachRole) {
                $query->where('role_id', $CoachRole->id);
            })->where('id', $Coach_Id)->first();

            if (!$Coach) {
                return [
                    'status' => false,
                    'message' => __('Admin::response_message.mappings.coach_notFound'),
                ];
            }

            $mappings = TACoachStudentMapping::with(['AdminUsers', 'Student.studentBatchMappings.Batch'])
                        ->where('is_deleted', false)
                        ->where('admin_user_id', $Coach_Id)
                        ->get();

                $data = $mappings->map(function($mapping) {
                $student = $mapping->student;
                $batches = $student->studentBatchMappings->map(function ($studentBatchMapping) {
                    return [
                        'batch_id' => $studentBatchMapping->batch->id,
                        'batch_name' => $studentBatchMapping->batch->name,
                        'branch' => [
                            'id' => $studentBatchMapping->batch->parent->id,
                            'name' =>$studentBatchMapping->batch->parent->name
                        ],
                        'is_active' => $studentBatchMapping->batch->is_active,
                    ];
                });

                return [
                    'id' => $mapping->id,
                    'Coach' => [
                        'id' => $mapping->AdminUsers->id,
                        'name' => $mapping->AdminUsers->name,
                    ],
                    'student' => [
                        'id' => $student->id,
                        'name' => $student->name,
                        'enrollment_id' => $student->enrollment_id,
                        'packages' => $student->packages->map(function ($package) {
                            return [
                                'id' => $package->id,
                                'package_id' => $package->package_id,
                                'name' => $package->package_name,
                            ];
                        }),
                        'batches' => $batches,
                    ],
                    'is_active' => $mapping->is_active,
                ];
            });

            if($data){
                return [
                    'status' => true,
                    'message' => __('Admin::response_message.mappings.assignstudents_retrive'),
                    'data' => $data,
                ];
            } else {
                return [
                    'status' => false,
                    'message' => __('Admin::response_message.mappings.assignstudents_notretrive'),
                ];
            }
        }

        public function getAssignBatches($Coach_Id)
        {
            $CoachRole = Role::where('role_name', 'Coach')->first();
            $Coach = AdminUsers::whereHas('roles', function ($query) use ($CoachRole) {
                $query->where('role_id', $CoachRole->id);
            })->where('id', $Coach_Id)->first();

            if (!$Coach) {
                return [
                    'status' => false,
                    'message' => __('Admin::response_message.mappings.coach_notFound'),
                ];
            }

            $mappings = TACoachBatchMapping::with(['AdminUsers', 'batch'])
                ->where('is_deleted', false)
                ->where('admin_user_id', $Coach_Id)
                ->get();

            $data = $mappings->map(function ($mapping) {
                return [
                    'id' => $mapping->id,
                    'coach' => [
                        'id' => $mapping->AdminUsers->id,
                        'name' => $mapping->AdminUsers->name,
                    ],
                    'batch' => [
                        'id' => $mapping->batch->id,
                        'name' => $mapping->batch->name,
                        'branch' => [
                            'id' => $mapping->batch->parent->id,
                            'name' => $mapping->batch->parent->name
                        ],
                    ],
                    'is_active' => $mapping->is_active,
                ];
            });

            if ($data) {
                return [
                    'status' => true,
                    'message' => __('Admin::response_message.mappings.assigbatch_retrive'),
                    'data' => $data,
                ];
            } else {
                return [
                    'status' => false,
                    'message' => __('Admin::response_message.mappings.assigbatch_notretrive'),
                ];
            }
        }


        public function getActiveAssignStudents($Coach_Id)
        {
            $CoachRole = Role::where('role_name', 'Coach')->first();
            $Coach = AdminUsers::whereHas('roles', function ($query) use ($CoachRole) {
                $query->where('role_id', $CoachRole->id);
            })->where('id', $Coach_Id)->first();
        
            if (!$Coach) {
                return [
                    'status' => false,
                    'message' => __('Admin::response_message.mappings.coach_notFound'),
                ];
            }
        
            $mappings = TACoachStudentMapping::with(['AdminUsers', 'Student.studentBatchMappings.Batch'])
                ->where('is_deleted', false)
                ->where('is_active', true)
                ->where('admin_user_id', $Coach_Id)
                ->get();
        
            $data = $mappings->map(function ($mapping) {
                $student = $mapping->student;
                $batches = $student->studentBatchMappings->map(function ($studentBatchMapping) {
                    return [
                        'batch_id' => $studentBatchMapping->batch->id,
                        'batch_name' => $studentBatchMapping->batch->name,
                        'branch' => [
                            'id' => $studentBatchMapping->batch->parent->id,
                            'name' => $studentBatchMapping->batch->parent->name,
                        ],
                    ];
                });
        
                return [
                    'id' => $mapping->id,
                    'Coach' => [
                        'id' => $mapping->AdminUsers->id,
                        'name' => $mapping->AdminUsers->name,
                    ],
                    'student' => [
                        'id' => $student->id,
                        'name' => $student->name,
                        'enrollment_id' => $student->enrollment_id,
                        'packages' => $student->packages->map(function ($package) {
                            return [
                                'id' => $package->id,
                                'package_id' => $package->package_id,
                                'name' => $package->package_name,
                            ];
                        }),
                        'batches' => $batches,
                    ],
                ];
            });
        
            if ($data->isNotEmpty()) {
                return [
                    'status' => true,
                    'message' => __('Admin::response_message.mappings.assignstudents_retrive'),
                    'data' => $data,
                ];
            } else {
                return [
                    'status' => false,
                    'message' => __('Admin::response_message.mappings.assignstudents_notretrive'),
                ];
            }
        }
        
        public function getActiveAssignBatches($Coach_Id)
        {
            $CoachRole = Role::where('role_name', 'Coach')->first();
            $Coach = AdminUsers::whereHas('roles', function ($query) use ($CoachRole) {
                $query->where('role_id', $CoachRole->id);
            })->where('id', $Coach_Id)->first();
        
            if (!$Coach) {
                return [
                    'status' => false,
                    'message' => __('Admin::response_message.mappings.coach_notFound'),
                ];
            }
        
            $mappings = TACoachBatchMapping::with(['AdminUsers', 'batch'])
                ->where('is_deleted', false)
                ->where('is_active', true)
                ->where('admin_user_id', $Coach_Id)
                ->get();
        
            $data = $mappings->map(function ($mapping) {
                return [
                    'id' => $mapping->id,
                    'coach' => [
                        'id' => $mapping->AdminUsers->id,
                        'name' => $mapping->AdminUsers->name,
                    ],
                    'batch' => [
                        'id' => $mapping->batch->id,
                        'name' => $mapping->batch->name,
                        'branch' => [
                            'id' => $mapping->batch->parent->id,
                            'name' => $mapping->batch->parent->name,
                        ],
                    ],
                ];
            });
        
            if ($data->isNotEmpty()) {
                return [
                    'status' => true,
                    'message' => __('Admin::response_message.mappings.assigbatch_retrive'),
                    'data' => $data,
                ];
            } else {
                return [
                    'status' => false,
                    'message' => __('Admin::response_message.mappings.assigbatch_notretrive'),
                ];
            }
        }
        
        public function assignStudents($request)
        {
            $CoachRole = Role::where('role_name', 'Coach')->first();
            $Coach = AdminUsers::whereHas('roles', function ($query) use ($CoachRole) {
                $query->where('role_id', $CoachRole->id);
            })->where('id', $request->admin_user_id)->first();
        
            if (!$Coach) {
                return [
                    'status' => false,
                    'message' => __('Admin::response_message.mappings.coach_notFound'),
                ];
            }
        
            foreach ($request->students as $studentData) {
                TACoachStudentMapping::updateOrCreate(
                    ['student_id' => $studentData['id'], 'admin_user_id' => $request->admin_user_id],
                    ['is_deleted' => 0]
                );
            }
        
            return [
                'status' => true,
                'message' => __('Student assigned successfully'),
                'data' => $request->students,
            ];
        }
        
        public function assignBatches($request)
        {
            $CoachRole = Role::where('role_name', 'Coach')->first();
            $Coach = AdminUsers::whereHas('roles', function ($query) use ($CoachRole) {
                $query->where('role_id', $CoachRole->id);
            })->where('id', $request->admin_user_id)->first();
        
            if (!$Coach) {
                return [
                    'status' => false,
                    'message' => __('Admin::response_message.mappings.coach_notFound'),
                ];
            }
        
            foreach ($request->batches as $batchData) {
                TACoachBatchMapping::updateOrCreate(
                    ['batch_id' => $batchData['id'], 'admin_user_id' => $request->admin_user_id],
                    ['is_deleted' => 0]
                );
                $studentListData = StudentBatchMapping::where('batch_id', $batchData['id'])->get();
                foreach ($studentListData as $studentData) {
                    TACoachStudentMapping::updateOrCreate(
                        ['student_id' => $studentData['student_id'], 'admin_user_id' => $request->admin_user_id],
                        ['is_deleted' => 0]
                    );
                }
            }
        
            return [
                'status' => true,
                'message' => __('Admin::response_message.mappings.batch_assigned'),
                'data' => $request->batches,
            ];
        }
        
        public function CoachswithActiveStudentnBatches()
        {
            $coachRole = Role::where('role_name', 'Coach')->first();
            $coachs = AdminUsers::whereHas('roles', function ($query) use ($coachRole) {
                $query->where('role_id', $coachRole->id);
            })->get()->map(function ($coach) {
                $data = $coach->only(['id', 'name', 'username', 'is_active', 'timezone_id']);
                
                // Count active batches assigned to this coach
                $batchCount = TACoachBatchMapping::where('admin_user_id', $coach->id)
                    ->where('is_active', true)
                    ->count();
                
                // Count active students assigned to this coach
                $studentCount = TACoachStudentMapping::where('admin_user_id', $coach->id)
                    ->where('is_active', true)
                    ->count();
                
                // Add counts to the coach object
                $data['Active_Batches'] = $batchCount;
                $data['Active_Students'] = $studentCount;
                
                return $data;
            });
        
            if ($coachs->isEmpty()) {
                return [
                    'status' => false,
                    'message' => __('Admin::response_message.mappings.coach_notFound'),
                ];
            }
        
            return [
                'status' => true,
                'message' => __('Admin::response_message.mappings.coach_Found'),
                'data' => $coachs,
            ];
        }
        
        public function ActiveDeactiveAssignStudent($id)
        {
            $mapping = TACoachStudentMapping::find($id);
            if (!$mapping) {
                return [
                    'status' => false,
                    'message' => __('Admin::response_message.mappings.mapping_notFound'),
                ];
            }
            $mapping->is_active = $mapping->is_active ? 0 : 1;
            $mapping->save();
        
            if ($mapping->is_active) {
                return [
                    'status' => true,
                    'message' => __('Admin::response_message.mappings.student_activated'),
                    'data' => $mapping,
                ];
            } else {
                return [
                    'status' => true,
                    'message' => __('Admin::response_message.mappings.student_deactivated'),
                    'data' => $mapping,
                ];
            }
        }
        
        public function ActiveDeactiveAssignBatch($id)
        {
            $mapping = TACoachBatchMapping::find($id);
        
            if (!$mapping) {
                return [
                    'status' => false,
                    'message' => __('Admin::response_message.mappings.mapping_notFound'),
                ];
            }
        
            // Toggle is_active status
            $mapping->is_active = !$mapping->is_active;
            $mapping->save();
        
            // Retrieve batch_id and admin_user_id
            $batchId = $mapping->batch_id;
            $adminUserId = $mapping->admin_user_id;
        
            // Find all student IDs associated with the batch
            $studentIds = StudentBatchMapping::where('batch_id', $batchId)
                ->pluck('student_id')
                ->toArray();
        
            // Activate/deactivate students in TACoachStudentMapping
            foreach ($studentIds as $studentId) {
                $studentMapping = TACoachStudentMapping::where('admin_user_id', $adminUserId)
                    ->where('student_id', $studentId)
                    ->first();
        
                if ($studentMapping) {
                    $studentMapping->is_active = $mapping->is_active ? 1 : 0;
                    $studentMapping->save();
                }
            }
        
            if ($mapping->is_active) {
                return [
                    'status' => true,
                    'message' => __('Admin::response_message.mappings.batch_activated'),
                    'data' => $mapping,
                ];
            } else {
                return [
                    'status' => true,
                    'message' => __('Admin::response_message.mappings.batch_deactivated'),
                    'data' => $mapping,
                ];
            }
        }
        
        public function destroyAssignStudents($id)
        {
            $mapping = TACoachStudentMapping::find($id);
        
            if (!$mapping) {
                return [
                    'status' => false,
                    'message' => __('Admin::response_message.mappings.mapping_notFound'),
                ];
            }
        
            // Soft delete the record by setting is_deleted to true
            $mapping->is_deleted = true;
            $mapping->save();
        
            if ($mapping->is_deleted) {
                return [
                    'status' => true,
                    'message' => __('Admin::response_message.mappings.student_deleted'),
                    'data' => $mapping,
                ];
            } else {
                return [
                    'status' => false,
                    'message' => __('Admin::response_message.mappings.student_not_deleted'),
                ];
            }
        }
        
        public function destroyAssignBatch($id)
        {
            $mapping = TACoachBatchMapping::find($id);

            if (!$mapping) {
                return [
                    'status' => false,
                    'message' => __('Admin::response_message.mappings.mapping_notFound'),
                ];
            }

            $batchId = $mapping->batch_id;
            $adminUserId = $mapping->admin_user_id;

            $studentIds = StudentBatchMapping::where('batch_id', $batchId)
                ->pluck('student_id')
                ->toArray();

            $mapping->is_deleted = true;
            $mapping->save();

            foreach ($studentIds as $studentId) {
                $studentMapping = TACoachStudentMapping::where('admin_user_id', $adminUserId)
                    ->where('student_id', $studentId)
                    ->first();

                if ($studentMapping) {
                    $studentMapping->is_deleted = true;
                    $studentMapping->save();
                }
            }

            return [
                'status' => true,
                'message' => __('Admin::response_message.mappings.batch_deleted'),
                'data' => $mapping,
            ];
        }

        public function destroyMapping($id)
        {
            $studentMappings = TACoachStudentMapping::where('admin_user_id', $id)->get();
            $batchMappings = TACoachBatchMapping::where('admin_user_id', $id)->get();

            $studentMappings->each(function ($mapping) {
                $mapping->is_deleted = true;
                $mapping->save();
            });

            $batchMappings->each(function ($mapping) {
                $mapping->is_deleted = true;
                $mapping->save();
            });

            if ($studentMappings->isNotEmpty() && $batchMappings->isNotEmpty()) {
                return [
                    'status' => true,
                    'message' => __('Admin::response_message.mappings.mapping_deleted'),
                    'data' => ['StudentMapping' => $studentMappings, 'BatchMapping' => $batchMappings],
                ];
            } else {
                return [
                    'status' => false,
                    'message' => __('Admin::response_message.mappings.mapping_not_deleted'),
                ];
            }
        }
    }    