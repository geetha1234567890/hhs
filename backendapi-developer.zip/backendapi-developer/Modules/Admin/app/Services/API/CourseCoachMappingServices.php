<?php

namespace Modules\Admin\Services\API;

class CourseCoachMappingServices
{
    /**
     * Get the available Coaches for the current date.
     *
     * @return array The response containing status, message, and data if available.
     */
    public function storeCoachCourseMapping($request)
    {
        $Coach_id= $request->Coach_id;
        $courses = $request->courses ?? []; 
        $coach = AdminUsers::find($Coach_id);
        $coachRole = $coach->roles;
    
        if (!$coachRole->contains('role_name', 'Coach')) {
            //return response()->json(['error' => 'Only Coach can be assigned to a course'], 403);

            return [
                'status' => false,
                'message' => __('Admin::response_message.course_coach_mapping.not_allow'),
            ];
        }
    
        foreach ($courses as $course) {
            $course = Course::find($course['id']);
                $course->coaches()->attach($Coach_id);
            }

        return [
                'status' => true,
                'message' => __('Admin::response_message.course_coach_mapping.coach_coache_mapping_sucess'),
                'data' => $courses,
            ];
    }
}
