<?php

namespace Modules\Admin\Services\API;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class ZoomServices {
    private function generateToken() {
        try {
            $response = Http::withHeaders([
                'Authorization' => 'Basic ' . base64_encode(env('ZOOM_CLIENT_ID') . ':' . env('ZOOM_CLIENT_SECRET')),
                'Content-Type' => 'application/x-www-form-urlencoded'
            ])->asForm()->post(env('ZOOM_OAUTH_TOKEN_URL'), [
                'grant_type' => 'client_credentials'
            ]);

            if ($response->successful()) {
                return $response->json()['access_token'];
            } else {
                Log::error('Error generating Zoom token', ['response' => $response->body()]);
                return null;
            }
        } catch (\Throwable $th) {
            Log::error('Exception in generateToken', ['error' => $th->getMessage()]);
            return null;
        }
    }

    public function createMeeting($data, $start_date, $meetingType = 'meetings') {
        $token = $this->generateToken();
 
        if (!$token) {
            return response()->json(['error' => 'Unable to generate Zoom token'], 500);
        }

        try {
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $token,
                'Content-Type' => 'application/json'
            ])->post(env('ZOOM_API_URL') . 'users/' . $data['host_id'] . '/' . $meetingType, [
                'topic' => $data['meeting_name'],
                'type' => 2,
                'start_time' => $start_date,
                'duration' => $data['duration'],
                'agenda' => $data['description'],
                'timezone' => 'UTC',
                'settings' => [
                    'host_video' => false,
                    'participant_video' => false,
                    'approval_type' => 0,
                    'waiting_room' => true,
                ]
            ]);

            if ($response->successful()) {
                return $response->json();
            } else {
                Log::error('Error creating Zoom meeting', ['response' => $response->body()]);
                return response()->json(['error' => 'Unable to create Zoom meeting'], 500);
            }
        } catch (\Throwable $th) {
            Log::error('Exception in createMeeting', ['error' => $th->getMessage()]);
            return response()->json(['error' => 'Exception occurred while creating Zoom meeting'], 500);
        }
    }

    public function addParticipant($meetingId, $participantData) {
        $token = $this->generateToken();

        if (!$token) {
            return response()->json(['error' => 'Unable to generate Zoom token'], 500);
        }

        try {
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $token,
                'Content-Type' => 'application/json'
            ])->post(env('ZOOM_API_URL') . 'meetings/' . $meetingId . '/registrants', $participantData);

            if ($response->successful()) {
                return $response->json();
            } else {
                Log::error('Error adding participant to Zoom meeting', ['response' => $response->body()]);
                return response()->json(['error' => 'Unable to add participant to Zoom meeting'], 500);
            }
        } catch (\Throwable $th) {
            Log::error('Exception in addParticipant', ['error' => $th->getMessage()]);
            return response()->json(['error' => 'Exception occurred while adding participant to Zoom meeting'], 500);
        }
    }
    public function deleteMeeting($meetingId)
    {
        $token = $this->generateToken();

        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $token,
            'Content-Type' => 'application/json'
        ])->delete(env('ZOOM_API_URL'). 'meetings/' . $meetingId);

        return $response->json();
    }
}


// // Usage example:
// $zoomService = new ZoomService();
// $data = [
//     'host_id' => 'your_host_id',
//     'meeting_name' => 'Meeting Name',
//     'duration' => 30,
//     'description' => 'Meeting Description'
// ];
// $start_date = '2023-06-20T15:00:00Z';

// // Create a new meeting
// $response = $zoomService->createMeeting($data, $start_date);
// $meetingId = $response['id'] ?? null;

// // Add a participant to the meeting
// if ($meetingId) {
//     $participantData = [
//         'email' => 'participant@example.com',
//         'first_name' => 'ParticipantFirstName',
//         'last_name' => 'ParticipantLastName'
//     ];
//     $participantResponse = $zoomService->addParticipant($meetingId, $participantData);
//     print_r($participantResponse);
// }

?>

