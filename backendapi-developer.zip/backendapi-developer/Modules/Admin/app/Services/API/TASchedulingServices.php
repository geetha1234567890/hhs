<?php 
    namespace Modules\Admin\Services\API;
    use Auth;
    use Crypt;
    use Modules\Admin\Models\AdminUsers;
    use Modules\Admin\Models\Role;
    use Modules\Admin\Models\TACoachScheduling;
    use Modules\Admin\Models\TACoachBatchScheduling;
    use Modules\Admin\Models\TACoachStudentScheduling;
    use Modules\Admin\Models\TACoachStudentMapping;
    use Modules\Admin\Models\TACoachBatchMapping;
    use Modules\Admin\Models\StudentBatchMapping; 
    use Carbon\Carbon;
    use Modules\Admin\Models\Student;
    use Modules\Admin\Models\Batch;
    use Modules\Admin\Models\TACoachSlots;
    use Modules\Admin\Models\MeetingDetails;
    use Modules\Admin\Services\API\ZoomServices;
    use Illuminate\Support\Facades\Log;


class TASchedulingServices
{   

    public function __construct(ZoomServices $zoomService) {
        $this->zoomService = $zoomService;
    }

    /**
     * Retrieve all TA coach schedules and return as API response.
     *
     * @return array
     */

    public function getOneTaAllSessions($ta_id)
    {   
        //print 'in getOneTaAllSessions';
        $taRole = Role::where('role_name', 'TA')->first();
        $ta = AdminUsers::where('id', $ta_id)
            ->whereHas('roles', function ($query) use ($taRole) {
                $query->where('role_id', $taRole->id);
            })
            ->first();

        if (is_null($ta)) {
            return [
                'status' => false,
                'message' =>  __('Admin::response_message.schedules.ta_role_not_found'),
            ];
        }
        
        // Retrieve all TA coach schedules for the week from the database
        $schedules = TACoachScheduling::with(['PlatformToolDetails','PlatformMeetingDetails'])->where('admin_user_id', $ta_id)
            ->where('is_deleted', false)
            ->orderBy('date')
            ->orderBy('start_time')
            ->get();
        

        // Check if schedules were found
        if ($schedules) {
            // Return success response with schedules data
            $schedules = $schedules->toArray();
            return [
                'status' => true,
                'message' => __('Admin::response_message.schedules.schedule_retrieve'),
                'data' => $schedules,
            ];
        } else {
            // Return failure response if no schedules were found
            return [
                'status' => false,
                'message' => __('Admin::response_message.schedules.schedule_not_found'),
            ];
        }
    }



    public function getOneTaAllRecords($request,$ta_id)
    {   
        //print 'in getOneTaAllRecords';
        $taRole = Role::where('role_name', 'TA')->first();
        $ta = AdminUsers::where('id', $ta_id)
            ->whereHas('roles', function ($query) use ($taRole) {
                $query->where('role_id', $taRole->id);
            })
            ->first();

        if (is_null($ta)) {
            return [
                'status' => false,
                'message' =>  __('Admin::response_message.schedules.ta_role_not_found'),
            ];
        }
        $startDate = $request->start_date;
        $endDate = $request->end_date;
        if(!$startDate &&  !$endDate){
            $startDate = now()->startOfWeek();
            $endDate = now()->endOfWeek();
        }
        
        // Retrieve all TA coach schedules for the week from the database
        $schedules = TACoachScheduling::with(['PlatformToolDetails','PlatformMeetingDetails'])->where('admin_user_id', $ta_id)
            ->whereBetween('date', [$startDate, $endDate])
            ->where('is_deleted', false)
            ->orderBy('date')
            ->orderBy('start_time')
            ->get();
        

        // Check if schedules were found
        if ($schedules) {
            // Return success response with schedules data
            $schedules = $schedules->toArray();
            return [
                'status' => true,
                'message' => __('Admin::response_message.schedules.schedule_retrieve'),
                'data' => $schedules,
            ];
        } else {
            // Return failure response if no schedules were found
            return [
                'status' => false,
                'message' => __('Admin::response_message.schedules.schedule_not_found'),
            ];
        }
    }

    public function getScheduleStudents($id)
    {
        $schedule = TACoachScheduling::find($id);
        if($schedule){
            $students = $schedule->students()
            ->wherePivot('is_deleted', 0)
            ->get()
            ->map(function ($student) {
                return [
                    'student_id' => $student->id,
                    'student_name' => $student->name,
                    'packages' => $student->packages->map(function ($package) {
                        return [
                            'id' => $package->id,
                            'package_id' => $package->package_id,
                            'name' => $package->package_name,
                        ];
                    }),
                    'enrollment_id' => $student->enrollment_id,
                    'is_active' => $student->is_active,
                    'batches' => $student->studentBatchMappings->map(function ($mapping) {
                        return [
                            'batch_id' => $mapping->batch->id,
                            'batch_name' => $mapping->batch->name,
                            'branch' => [
                                'id' => $mapping->batch->parent->id,
                                'name' => $mapping->batch->parent->name
                            ],
                            'is_active' => $mapping->batch->is_active
                        ];
                    })
                ];
            });
            return [
                'status' => true,
                'message' => __('Admin::response_message.schedules.get_schedule_students'),
                'data' => $students,
            ];
        }else{
            return [
                'status' => false,
                'message' => __('Admin::response_message.schedules.get_schedule_students_failed'),
            ];
        }
    }

    public function getScheduleBatches($id)
    {
        $schedule = TACoachScheduling::find($id);
        if($schedule){
            $batches = $schedule->batch()
            ->wherePivot('is_deleted', 0)
            ->get()
            ->map(function ($batch) {
                return [
                    'batch_id' => $batch->id,
                    'batch_name' => $batch->name,
                    'branch' => [
                        'id' => $batch->parent->id,
                        'name' => $batch->parent->name
                    ],
                    'is_active' => $batch->is_active
                ];
            });
            return [
                'status' => true,
                'message' => __('Admin::response_message.schedules.get_schedule_batches'),
                'data' => $batches,
            ];
        }else{
            return [
                'status' => false,
                'message' => __('Admin::response_message.schedules.get_schedule_batches_failed'),
            ];
        }
    }

    /**
     * Update schedules student and batches based on the provided request data.
     *
     * @param Illuminate\Http\Request $request
     * @return array
     */

     public function updateScheduleStudents($request, $id)
     {
         $schedule = TACoachScheduling::find($id);
         if ($schedule) {
             $adminUserId = $schedule->admin_user_id;
             $studentIds = $request->studentId ?? [];
             
             // Retrieve all existing mappings for the schedule
             $existingMappings = TACoachStudentScheduling::where('ta_schedule_id', $id)->get();
             
             // Mark all existing mappings as deleted
             foreach ($existingMappings as $mapping) {
                 $mapping->is_deleted = true;
                 $mapping->save();
             }
     
             // Iterate over the new list of student IDs
             foreach ($studentIds as $studentId) {
                 // Update or create the student scheduling mapping
                 TACoachStudentScheduling::updateOrCreate(
                     ['ta_schedule_id' => $id, 'student_id' => $studentId],
                     [
                         'is_deleted' => false, // Reactivate if previously marked as deleted
                         'updated_by' => $adminUserId,
                     ]
                 );
             }
             
             return [
                 'status' => true,
                 'message' => __('Admin::response_message.schedules.update_schedule_students'),
                 'data' => $studentIds,
             ];
         } else {
             return [
                 'status' => false,
                 'message' => __('Admin::response_message.schedules.update_schedule_students_failed'),
             ];
         }
     }

     public function updateScheduleBatches($request, $id)
    {
        $schedule = TACoachScheduling::find($id);
        if ($schedule) {
            $adminUserId = $schedule->admin_user_id;
            $newBatchIds = $request->batchId ?? [];
            
            // Retrieve all existing batch mappings for the schedule
            $existingBatchMappings = TACoachBatchScheduling::where('ta_schedule_id', $id)->get();
            
            // Mark all existing batch mappings as deleted
            foreach ($existingBatchMappings as $batchMapping) {
                $batchMapping->is_deleted = true;
                $batchMapping->save();
            }

            // Handle the new list of batches
            foreach ($newBatchIds as $batchId) {
                // Update or create the batch scheduling mapping
                TACoachBatchScheduling::updateOrCreate(
                    ['ta_schedule_id' => $id, 'batch_id' => $batchId],
                    [
                        'is_deleted' => false, // Reactivate if previously marked as deleted
                        'updated_by' => $adminUserId,
                    ]
                );

                // Find students associated with this batch
                $batchStudents = StudentBatchMapping::where('batch_id', $batchId)->get();

                // For each student in the batch, update or create the student scheduling mapping
                foreach ($batchStudents as $batchStudent) {
                    $studentId = $batchStudent->student_id;

                    TACoachStudentScheduling::updateOrCreate(
                        ['ta_schedule_id' => $id, 'student_id' => $studentId],
                        [
                            'is_deleted' => false, // Reactivate if previously marked as deleted
                            'updated_by' => $adminUserId,
                        ]
                    );
                }
            }

            return [
                'status' => true,
                'message' => __('Admin::response_message.schedules.update_schedule_batches'),
                'data' => [
                    'batch_ids' => $newBatchIds,
                ],
            ];
        } else {
            return [
                'status' => false,
                'message' => __('Admin::response_message.schedules.update_schedule_batches_failed'),
            ];
        }
    }


    private function deleteZoomData($meeting_id){
        $response = $this->zoomService->deleteMeeting($meeting_id);
        return $response;
    }
    
    /**
     * Deletes a schedule and all related schedules in the series.
     *
     * @param int $id The ID of the schedule to delete.
     * @return array An array containing the status, message, and data.
     */
    public function DeleteSchedules($id)
    {
        // Find the slot with the given ID
        $schedule = TACoachScheduling::find($id);

        if($schedule){
            $meeting_data =  MeetingDetails::find($schedule->meeting_id);
            $platform_id = $schedule->platform_id;

            if($platform_id == 1){
                $deletezoom = $this->deleteZoomData($meeting_data->platform_meeting_id);

                if ($deletezoom) {
                    return [
                        'status' => false,
                        'message' => ['error deleting zoom meeting' => $deletezoom],
                    ];
                }
            }else if($platform_id == 2){
                //TODO : delete for MS Teams
            }else if($platform_id == 3){
                //TODO : delete for big blue button
            }

            MeetingDetails::where('id',$schedule->meeting_id)->delete();

            $schedule_deleted = $schedule->delete();
            //ToDO
            // Delete all schedules with the same series ID as the deleted slot
            // $related_schedules_deleted = TACoachScheduling::where('series', $schedules->id)->delete();

            return [
                'status'=>true,
                'message' => __('Admin::response_message.schedules.schedule_deleted'),
                'data'=>$schedule_deleted,
            ];

        }else{  
            return [
                'status'=>false,
                'message' =>  __('Admin::response_message.schedules.schedule_not_found'),
               
            ];
        }
    }

    /**
     * Cancle a schedule and all related schedules in the series.
     *
     * @param int $id The ID of the schedule to delete.
     * @return array An array containing the status, message, and data.
     */
    public function CancelSchedules($id)
    {
        // Find the slot with the given ID
        $schedule = TACoachScheduling::find($id);
    
        if ($schedule) {
            $meeting_data =  MeetingDetails::find($schedule->meeting_id);
            $platform_id = $schedule->platform_id;

            if($platform_id == 1){
                $deletezoom = $this->deleteZoomData($meeting_data->platform_meeting_id);

                if ($deletezoom) {
                    return [
                        'status' => false,
                        'message' => ['error deleting zoom meeting' => $deletezoom],
                    ];
                }
            }else if($platform_id == 2){
                //TODO : delete for MS Teams
            }else if($platform_id == 3){
                //TODO : delete for big blue button
            }

            // MeetingDetails::where('id',$schedule->meeting_id)->delete();

            $schedule->is_deleted = true;
            $schedule->event_status = 'cancelled';
            $schedule->is_active = false;
            $schedule_deleted = $schedule->save();

            return [
                'status' => true,
                'message' => __('Admin::response_message.schedules.schedule_deleted'),
                'data' => $schedule,
            ];
        } else {
            return [
                'status' => false,
                'message' => __('Admin::response_message.schedules.schedule_not_found'),
            ];
        }
    }

    /**
     * Store schedules based on the provided request data.
     *
     * @param Illuminate\Http\Request $request
     * @return array
     */

    private function createZoomData($zoomData){
        try {
           
             $schedule_date = $zoomData['schedule_date'];
             $start_time = $zoomData['start_time'];
             $end_time = $zoomData['end_time'];
             $meeting_name = $zoomData['meeting_name'];
             $adminUserEmail = $zoomData['admin_user_email'];
            
             $datetime_string = "$schedule_date $start_time";

             $datetime = Carbon::createFromFormat('Y-m-d H:i:s', $datetime_string, 'UTC');
             $formatted_datetime =$datetime->toIso8601String();
             $start = Carbon::createFromTimeString($start_time);
             $end = Carbon::createFromTimeString($end_time);
             // Calculate the difference in minutes
             $minutes = $start->diffInMinutes($end);
             $data = [
                         'host_id' => $adminUserEmail,//'sandeeppatel@dynapt.co.in',//$adminUserEmail,
                         'meeting_name' => $meeting_name,
                         'duration' => $minutes,
                         'description' => $meeting_name
                     ];
                    
            $zoom_response = $this->zoomService->createMeeting($data,$formatted_datetime);
            return [
                'status' => true,
                'message' => __('Admin::response_message.schedules.schedule_store'),
                'data' => $zoom_response,
            ];
        }
        catch (\Throwable $th) {
            Log::error('Exception in create zoom Meeting', ['error' => $th->getMessage()]);
            return [
                'status' => false,
                'message' => ['error creating zoom meeting' => $th->getMessage()],
            ];
        }

    }
    
    public function storeSchedules($request)
    {
        // Extract request parameters
        $adminUserId = $request->admin_user_id;
        $meeting_name = $request->meeting_name;
        $start_date = Carbon::parse($request->schedule_date);
        $endDate = Carbon::parse($request->end_date);
        $slot_id = $request->slot_id;
        $platform_id = $request->platform_id;
        $start_time = $request->start_time;
        $end_time = $request->end_time;
        $timezone_id = $request->timezone_id;
        $event_status = $request->event_status;
        $studentIds = $request->studentId ?? []; 
        $batchIds = $request->batchId ?? [];
        $weeks = $request->weeks ?? []; // array example: [1,0,0,1,0,1,0]
        $potentialDates = [];
        // Calculate all dates within the range based on the weeks array
        for ($date = $start_date; $date->lte($endDate); $date->addDay()) {
            $dayOfWeek = $date->dayOfWeek; // 0 (Sunday) to 6 (Saturday)
            if (isset($weeks[$dayOfWeek]) && $weeks[$dayOfWeek] == 1) {
                $potentialDates[] = $date->format('Y-m-d');
            }
        }
    
        // Check for slot clashes on all potential dates
        foreach ($potentialDates as $date) {
            $existingSchedule = TACoachScheduling::where('admin_user_id', $adminUserId)
                                        ->where('date', $date)
                                        ->orderBy('start_time')
                                        ->where('is_deleted', false)
                                        ->get();
    
            foreach ($existingSchedule as $schedule) {
                if (($start_time >= $schedule->start_time && $start_time < $schedule->end_time) ||
                    ($end_time > $schedule->start_time && $end_time <= $schedule->end_time) ||
                    ($start_time <= $schedule->start_time && $end_time >= $schedule->end_time)) {

                    return [
                        'status'=>false,
                        'message' => __('Admin::response_message.schedules.schedule_clash_message', ['date' => $date]),
                    ];

                }
            }
        }
        $potentialSlots = [];
        foreach ($potentialDates as $date) {
            $existingSlots = TACoachSlots::where('admin_user_id', $adminUserId)
                                        ->where('slot_date', $date)
                                        ->orderBy('from_time')
                                        ->get();

            if ($existingSlots->isEmpty()) {
                return [
                    'status' => false,
                    'message' => __('response_message.slots.slot_not_found', ['date' => $date]),
                ];
            }
            $count = 0;
            foreach ($existingSlots as $slot) {
                if (($start_time >= $slot->from_time && $end_time <= $slot->to_time)) {
                    $potentialSlots[] = $slot;
                    $count = 1;
                }
            }
            if($count==0){
                return [
                    'status' => false,
                    'message' => __('response_message.slots.slot_time_message',[
                        'date' => $date,
                        'slot_from_time' => $start_time,
                        'slot_to_time' => $end_time
                    ]
                ),
                ];
            }
        }
        // No clashes found, proceed to create schedules
        $created_schedule = [];
        $seriesId = null;
        //TODO :
        // $admin_user_email = AdminUsers::find($adminUserId)->email;
        // $admin_user_email = crypt::decrypt($admin_user_email);
        $admin_user_email = 'sandeeppatel@dynapt.co.in';
        foreach ($potentialSlots as $slot) {
            $meeting_id = 0;
            if($platform_id == 1){
                $zoomData = [
                    'admin_user_email' => $admin_user_email,
                    'meeting_name' => $meeting_name,
                    'schedule_date' => $slot['slot_date'],
                    'start_time' => $start_time,
                    'end_time' => $end_time,
                ];
                $zoom_meeting_data = $this->createZoomData($zoomData);

                if($zoom_meeting_data['status'] == false){
                    return $zoom_meeting_data;
                }

                $zoom_response = $zoom_meeting_data['data'];

                $newMeetingDetails = new MeetingDetails([
                    'platform_meeting_id' => $zoom_response['id'],
                    'host_meeting_url' =>$zoom_response['start_url'],
                    'join_url' => $zoom_response['join_url'],
                    'password' => $zoom_response['password'],
                    'h323_password' => $zoom_response['h323_password'],
                    'pstn_password' => $zoom_response['pstn_password'],
                    'encrypted_password' => $zoom_response['encrypted_password'],
                ]);
                $newMeetingDetails->save();
                $meeting_id = $newMeetingDetails->id;

            }else if($platform_id == 2){
                $newMeetingDetails = new MeetingDetails([
                    'platform_meeting_id' => random_int(100000, 999999),
                    'host_meeting_url' => 'http://localhost:8000',
                    'join_url' => 'http://localhost:8000',
                    'password' => '123456',
                ]);
                $newMeetingDetails->save();
                $meeting_id = $newMeetingDetails->id;
                //TODO : MS Teams
            }else if($platform_id == 3){
                $newMeetingDetails = new MeetingDetails([
                    'platform_meeting_id' => random_int(100000, 999999),
                    'host_meeting_url' => 'http://localhost:8000',
                    'join_url' => 'http://localhost:8000',
                    'password' => '123456',
                ]);
                $newMeetingDetails->save();
                $meeting_id = $newMeetingDetails->id;
                //TODO : big blue button
            }

            $newSchedule = new TACoachScheduling([
                'admin_user_id' => $adminUserId,
                'meeting_name' => $meeting_name,
                'meeting_id' => $meeting_id,
                'platform_id' => $platform_id,
                'date' => $slot['slot_date'],
                'slot_id' => $slot['id'],
                'start_time' => $start_time,
                'end_time' => $end_time,
                'timezone_id' => $timezone_id,
                'event_status' => $event_status,
                'session_type' => 'Live',
                'created_by' => 1,
                'updated_by' => 1,
            ]);
            
            $newSchedule->save();
            // Assign series ID for grouping, ensuring null for the first slot and parent ID for subsequent schedules
            if ($seriesId === null) {
                // If $seriesId is null, set it to the ID of the first created slot
                $seriesId = $newSchedule->id;
            } else {
                // For subsequent schedules, assign the same $seriesId (parent ID)
                $newSchedule->series = $seriesId;
                $newSchedule->save();
            }

            foreach ($request->batchId as $batchData) {
                $Batch = Batch::find($batchData);
                if ($Batch) {
                    $newSchedule->batch()->attach($Batch);
            
                    $studentListData = StudentBatchMapping::where('batch_id', $batchData)->get();
                    foreach ($studentListData as $studentMapping) {
                        $studentId = $studentMapping->student_id;
                        TACoachStudentScheduling::firstOrCreate(
                            ['ta_schedule_id' => $newSchedule->id, 'student_id' => $studentId],
                            [
                                'created_by' => 1,
                                'updated_by' => 1,
                            ]
                        );
                    }
                }
            }
            foreach ($request->studentId as $studentId) {
                TACoachStudentScheduling::firstOrCreate(
                    ['ta_schedule_id' => $newSchedule->id, 'student_id' => $studentId],
                    [
                        'created_by' => 1,
                        'updated_by' => 1,
                    ]
                );
            }            
            $created_schedule[] = $newSchedule;
        }

        // Return appropriate response based on slot creation result
        if($created_schedule){
            return [
                'status'=>true,
                'message' => __('Admin::response_message.schedules.schedule_store'),
                'data'=>$created_schedule,
            ];
        }else{
            return [
                'status'=>false,
                'message' => __('Admin::response_message.schedules.store_schedule_failed'),
            ];
        }

    }


    /**
     * reschedule based on the provided request data.
     *
     * @param Illuminate\Http\Request $request
     * @return array
     */
    public function ReSchedules($request , $id)
    {
        $adminUserId = $request->admin_user_id;
        $start_date = Carbon::parse($request->schedule_date);
        $slot_id = $request->slot_id;
        $start_time = $request->start_time;
        $end_time = $request->end_time;
        $timezone_id = $request->timezone_id;

        // Validate slotDate against today's date
        
        $existingSchedule = TACoachScheduling::where('admin_user_id', $adminUserId)
                                        ->where('id', '!=', $id)
                                        ->where('is_deleted', false)
                                        ->get();
            
    
            foreach ($existingSchedule as $schedule) {
                if (($start_time >= $schedule->start_time && $start_time < $schedule->end_time) ||
                    ($end_time > $schedule->start_time && $end_time <= $schedule->end_time) ||
                    ($start_time <= $schedule->start_time && $end_time >= $schedule->end_time)) {

                    return [
                        'status'=>false,
                        'message' => __('Admin::response_message.schedules.schedule_clash_message', ['date' => $start_date . ' ' . $start_time . ' - ' . $end_time]),
                    ];

                }
            }

        $existingSlot = TACoachSlots::where('admin_user_id', $adminUserId)
                                        ->where('id', $slot_id)
                                        ->where('slot_date', $start_date)
                                        ->get();

        if ($existingSlot->isEmpty()) {
            return [
                'status' => false,
                 'message' =>__('Admin::response_message.slots.slot_not_found', ['date' => $start_date]),
            ];
        }
        //die($existingSlot[0]);

        if($existingSlot[0]['from_time'] > $start_time || $existingSlot[0]['to_time'] < $end_time){
            return [
                'status' => false,
                'message' => __('response_message.slots.slot_time_message',[
                        'date' => $date,
                        'slot_from_time' => $start_time,
                        'slot_to_time' => $end_time
                    ]
                ),
            ];
        }

        
        // No clashes found, proceed to create schedules
        $newSchedule = TACoachScheduling::find($id);

        if($newSchedule){

            $meeting_data =  MeetingDetails::find($newSchedule->meeting_id);
            $platform_id = $newSchedule->platform_id;

            if($platform_id == 1){
                $deletezoom = $this->deleteZoomData($meeting_data->platform_meeting_id);

                if ($deletezoom) {
                    return [
                        'status' => false,
                        'message' => ['error deleting zoom meeting' => $deletezoom],
                    ];
                }
                //TODO :
                // $admin_user_email = AdminUsers::find($adminUserId)->email;
                // $admin_user_email = crypt::decrypt($admin_user_email);
                $admin_user_email = 'sandeeppatel@dynapt.co.in';

                $zoomData = [
                    'admin_user_email' => $admin_user_email,
                    'meeting_name' => $newSchedule->meeting_name,
                    'schedule_date' => $request->schedule_date,
                    'start_time' => $start_time,
                    'end_time' => $end_time,
                ];

                $zoom_meeting_data = $this->createZoomData($zoomData);
                if($zoom_meeting_data['status'] == false){
                    return $zoom_meeting_data;
                }

                $zoom_response = $zoom_meeting_data['data'];

                $meeting_data->platform_meeting_id = $zoom_response['id'];
                $meeting_data->host_meeting_url = $zoom_response['start_url'];
                $meeting_data->join_url = $zoom_response['join_url'];
                $meeting_data->password = $zoom_response['password'];
                $meeting_data->h323_password = $zoom_response['h323_password'];
                $meeting_data->pstn_password = $zoom_response['pstn_password'];
                $meeting_data->encrypted_password = $zoom_response['encrypted_password'];
                $meeting_data->save();
            }
            else if($platform_id == 2){
                //TODO : MS Teams
            }
            else if($platform_id == 3){
                //TODO : big blue button
            }
            
            $newSchedule->date = $start_date;
            $newSchedule->slot_id = $slot_id;
            $newSchedule->start_time = $start_time;
            $newSchedule->end_time = $end_time;
            $newSchedule->timezone_id= $timezone_id;
            $newSchedule->event_status = 'rescheduled';
            $newSchedule->save();
            return [
                'status'=>true,
                'message' => __('Admin::response_message.schedules.reschedule'),
                'data'=>$newSchedule,
            ];
        }else{
            return [
                'status'=>false,
                'message' => __('Admin::response_message.schedules.failed_reschedule'),
            ];
        }

    }
    

    public function changePlatform($request,$id)
    {
        $adminUserId = $request->admin_user_id;
        $platform_id = $request->platform_id;

        $schedule = TACoachScheduling::find($id);
        if($schedule){
            
            $previous_platform_id = $schedule->platform_id;

            if($previous_platform_id == $platform_id){
                return [
                    'status'=>false,
                    'message' => __('Admin::response_message.schedules.platform_same'),
                ];
            }
            // first delete the previous meeting of platform
            $meeting_data =  MeetingDetails::find($schedule->meeting_id);
            if($previous_platform_id == 1){
                $deletezoom = $this->deleteZoomData($meeting_data->platform_meeting_id);

                if ($deletezoom) {
                    return [
                        'status' => false,
                        'message' => ['error deleting zoom meeting' => $deletezoom],
                    ];
                }
            }else if($previous_platform_id == 2){
                //TODO : delete for MS Teams
            }else if($previous_platform_id == 3){
                //TODO : delete for big blue button
            }

            // create new meeting on platform

            if($platform_id == 1){
                // $admin_user_email = AdminUsers::find($adminUserId)->email;
                // $admin_user_email = crypt::decrypt($admin_user_email);
                $admin_user_email = 'sandeeppatel@dynapt.co.in';
                $formattedDate = Carbon::parse($schedule->date)->format('Y-m-d');
                $zoomData = [
                    'admin_user_email' => $admin_user_email,
                    'meeting_name' => $schedule->meeting_name,
                    'schedule_date' => $formattedDate,
                    'start_time' => $schedule->start_time,
                    'end_time' => $schedule->end_time,
                ];
                $zoom_meeting_data = $this->createZoomData($zoomData);

                if($zoom_meeting_data['status'] == false){
                    return $zoom_meeting_data;
                }

                $zoom_response = $zoom_meeting_data['data'];

                $meeting_data->platform_meeting_id = $zoom_response['id'];
                $meeting_data->host_meeting_url = $zoom_response['start_url'];
                $meeting_data->join_url = $zoom_response['join_url'];
                $meeting_data->password = $zoom_response['password'];
                $meeting_data->h323_password = $zoom_response['h323_password'];
                $meeting_data->pstn_password = $zoom_response['pstn_password'];
                $meeting_data->encrypted_password = $zoom_response['encrypted_password'];
                $meeting_data->save();
            }
            else if($platform_id == 2){
                //TODO : create for MS Teams
                $meeting_data->platform_meeting_id = random_int(100000, 999999);
                $meeting_data->host_meeting_url = 'http://localhost:8000';
                $meeting_data->join_url = 'http://localhost:8000';
                $meeting_data->password = '123456';
                $meeting_data->h323_password = null;
                $meeting_data->pstn_password = null;
                $meeting_data->encrypted_password = null;
                $meeting_data->save();
            }
            else if($platform_id == 3){
                //TODO : create for big blue button
                $meeting_data->platform_meeting_id = random_int(100000, 999999);
                $meeting_data->host_meeting_url = 'http://localhost:8000';
                $meeting_data->join_url = 'http://localhost:8000';
                $meeting_data->password = '123456';
                $meeting_data->h323_password = null;
                $meeting_data->pstn_password = null;
                $meeting_data->encrypted_password = null;
                $meeting_data->save();
            }

            $schedule->platform_id = $request->platform_id;
            $schedule->save();
            return [
                'status'=>true,
                'message' => __('Admin::response_message.schedules.platform_changed'),
                'data'=>$schedule,
            ];
        }else{
            return [
                'status'=>false,
                'message' => __('Admin::response_message.schedules.schedule_not_found'),
            ];
        }
    }


    /**
     * Retrieve TA schedules records based on admin user ID and data criteria.
     *
     * @param Illuminate\Http\Request $request
     * @return array
     */
    public function getTASchedulesRecords($request)
    {
        // Extract admin user ID and data from request input
        $admin_user_id = $request->input('admin_user_id');
        $data = $request->input('data');
        
        // Initialize an empty response array
        $response = [];

        // Loop through each data entry to fetch matching records
        foreach ($data as $item) {

            $date = $item['date'];
            $slotId = $item['slot_id'];
            $startTime = $item['start_time'];
            $endTime = $item['end_time'];

            // Query to fetch TA scheduling records based on criteria
            $records = TACoachScheduling::with(['students.studentBatchMappings.batch'])
                ->where('admin_user_id', $admin_user_id)
                ->where('slot_id', $slotId)
                ->where('is_deleted', false)
                ->whereDate('date', $date)
                ->whereTime('start_time', '>=', $startTime)
                ->whereTime('end_time', '<=', $endTime)
                ->get();

            $formattedRecords = $records->map(function ($record) {
                $students = $record->students->map(function ($student) {
                    return [
                        'student_id' => $student->id,
                        'student_name' => $student->name,
                        'packages' => $student->packages->map(function ($package) {
                            return [
                                'id' => $package->id,
                                'package_id' => $package->package_id,
                                'name' => $package->package_name,
                            ];
                        }),
                        'enrollment_id' => $student->enrollment_id,
                        'is_active' => $student->is_active,
                        'batches' => $student->studentBatchMappings->map(function ($mapping) {
                            return [
                                'batch_id' => $mapping->batch->id,
                                'batch_name' => $mapping->batch->name,
                                'branch' => [
                                    'id' => $mapping->batch->parent->id,
                                    'name' => $mapping->batch->parent->name
                                ],
                                'is_active' => $mapping->batch->is_active
                            ];
                        })
                    ];
                });

                return [
                    'id' => $record->id,
                    'admin_user_id' => $record->admin_user_id,
                    'meeting_name' => $record->meeting_name,
                    'meeting_id' => $record->meeting_id,
                    'platform_id' => $record->platform_id,
                    'date' => $record->date,
                    'slot_id' => $record->slot_id,
                    'start_time' => $record->start_time,
                    'end_time' => $record->end_time,
                    'timezone_id' => $record->timezone_id,
                    'is_active' => $record->is_active,
                    'event_status' => $record->event_status,
                    'session_type' => $record->session_type,
                    'is_deleted' => $record->is_deleted,
                    'created_by' => $record->created_by,
                    'updated_by' => $record->updated_by,
                    'Students' => $students
                ];
            });

            // Merge fetched records into response array
            $response = array_merge($response, $formattedRecords->toArray());
        }
    
        // Prepare and return response based on fetched records
        if ($response) {
            return [
                'status' => true,
                'message' => __('Admin::response_message.schedules.schedule_retrieve'),
                'data' => $response,
            ];
        } else {
            return [
                'status' => false,
                'message' => __('Admin::response_message.schedules.schedule_not_found'),
            ];
        }
    }

}
