<?php

namespace Modules\Admin\Services\API;

use Modules\Admin\Models\AdminUsers;
use Modules\Admin\Models\TACoachStudentMapping;
use Modules\Admin\Models\TACoachBatchMapping;
use Modules\Admin\Models\StudentBatchMapping;
use Modules\Admin\Models\Student;
use Modules\Admin\Models\Batch;
use Modules\Admin\Models\Role;

class TaMappingServices
{

    /**
     * Retrieve all TA coach slots and return as API response.
     *
     * @return array
     */

     public function getAssignStudents($TA_Id)
     {
        $taRole = Role::where('role_name', 'TA')->first();
        $ta = AdminUsers::whereHas('roles', function ($query) use ($taRole) {
            $query->where('role_id', $taRole->id);
        })->where('id', $TA_Id)->first();

        if (!$ta) {
           return [
               'status' => false,
               'message' => "TA not found",
           ];
        }

        $mappings = TACoachStudentMapping::with(['AdminUsers', 'Student.studentBatchMappings.Batch'])
                    ->where('is_deleted', false)
                    ->where('admin_user_id', $TA_Id)
                    ->get();

        $data = $mappings->map(function($mapping) {
            $student = $mapping->student;
            $batches = $student->studentBatchMappings->map(function ($studentBatchMapping) {
                return [
                    'batch_id' => $studentBatchMapping->batch->id,
                    'batch_name' => $studentBatchMapping->batch->name,
                    'branch' => [
                            'id' => $studentBatchMapping->batch->parent->id,
                            'name' =>$studentBatchMapping->batch->parent->name
                    ],
                    'is_active' => $studentBatchMapping->batch->is_active,
                ];
            });

            return [
                'id' => $mapping->id,
                'ta' => [
                    'id' => $mapping->AdminUsers->id,
                    'name' => $mapping->AdminUsers->name,
                ],
                'student' => [
                    'id' => $student->id,
                    'name' => $student->name,
                    'enrollment_id' => $student->enrollment_id,
                    'packages' => $student->packages->map(function ($package) {
                        return [
                            'id' => $package->id,
                            'package_id' => $package->package_id,
                            'name' => $package->package_name,
                        ];
                    }),
                    'batches' => $batches,
                ],
                'is_active' => $mapping->is_active,
            ];
        });

        if($data){
            return [
                'status' => true,
                'message' => __('Admin::response_message.mappings.student_retrive'),
                'data' => $data,
            ];
        }else{
            return [
                'status' => false,
                'message' => "Assign student not found",
            ];
        }
     }
 
 
     
 
     public function getAssignBatches($TA_Id)
     {
        $taRole = Role::where('role_name', 'TA')->first();
        $ta = AdminUsers::whereHas('roles', function ($query) use ($taRole) {
            $query->where('role_id', $taRole->id);
        })->where('id', $TA_Id)->first();

        if (!$ta) {
            return [
                'status' => false,
                'message' => "TA not found",
            ];
        }

        $mappings = TACoachBatchMapping::with(['AdminUsers', 'batch'])
                    ->where('is_deleted', false)
                    ->where('admin_user_id', $TA_Id)
                    ->get();

        $data = $mappings->map(function($mapping) {
            return [
                'id' => $mapping->id,
                'ta' => [
                    'id' => $mapping->AdminUsers->id,
                    'name' => $mapping->AdminUsers->name,
                ],
                'batch' => [
                    'id' => $mapping->batch->id,
                    'name' => $mapping->batch->name,
                    'branch' => [
                        'id' => $mapping->batch->parent->id,
                        'name' => $mapping->batch->parent->name
                    ],
                ],
                'is_active' => $mapping->is_active,
                // 'is_deleted' => $mapping->is_deleted,
            ];
        });

        if($data){
            return [
                'status' => true,
                'message' => "Assign batch retrive successfully",
                'data' => $data,
            ];
        }else{
            return [
                'status' => false,
                'message' => "Assign batch not found",
            ];
        }

     }

     
     public function getActiveAssignStudents($TA_Id)
     {
        $taRole = Role::where('role_name', 'TA')->first();
        $ta = AdminUsers::whereHas('roles', function ($query) use ($taRole) {
            $query->where('role_id', $taRole->id);
        })->where('id', $TA_Id)->first();

        if (!$ta) {
           return [
               'status' => false,
               'message' => "TA not found",
           ];
        }

        $mappings = TACoachStudentMapping::with(['AdminUsers', 'Student.studentBatchMappings.Batch'])
                    ->where('is_deleted', false)
                    ->where('is_active', true)
                    ->where('admin_user_id', $TA_Id)
                    ->get();

        $data = $mappings->map(function($mapping) {
            $student = $mapping->student;
            $batches = $student->studentBatchMappings->map(function ($studentBatchMapping) {
                return [
                    'batch_id' => $studentBatchMapping->batch->id,
                    'batch_name' => $studentBatchMapping->batch->name,
                    'branch' => [
                            'id' => $studentBatchMapping->batch->parent->id,
                            'name' =>$studentBatchMapping->batch->parent->name
                    ],
                ];
            });

            return [
                'id' => $mapping->id,
                'ta' => [
                    'id' => $mapping->AdminUsers->id,
                    'name' => $mapping->AdminUsers->name,
                ],
                'student' => [
                    'id' => $student->id,
                    'name' => $student->name,
                    'enrollment_id' => $student->enrollment_id,
                    'packages' => $student->packages->map(function ($package) {
                        return [
                            'id' => $package->id,
                            'package_id' => $package->package_id,
                            'name' => $package->package_name,
                        ];
                    }),
                    'batches' => $batches,
                ],
            ];
        });

        if($data){
            return [
                'status' => true,
                'message' => __('Admin::response_message.mappings.student_retrive'),
                'data' => $data,
            ];
        }else{
            return [
                'status' => false,
                'message' => "Assign student not found",
            ];
        }
     }
 
 
     
 
     public function getActiveAssignBatches($TA_Id)
     {
        $taRole = Role::where('role_name', 'TA')->first();
        $ta = AdminUsers::whereHas('roles', function ($query) use ($taRole) {
            $query->where('role_id', $taRole->id);
        })->where('id', $TA_Id)->first();

        if (!$ta) {
            return [
                'status' => false,
                'message' => "TA not found",
            ];
        }

        $mappings = TACoachBatchMapping::with(['AdminUsers', 'batch'])
                    ->where('is_deleted', false)
                    ->where('is_active', true)
                    ->where('admin_user_id', $TA_Id)
                    ->get();

        $data = $mappings->map(function($mapping) {
            return [
                'id' => $mapping->id,
                'ta' => [
                    'id' => $mapping->AdminUsers->id,
                    'name' => $mapping->AdminUsers->name,
                ],
                'batch' => [
                    'id' => $mapping->batch->id,
                    'name' => $mapping->batch->name,
                    'branch' => [
                        'id' => $mapping->batch->parent->id,
                        'name' => $mapping->batch->parent->name
                    ],
                ],
                // 'is_deleted' => $mapping->is_deleted,
            ];
        });

        if($data){
            return [
                'status' => true,
                'message' => "Active Assign batch retrive successfully",
                'data' => $data,
            ];
        }else{
            return [
                'status' => false,
                'message' => "Active Assign batch not found",
            ];
        }

     }
     
     /**
      * Store a newly created resource in storage.
      */
     public function assignStudents($request)
     {  
        $taRole = Role::where('role_name', 'TA')->first();
        $ta = AdminUsers::whereHas('roles', function ($query) use ($taRole) {
            $query->where('role_id', $taRole->id);
        })->where('id', $request->admin_user_id)->first();

        if (!$ta) {
            return [
                'status' => false,
                'message' => "TA not found",
            ];
        }


        foreach ($request['students'] as $studentData) {
            $student = TACoachStudentMapping ::updateOrCreate(
                ['student_id' => $studentData['id'], 'admin_user_id' => $request['admin_user_id']],['is_deleted' => 0]
            );
        }

        return [
            'status' => true,
            'message' => "Student assigned successfully",
            'data' => $request['students'],
        ];
     }
     
     public function assignBatches($request)
     {
        $taRole = Role::where('role_name', 'TA')->first();
        $ta = AdminUsers::whereHas('roles', function ($query) use ($taRole) {
            $query->where('role_id', $taRole->id);
        })->where('id', $request->admin_user_id)->first();

        if (!$ta) {
            return [
                'status' => false,
                'message' => "TA not found",
            ];
        }

        foreach ($request->batches as $batchData) {
            TACoachBatchMapping::updateOrCreate([
                'batch_id' => $batchData['id'],
                'admin_user_id' => $request->admin_user_id,
            ],['is_deleted' => 0]);
            $studentListData = StudentBatchMapping::where('batch_id',  $batchData['id'])->get();
            foreach ($studentListData as $studentData) {
                $student = TACoachStudentMapping ::updateOrCreate(
                    ['student_id' => $studentData['student_id'], 'admin_user_id' => $request->admin_user_id],['is_deleted' => 0]
                );
            }
        }

        return [
            'status' => true,
            'message' => "Batch assigned successfully",
            'data' =>$request['batches'],
        ];
     }
     
     
 
 
 
     public function TAswithActiveStudentnBatches()
     {
        $taRole = Role::where('role_name', 'TA')->first();
        $tas = AdminUsers::whereHas('roles', function ($query) use ($taRole) {
            $query->where('role_id', $taRole->id);
        })->get()->map(function ($ta) {
            $data = $ta->only(['id', 'name', 'username', 'is_active','timezone_id']);
            
            // Count active batches assigned to this TA
            $batchCount = TACoachBatchMapping::where('admin_user_id', $ta->id)
                ->where('is_deleted', false)
                ->where('is_active', true)
                ->count();
                
            // Count active students assigned to this TA
            $studentCount = TACoachStudentMapping::where('admin_user_id', $ta->id)
                ->where('is_deleted', false)
                ->where('is_active', true)
                ->count();
            
            // Add counts to the TA object
            $data['Active_Batches'] = $batchCount;
            $data['Active_Students'] = $studentCount;
            
            return $data;
        });

        if ($tas->isEmpty()) {
            return [
                'status' => false,
                'message' => "TA not found",
            ];
        }
    
        return [
            'status' => true,
            'message' => "TA(s) retrive successfully",
            'data' => $tas,
        ];
     }
 
 
     public function ActiveDeactiveAssignStudent($id)
     {
        $mapping = TACoachStudentMapping ::find($id);
        if (!$mapping) {
            return [
                'status' => false,
                'message' => "Mapping not found",
            ];
        }
        $mapping->is_active = $mapping->is_active ? 0 : 1;
        $mapping->save();

        if($mapping->is_active){
            return [
                'status' => true,
                'message' => "Student Activated successfully",
                'data' => $mapping,
            ];
        }else{
            return [
                'status' => true,
                'message' => "Student De-Activated successfully",
                'data' => $mapping,
            ];
        }
     }
     
 
     public function ActiveDeactiveAssignBatch($id)
     {
        $mapping = TACoachBatchMapping::find($id);
 
        if (!$mapping) {
            return [
                'status' => false,
                'message' => "Mapping not found",
            ];
        }

        // Soft delete the record by setting is_deleted to true
        $mapping->is_active = !$mapping->is_active;
        $mapping->save();
 
        // Retrieve batch_id and admin_user_id
        $batchId = $mapping->batch_id;
        $adminUserId = $mapping->admin_user_id;

        // Find all student IDs associated with the batch
        $studentIds = StudentBatchMapping::where('batch_id', $batchId)
            ->pluck('student_id')
            ->toArray();

        // Activate/deactivate students in tacoachstudentmapping
        foreach ($studentIds as $studentId) {
            $studentMapping = TACoachStudentMapping::where('admin_user_id', $adminUserId)
                ->where('student_id', $studentId)
                ->first();

            if ($studentMapping) {
                $studentMapping->is_active = $mapping->is_active ? 1 : 0;
                $studentMapping->save();
            }
            //print $studentMapping;
        }

        if($mapping->is_active){
            return [
                'status' => true,
                'message' => "Batch Activated successfully",
                'data' => $mapping,
            ];
        }else{
            return [
                'status' => true,
                'message' => "Batch De-Activated successfully",
                'data' => $mapping,
            ];
        }
     }
     
 
     /**
      * Remove the specified resource from storage.
      */
     public function destroyAssignStudents($id)
     {
        $mapping = TACoachStudentMapping ::find($id);
 
        if (!$mapping) {
           
            return [
                'status' => false,
                'message' => "Mapping not found",
            ];
        }

        // Soft delete the record by setting is_deleted to true
        $mapping->is_deleted = true;
        $mapping->save();

        if($mapping->is_deleted){
            return [
                'status' => true,
                'message' => "Student deleted successfully",
                'data' => $mapping,
            ];
        }else{
            return [
                'status' => false,
                'message' => "Student not deleted",
            ];
        }

     }
     
     public function destroyAssignBatch($id)
     {
        $mapping = TACoachBatchMapping::find($id);
     
             if (!$mapping) {
                    return [
                        'status' => false,
                        'message' => "Mapping not found",
                    ];
             }
     
             $batchId = $mapping->batch_id;
             $adminUserId = $mapping->admin_user_id;
     
             $studentIds = StudentBatchMapping::where('batch_id', $batchId)
                 ->pluck('student_id')
                 ->toArray();
     
            $mapping->is_deleted = true;
            $mapping->save();
     
     
             foreach ($studentIds as $studentId) {
                 $studentMapping = TACoachStudentMapping::where('admin_user_id', $adminUserId)
                     ->where('student_id', $studentId)
                     ->first();
     
                 if ($studentMapping) {
                    $studentMapping->is_deleted = true;
                    $studentMapping->save();
                 }
             }
     
                return [
                    'status' => true,
                    'message' => "Batch deleted successfully",
                    'data' => $mapping,
                ];
     }

     public function destroyMapping($id)
    {
        $studentMappings = TACoachStudentMapping::where('admin_user_id', $id)->get();
        $batchMappings = TACoachBatchMapping::where('admin_user_id', $id)->get();

        $studentMappings->each(function ($mapping) {
            $mapping->is_deleted = true;
            $mapping->save();
        });

        $batchMappings->each(function ($mapping) {
            $mapping->is_deleted = true;
            $mapping->save();
        });

        if ($studentMappings->isNotEmpty() && $batchMappings->isNotEmpty()) {
            return [
                'status' => true,
                'message' => __('Admin::response_message.mappings.mapping_deleted'),
                'data' => ['StudentMapping' => $studentMappings, 'BatchMapping' => $batchMappings],
            ];
        } else {
            return [
                'status' => false,
                'message' => __('Admin::response_message.mappings.mapping_not_deleted'),
            ];
        }
    }
}
