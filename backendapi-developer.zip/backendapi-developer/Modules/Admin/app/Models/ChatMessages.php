<?php

namespace Modules\Admin\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Modules\Admin\Database\Factories\ChatMessagesFactory;

class ChatMessages extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'chat_id', 
        'sender_id', 
        'sender_type', 
        'message_text', 
        'status', 
        'sent_at', 
        'read_at', 
        'delivery_time'
    ];

    public function sender()
    {
        return $this->morphTo();
    }

    public function chats()
    {
        return $this->belongsTo(Chats::class,'chat_id');
    }
    
    public function chatMessageFiles()
    {
        return $this->hasOne(ChatMessageFiles::class,'message_id');
    }
}
