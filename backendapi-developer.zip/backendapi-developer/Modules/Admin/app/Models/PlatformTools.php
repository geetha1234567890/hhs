<?php

namespace Modules\Admin\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class PlatformTools extends Model
{
    use HasFactory;

    protected $table = 'platform_tools';

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = ['name'];

}
