<?php

namespace Modules\Admin\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Modules\Admin\Database\Factories\StudentJoinedMeetingStatusFactory;

class StudentJoinedMeetingStatus extends Model
{
    use HasFactory;

    protected $table = 'student_joined_meeting_status';

    protected $fillable = [
        'student_id',
        'ta_schedule_id',
        'joined_at'
    ];

    public function student()
    {
        return $this->belongsTo(Student::class);
    }

    public function taCoachScheduling()
    {
        return $this->belongsTo(TACoachScheduling::class, 'ta_schedule_id', 'id');
    }
}
