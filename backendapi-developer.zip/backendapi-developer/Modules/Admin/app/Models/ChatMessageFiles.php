<?php

namespace Modules\Admin\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Modules\Admin\Database\Factories\ChatMessageFilesFactory;

class ChatMessageFiles extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'message_id', 
        'file_name', 
        'original_name',
        'uploaded_at', 
    ];

    public function chatMessages()
    {
        return $this->belongsTo(ChatMessages::class);
    }
}
