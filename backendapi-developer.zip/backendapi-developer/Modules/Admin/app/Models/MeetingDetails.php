<?php

namespace Modules\Admin\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Modules\Admin\Database\Factories\MeetingDetailsFactory;

class MeetingDetails extends Model
{
    use HasFactory;
    protected $table = 'meeting_details';
    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'id',
        'platform_meeting_id',
        'join_url',
        'host_meeting_url',
        'password',
        'h323_password',
        'pstn_password',
        'encrypted_password',
    ];
}
