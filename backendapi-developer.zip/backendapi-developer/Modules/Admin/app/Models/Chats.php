<?php

namespace Modules\Admin\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Modules\Admin\Database\Factories\ChatsFactory;

class Chats extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'chat_name', 
        'is_group'
    ];

    public function chatMessages()
    {
        return $this->hasMany(ChatMessages::class,'chat_id');
    }

    public function adminUsers()
    {
        return $this->morphedByMany(AdminUsers::class, 'user', 'chat_users');
    }

    public function students()
    {
        return $this->morphedByMany(Student::class, 'user', 'chat_users');
    }
}
